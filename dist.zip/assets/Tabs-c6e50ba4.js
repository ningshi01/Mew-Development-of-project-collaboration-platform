import{e as K,r as W,c8 as dt,j as c,bX as bt,cp as Se,c as ct,aX as ft,aV as we,aW as pt,h as q,c4 as ut,aJ as gt,bI as vt,ce as ht,cq as xt,c7 as mt,b as r,d as i,a as T,a$ as B,bp as yt,u as Ct,g as Te,b4 as Z,b2 as ee,aU as St,b0 as H,w as wt,i as Tt,bn as ue,b5 as ge,bE as U,b3 as te,b7 as Pt,b8 as Rt,cl as zt,aT as Lt,k,cf as Y}from"./index-b27597f8.js";import{A as $t}from"./Add-a453005a.js";import{e as Wt,f as ve,u as he,a as Bt,o as _t}from"./Popover-61edb1a7.js";import{t as xe}from"./toNumber-3f46f0be.js";const At=ve(".v-x-scroll",{overflow:"auto",scrollbarWidth:"none"},[ve("&::-webkit-scrollbar",{width:0,height:0})]),Et=K({name:"XScroll",props:{disabled:Boolean,onScroll:Function},setup(){const e=W(null);function n(d){!(d.currentTarget.offsetWidth<d.currentTarget.scrollWidth)||d.deltaY===0||(d.currentTarget.scrollLeft+=d.deltaY+d.deltaX,d.preventDefault())}const s=dt();return At.mount({id:"vueuc/x-scroll",head:!0,anchorMetaName:Wt,ssr:s}),Object.assign({selfRef:e,handleWheel:n},{scrollTo(...d){var m;(m=e.value)===null||m===void 0||m.scrollTo(...d)}})},render(){return c("div",{ref:"selfRef",onScroll:this.onScroll,onWheel:this.disabled?void 0:this.handleWheel,class:"v-x-scroll"},this.$slots)}});var Vt=function(){return bt.Date.now()};const ae=Vt;var kt="Expected a function",Mt=Math.max,jt=Math.min;function Gt(e,n,s){var f,d,m,u,p,y,h=0,C=!1,S=!1,x=!0;if(typeof e!="function")throw new TypeError(kt);n=xe(n)||0,Se(s)&&(C=!!s.leading,S="maxWait"in s,m=S?Mt(xe(s.maxWait)||0,n):m,x="trailing"in s?!!s.trailing:x);function v(b){var L=f,M=d;return f=d=void 0,h=b,u=e.apply(M,L),u}function w(b){return h=b,p=setTimeout(_,n),C?v(b):u}function R(b){var L=b-y,M=b-h,G=n-L;return S?jt(G,m-M):G}function P(b){var L=b-y,M=b-h;return y===void 0||L>=n||L<0||S&&M>=m}function _(){var b=ae();if(P(b))return z(b);p=setTimeout(_,R(b))}function z(b){return p=void 0,x&&f?v(b):(f=d=void 0,u)}function A(){p!==void 0&&clearTimeout(p),h=0,f=y=d=p=void 0}function V(){return p===void 0?u:z(ae())}function g(){var b=ae(),L=P(b);if(f=arguments,d=this,y=b,L){if(p===void 0)return w(y);if(S)return clearTimeout(p),p=setTimeout(_,n),v(y)}return p===void 0&&(p=setTimeout(_,n)),u}return g.cancel=A,g.flush=V,g}var Ht="Expected a function";function re(e,n,s){var f=!0,d=!0;if(typeof e!="function")throw new TypeError(Ht);return Se(s)&&(f="leading"in s?!!s.leading:f,d="trailing"in s?!!s.trailing:d),Gt(e,n,{leading:f,maxWait:n,trailing:d})}const It={tabFontSizeSmall:"14px",tabFontSizeMedium:"14px",tabFontSizeLarge:"16px",tabGapSmallLine:"36px",tabGapMediumLine:"36px",tabGapLargeLine:"36px",tabGapSmallLineVertical:"8px",tabGapMediumLineVertical:"8px",tabGapLargeLineVertical:"8px",tabPaddingSmallLine:"6px 0",tabPaddingMediumLine:"10px 0",tabPaddingLargeLine:"14px 0",tabPaddingVerticalSmallLine:"6px 12px",tabPaddingVerticalMediumLine:"8px 16px",tabPaddingVerticalLargeLine:"10px 20px",tabGapSmallBar:"36px",tabGapMediumBar:"36px",tabGapLargeBar:"36px",tabGapSmallBarVertical:"8px",tabGapMediumBarVertical:"8px",tabGapLargeBarVertical:"8px",tabPaddingSmallBar:"4px 0",tabPaddingMediumBar:"6px 0",tabPaddingLargeBar:"10px 0",tabPaddingVerticalSmallBar:"6px 12px",tabPaddingVerticalMediumBar:"8px 16px",tabPaddingVerticalLargeBar:"10px 20px",tabGapSmallCard:"4px",tabGapMediumCard:"4px",tabGapLargeCard:"4px",tabGapSmallCardVertical:"4px",tabGapMediumCardVertical:"4px",tabGapLargeCardVertical:"4px",tabPaddingSmallCard:"8px 16px",tabPaddingMediumCard:"10px 20px",tabPaddingLargeCard:"12px 24px",tabPaddingSmallSegment:"4px 0",tabPaddingMediumSegment:"6px 0",tabPaddingLargeSegment:"8px 0",tabPaddingVerticalLargeSegment:"0 8px",tabPaddingVerticalSmallCard:"8px 12px",tabPaddingVerticalMediumCard:"10px 16px",tabPaddingVerticalLargeCard:"12px 20px",tabPaddingVerticalSmallSegment:"0 4px",tabPaddingVerticalMediumSegment:"0 6px",tabGapSmallSegment:"0",tabGapMediumSegment:"0",tabGapLargeSegment:"0",tabGapSmallSegmentVertical:"0",tabGapMediumSegmentVertical:"0",tabGapLargeSegmentVertical:"0",panePaddingSmall:"8px 0 0 0",panePaddingMedium:"12px 0 0 0",panePaddingLarge:"16px 0 0 0",closeSize:"18px",closeIconSize:"14px"},Ft=e=>{const{textColor2:n,primaryColor:s,textColorDisabled:f,closeIconColor:d,closeIconColorHover:m,closeIconColorPressed:u,closeColorHover:p,closeColorPressed:y,tabColor:h,baseColor:C,dividerColor:S,fontWeight:x,textColor1:v,borderRadius:w,fontSize:R,fontWeightStrong:P}=e;return Object.assign(Object.assign({},It),{colorSegment:h,tabFontSizeCard:R,tabTextColorLine:v,tabTextColorActiveLine:s,tabTextColorHoverLine:s,tabTextColorDisabledLine:f,tabTextColorSegment:v,tabTextColorActiveSegment:n,tabTextColorHoverSegment:n,tabTextColorDisabledSegment:f,tabTextColorBar:v,tabTextColorActiveBar:s,tabTextColorHoverBar:s,tabTextColorDisabledBar:f,tabTextColorCard:v,tabTextColorHoverCard:v,tabTextColorActiveCard:s,tabTextColorDisabledCard:f,barColor:s,closeIconColor:d,closeIconColorHover:m,closeIconColorPressed:u,closeColorHover:p,closeColorPressed:y,closeBorderRadius:w,tabColor:h,tabColorSegment:C,tabBorderColor:S,tabFontWeightActive:x,tabFontWeight:x,tabBorderRadius:w,paneTextColor:n,fontWeightStrong:P})},Ot={name:"Tabs",common:ct,self:Ft},Dt=Ot,ie=ft("n-tabs"),Pe={tab:[String,Number,Object,Function],name:{type:[String,Number],required:!0},disabled:Boolean,displayDirective:{type:String,default:"if"},closable:{type:Boolean,default:void 0},tabProps:Object,label:[String,Number,Object,Function]},Qt=K({__TAB_PANE__:!0,name:"TabPane",alias:["TabPanel"],props:Pe,setup(e){const n=we(ie,null);return n||pt("tab-pane","`n-tab-pane` must be placed inside `n-tabs`."),{style:n.paneStyleRef,class:n.paneClassRef,mergedClsPrefix:n.mergedClsPrefixRef}},render(){return c("div",{class:[`${this.mergedClsPrefix}-tab-pane`,this.class],style:this.style},this.$slots)}}),Nt=Object.assign({internalLeftPadded:Boolean,internalAddable:Boolean,internalCreatedByPane:Boolean},mt(Pe,["displayDirective"])),oe=K({__TAB__:!0,inheritAttrs:!1,name:"Tab",props:Nt,setup(e){const{mergedClsPrefixRef:n,valueRef:s,typeRef:f,closableRef:d,tabStyleRef:m,tabChangeIdRef:u,onBeforeLeaveRef:p,triggerRef:y,handleAdd:h,activateTab:C,handleClose:S}=we(ie);return{trigger:y,mergedClosable:q(()=>{if(e.internalAddable)return!1;const{closable:x}=e;return x===void 0?d.value:x}),style:m,clsPrefix:n,value:s,type:f,handleClose(x){x.stopPropagation(),!e.disabled&&S(e.name)},activateTab(){if(e.disabled)return;if(e.internalAddable){h();return}const{name:x}=e,v=++u.id;if(x!==s.value){const{value:w}=p;w?Promise.resolve(w(e.name,s.value)).then(R=>{R&&u.id===v&&C(x)}):C(x)}}}},render(){const{internalAddable:e,clsPrefix:n,name:s,disabled:f,label:d,tab:m,value:u,mergedClosable:p,style:y,trigger:h,$slots:{default:C}}=this,S=d??m;return c("div",{class:`${n}-tabs-tab-wrapper`},this.internalLeftPadded?c("div",{class:`${n}-tabs-tab-pad`}):null,c("div",Object.assign({key:s,"data-name":s,"data-disabled":f?!0:void 0},ut({class:[`${n}-tabs-tab`,u===s&&`${n}-tabs-tab--active`,f&&`${n}-tabs-tab--disabled`,p&&`${n}-tabs-tab--closable`,e&&`${n}-tabs-tab--addable`],onClick:h==="click"?this.activateTab:void 0,onMouseenter:h==="hover"?this.activateTab:void 0,style:e?void 0:y},this.internalCreatedByPane?this.tabProps||{}:this.$attrs)),c("span",{class:`${n}-tabs-tab__label`},e?c(gt,null,c("div",{class:`${n}-tabs-tab__height-placeholder`}," "),c(vt,{clsPrefix:n},{default:()=>c($t,null)})):C?C():typeof S=="object"?S:ht(S??s)),p&&this.type==="card"?c(xt,{clsPrefix:n,class:`${n}-tabs-tab__close`,onClick:this.handleClose,disabled:f}):null))}}),Xt=r("tabs",`
 box-sizing: border-box;
 width: 100%;
 display: flex;
 flex-direction: column;
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
`,[i("segment-type",[r("tabs-rail",[T("&.transition-disabled","color: red;",[r("tabs-tab",`
 transition: none;
 `)])])]),i("top",[r("tab-pane",`
 padding: var(--n-pane-padding-top) var(--n-pane-padding-right) var(--n-pane-padding-bottom) var(--n-pane-padding-left);
 `)]),i("left",[r("tab-pane",`
 padding: var(--n-pane-padding-right) var(--n-pane-padding-bottom) var(--n-pane-padding-left) var(--n-pane-padding-top);
 `)]),i("left, right",`
 flex-direction: row;
 `,[r("tabs-bar",`
 width: 2px;
 right: 0;
 transition:
 top .2s var(--n-bezier),
 max-height .2s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `),r("tabs-tab",`
 padding: var(--n-tab-padding-vertical); 
 `)]),i("right",`
 flex-direction: row-reverse;
 `,[r("tab-pane",`
 padding: var(--n-pane-padding-left) var(--n-pane-padding-top) var(--n-pane-padding-right) var(--n-pane-padding-bottom);
 `),r("tabs-bar",`
 left: 0;
 `)]),i("bottom",`
 flex-direction: column-reverse;
 justify-content: flex-end;
 `,[r("tab-pane",`
 padding: var(--n-pane-padding-bottom) var(--n-pane-padding-right) var(--n-pane-padding-top) var(--n-pane-padding-left);
 `),r("tabs-bar",`
 top: 0;
 `)]),r("tabs-rail",`
 padding: 3px;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 background-color: var(--n-color-segment);
 transition: background-color .3s var(--n-bezier);
 display: flex;
 align-items: center;
 `,[r("tabs-tab-wrapper",`
 flex-basis: 0;
 flex-grow: 1;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[r("tabs-tab",`
 overflow: hidden;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[i("active",`
 font-weight: var(--n-font-weight-strong);
 color: var(--n-tab-text-color-active);
 background-color: var(--n-tab-color-segment);
 box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .08);
 `),T("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])])]),i("flex",[r("tabs-nav",{width:"100%"},[r("tabs-wrapper",{width:"100%"},[r("tabs-tab",{marginRight:0})])])]),r("tabs-nav",`
 box-sizing: border-box;
 line-height: 1.5;
 display: flex;
 transition: border-color .3s var(--n-bezier);
 `,[B("prefix, suffix",`
 display: flex;
 align-items: center;
 `),B("prefix","padding-right: 16px;"),B("suffix","padding-left: 16px;")]),i("top, bottom",[r("tabs-nav-scroll-wrapper",[T("&::before",`
 top: 0;
 bottom: 0;
 left: 0;
 width: 20px;
 `),T("&::after",`
 top: 0;
 bottom: 0;
 right: 0;
 width: 20px;
 `),i("shadow-start",[T("&::before",`
 box-shadow: inset 10px 0 8px -8px rgba(0, 0, 0, .12);
 `)]),i("shadow-end",[T("&::after",`
 box-shadow: inset -10px 0 8px -8px rgba(0, 0, 0, .12);
 `)])])]),i("left, right",[r("tabs-nav-scroll-wrapper",[T("&::before",`
 top: 0;
 left: 0;
 right: 0;
 height: 20px;
 `),T("&::after",`
 bottom: 0;
 left: 0;
 right: 0;
 height: 20px;
 `),i("shadow-start",[T("&::before",`
 box-shadow: inset 0 10px 8px -8px rgba(0, 0, 0, .12);
 `)]),i("shadow-end",[T("&::after",`
 box-shadow: inset 0 -10px 8px -8px rgba(0, 0, 0, .12);
 `)])])]),r("tabs-nav-scroll-wrapper",`
 flex: 1;
 position: relative;
 overflow: hidden;
 `,[r("tabs-nav-y-scroll",`
 height: 100%;
 width: 100%;
 overflow-y: auto; 
 scrollbar-width: none;
 `,[T("&::-webkit-scrollbar",`
 width: 0;
 height: 0;
 `)]),T("&::before, &::after",`
 transition: box-shadow .3s var(--n-bezier);
 pointer-events: none;
 content: "";
 position: absolute;
 z-index: 1;
 `)]),r("tabs-nav-scroll-content",`
 display: flex;
 position: relative;
 min-width: 100%;
 width: fit-content;
 box-sizing: border-box;
 `),r("tabs-wrapper",`
 display: inline-flex;
 flex-wrap: nowrap;
 position: relative;
 `),r("tabs-tab-wrapper",`
 display: flex;
 flex-wrap: nowrap;
 flex-shrink: 0;
 flex-grow: 0;
 `),r("tabs-tab",`
 cursor: pointer;
 white-space: nowrap;
 flex-wrap: nowrap;
 display: inline-flex;
 align-items: center;
 color: var(--n-tab-text-color);
 font-size: var(--n-tab-font-size);
 background-clip: padding-box;
 padding: var(--n-tab-padding);
 transition:
 box-shadow .3s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[i("disabled",{cursor:"not-allowed"}),B("close",`
 margin-left: 6px;
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `),B("label",`
 display: flex;
 align-items: center;
 `)]),r("tabs-bar",`
 position: absolute;
 bottom: 0;
 height: 2px;
 border-radius: 1px;
 background-color: var(--n-bar-color);
 transition:
 left .2s var(--n-bezier),
 max-width .2s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `,[T("&.transition-disabled",`
 transition: none;
 `),i("disabled",`
 background-color: var(--n-tab-text-color-disabled)
 `)]),r("tabs-pane-wrapper",`
 position: relative;
 overflow: hidden;
 transition: max-height .2s var(--n-bezier);
 `),r("tab-pane",`
 color: var(--n-pane-text-color);
 width: 100%;
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 opacity .2s var(--n-bezier);
 left: 0;
 right: 0;
 top: 0;
 `,[T("&.next-transition-leave-active, &.prev-transition-leave-active, &.next-transition-enter-active, &.prev-transition-enter-active",`
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 transform .2s var(--n-bezier),
 opacity .2s var(--n-bezier);
 `),T("&.next-transition-leave-active, &.prev-transition-leave-active",`
 position: absolute;
 `),T("&.next-transition-enter-from, &.prev-transition-leave-to",`
 transform: translateX(32px);
 opacity: 0;
 `),T("&.next-transition-leave-to, &.prev-transition-enter-from",`
 transform: translateX(-32px);
 opacity: 0;
 `),T("&.next-transition-leave-from, &.next-transition-enter-to, &.prev-transition-leave-from, &.prev-transition-enter-to",`
 transform: translateX(0);
 opacity: 1;
 `)]),r("tabs-tab-pad",`
 box-sizing: border-box;
 width: var(--n-tab-gap);
 flex-grow: 0;
 flex-shrink: 0;
 `),i("line-type, bar-type",[r("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 box-sizing: border-box;
 vertical-align: bottom;
 `,[T("&:hover",{color:"var(--n-tab-text-color-hover)"}),i("active",`
 color: var(--n-tab-text-color-active);
 font-weight: var(--n-tab-font-weight-active);
 `),i("disabled",{color:"var(--n-tab-text-color-disabled)"})])]),r("tabs-nav",[i("line-type",[i("top",[B("prefix, suffix",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),r("tabs-nav-scroll-content",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),r("tabs-bar",`
 bottom: -1px;
 `)]),i("left",[B("prefix, suffix",`
 border-right: 1px solid var(--n-tab-border-color);
 `),r("tabs-nav-scroll-content",`
 border-right: 1px solid var(--n-tab-border-color);
 `),r("tabs-bar",`
 right: -1px;
 `)]),i("right",[B("prefix, suffix",`
 border-left: 1px solid var(--n-tab-border-color);
 `),r("tabs-nav-scroll-content",`
 border-left: 1px solid var(--n-tab-border-color);
 `),r("tabs-bar",`
 left: -1px;
 `)]),i("bottom",[B("prefix, suffix",`
 border-top: 1px solid var(--n-tab-border-color);
 `),r("tabs-nav-scroll-content",`
 border-top: 1px solid var(--n-tab-border-color);
 `),r("tabs-bar",`
 top: -1px;
 `)]),B("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 `),r("tabs-nav-scroll-content",`
 transition: border-color .3s var(--n-bezier);
 `),r("tabs-bar",`
 border-radius: 0;
 `)]),i("card-type",[B("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),r("tabs-pad",`
 flex-grow: 1;
 transition: border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-tab-border-color);
 `),r("tabs-tab-pad",`
 transition: border-color .3s var(--n-bezier);
 `),r("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 border: 1px solid var(--n-tab-border-color);
 background-color: var(--n-tab-color);
 box-sizing: border-box;
 position: relative;
 vertical-align: bottom;
 display: flex;
 justify-content: space-between;
 font-size: var(--n-tab-font-size);
 color: var(--n-tab-text-color);
 `,[i("addable",`
 padding-left: 8px;
 padding-right: 8px;
 font-size: 16px;
 `,[B("height-placeholder",`
 width: 0;
 font-size: var(--n-tab-font-size);
 `),yt("disabled",[T("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])]),i("closable","padding-right: 8px;"),i("active",`
 background-color: #0000;
 font-weight: var(--n-tab-font-weight-active);
 color: var(--n-tab-text-color-active);
 `),i("disabled","color: var(--n-tab-text-color-disabled);")]),r("tabs-scroll-padding","border-bottom: 1px solid var(--n-tab-border-color);")]),i("left, right",[r("tabs-wrapper",`
 flex-direction: column;
 `,[r("tabs-tab-wrapper",`
 flex-direction: column;
 `,[r("tabs-tab-pad",`
 height: var(--n-tab-gap-vertical);
 width: 100%;
 `)])])]),i("top",[i("card-type",[r("tabs-tab",`
 border-top-left-radius: var(--n-tab-border-radius);
 border-top-right-radius: var(--n-tab-border-radius);
 `,[i("active",`
 border-bottom: 1px solid #0000;
 `)]),r("tabs-tab-pad",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `)])]),i("left",[i("card-type",[r("tabs-tab",`
 border-top-left-radius: var(--n-tab-border-radius);
 border-bottom-left-radius: var(--n-tab-border-radius);
 `,[i("active",`
 border-right: 1px solid #0000;
 `)]),r("tabs-tab-pad",`
 border-right: 1px solid var(--n-tab-border-color);
 `)])]),i("right",[i("card-type",[r("tabs-tab",`
 border-top-right-radius: var(--n-tab-border-radius);
 border-bottom-right-radius: var(--n-tab-border-radius);
 `,[i("active",`
 border-left: 1px solid #0000;
 `)]),r("tabs-tab-pad",`
 border-left: 1px solid var(--n-tab-border-color);
 `)])]),i("bottom",[i("card-type",[r("tabs-tab",`
 border-bottom-left-radius: var(--n-tab-border-radius);
 border-bottom-right-radius: var(--n-tab-border-radius);
 `,[i("active",`
 border-top: 1px solid #0000;
 `)]),r("tabs-tab-pad",`
 border-top: 1px solid var(--n-tab-border-color);
 `)])])])]),Ut=Object.assign(Object.assign({},Te.props),{value:[String,Number],defaultValue:[String,Number],trigger:{type:String,default:"click"},type:{type:String,default:"bar"},closable:Boolean,justifyContent:String,size:{type:String,default:"medium"},placement:{type:String,default:"top"},tabStyle:[String,Object],barWidth:Number,paneClass:String,paneStyle:[String,Object],paneWrapperClass:String,paneWrapperStyle:[String,Object],addable:[Boolean,Object],tabsPadding:{type:Number,default:0},animated:Boolean,onBeforeLeave:Function,onAdd:Function,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],onClose:[Function,Array],labelSize:String,activeName:[String,Number],onActiveNameChange:[Function,Array]}),Zt=K({name:"Tabs",props:Ut,setup(e,{slots:n}){var s,f,d,m;const{mergedClsPrefixRef:u,inlineThemeDisabled:p}=Ct(e),y=Te("Tabs","-tabs",Xt,Dt,e,u),h=W(null),C=W(null),S=W(null),x=W(null),v=W(null),w=W(!0),R=W(!0),P=he(e,["labelSize","size"]),_=he(e,["activeName","value"]),z=W((f=(s=_.value)!==null&&s!==void 0?s:e.defaultValue)!==null&&f!==void 0?f:n.default?(m=(d=Z(n.default())[0])===null||d===void 0?void 0:d.props)===null||m===void 0?void 0:m.name:null),A=Bt(_,z),V={id:0},g=q(()=>{if(!(!e.justifyContent||e.type==="card"))return{display:"flex",justifyContent:e.justifyContent}});ee(A,()=>{V.id=0,G(),le()});function b(){var t;const{value:a}=A;return a===null?null:(t=h.value)===null||t===void 0?void 0:t.querySelector(`[data-name="${a}"]`)}function L(t){if(e.type==="card")return;const{value:a}=C;if(a&&t){const o=`${u.value}-tabs-bar--disabled`,{barWidth:l,placement:$}=e;if(t.dataset.disabled==="true"?a.classList.add(o):a.classList.remove(o),["top","bottom"].includes($)){if(M(["top","maxHeight","height"]),typeof l=="number"&&t.offsetWidth>=l){const E=Math.floor((t.offsetWidth-l)/2)+t.offsetLeft;a.style.left=`${E}px`,a.style.maxWidth=`${l}px`}else a.style.left=`${t.offsetLeft}px`,a.style.maxWidth=`${t.offsetWidth}px`;a.style.width="8192px",a.offsetWidth}else{if(M(["left","maxWidth","width"]),typeof l=="number"&&t.offsetHeight>=l){const E=Math.floor((t.offsetHeight-l)/2)+t.offsetTop;a.style.top=`${E}px`,a.style.maxHeight=`${l}px`}else a.style.top=`${t.offsetTop}px`,a.style.maxHeight=`${t.offsetHeight}px`;a.style.height="8192px",a.offsetHeight}}}function M(t){const{value:a}=C;if(a)for(const o of t)a.style[o]=""}function G(){if(e.type==="card")return;const t=b();t&&L(t)}function le(t){var a;const o=(a=v.value)===null||a===void 0?void 0:a.$el;if(!o)return;const l=b();if(!l)return;const{scrollLeft:$,offsetWidth:E}=o,{offsetLeft:F,offsetWidth:N}=l;$>F?o.scrollTo({top:0,left:F,behavior:"smooth"}):F+N>$+E&&o.scrollTo({top:0,left:F+N-E,behavior:"smooth"})}const O=W(null);let J=0,j=null;function Re(t){const a=O.value;if(a){J=t.getBoundingClientRect().height;const o=`${J}px`,l=()=>{a.style.height=o,a.style.maxHeight=o};j?(l(),j(),j=null):j=l}}function ze(t){const a=O.value;if(a){const o=t.getBoundingClientRect().height,l=()=>{document.body.offsetHeight,a.style.maxHeight=`${o}px`,a.style.height=`${Math.max(J,o)}px`};j?(j(),j=null,l()):j=l}}function Le(){const t=O.value;if(t){t.style.maxHeight="",t.style.height="";const{paneWrapperStyle:a}=e;if(typeof a=="string")t.style.cssText=a;else if(a){const{maxHeight:o,height:l}=a;o!==void 0&&(t.style.maxHeight=o),l!==void 0&&(t.style.height=l)}}}const se={value:[]},de=W("next");function $e(t){const a=A.value;let o="next";for(const l of se.value){if(l===a)break;if(l===t){o="prev";break}}de.value=o,We(t)}function We(t){const{onActiveNameChange:a,onUpdateValue:o,"onUpdate:value":l}=e;a&&U(a,t),o&&U(o,t),l&&U(l,t),z.value=t}function Be(t){const{onClose:a}=e;a&&U(a,t)}function be(){const{value:t}=C;if(!t)return;const a="transition-disabled";t.classList.add(a),G(),t.classList.remove(a)}let ce=0;function _e(t){var a;if(t.contentRect.width===0&&t.contentRect.height===0||ce===t.contentRect.width)return;ce=t.contentRect.width;const{type:o}=e;(o==="line"||o==="bar")&&be(),o!=="segment"&&Q((a=v.value)===null||a===void 0?void 0:a.$el)}const Ae=re(_e,64);ee([()=>e.justifyContent,()=>e.size],()=>{te(()=>{const{type:t}=e;(t==="line"||t==="bar")&&be()})});const D=W(!1);function Ee(t){var a;const{target:o,contentRect:{width:l}}=t,$=o.parentElement.offsetWidth;if(!D.value)$<l&&(D.value=!0);else{const{value:E}=x;if(!E)return;$-l>E.$el.offsetWidth&&(D.value=!1)}Q((a=v.value)===null||a===void 0?void 0:a.$el)}const Ve=re(Ee,64);function ke(){const{onAdd:t}=e;t&&t(),te(()=>{const a=b(),{value:o}=v;!a||!o||o.scrollTo({left:a.offsetLeft,top:0,behavior:"smooth"})})}function Q(t){if(!t)return;const{placement:a}=e;if(a==="top"||a==="bottom"){const{scrollLeft:o,scrollWidth:l,offsetWidth:$}=t;w.value=o<=0,R.value=o+$>=l}else{const{scrollTop:o,scrollHeight:l,offsetHeight:$}=t;w.value=o<=0,R.value=o+$>=l}}const Me=re(t=>{Q(t.target)},64);St(ie,{triggerRef:H(e,"trigger"),tabStyleRef:H(e,"tabStyle"),paneClassRef:H(e,"paneClass"),paneStyleRef:H(e,"paneStyle"),mergedClsPrefixRef:u,typeRef:H(e,"type"),closableRef:H(e,"closable"),valueRef:A,tabChangeIdRef:V,onBeforeLeaveRef:H(e,"onBeforeLeave"),activateTab:$e,handleClose:Be,handleAdd:ke}),_t(()=>{G(),le()}),wt(()=>{const{value:t}=S;if(!t)return;const{value:a}=u,o=`${a}-tabs-nav-scroll-wrapper--shadow-start`,l=`${a}-tabs-nav-scroll-wrapper--shadow-end`;w.value?t.classList.remove(o):t.classList.add(o),R.value?t.classList.remove(l):t.classList.add(l)});const fe=W(null);ee(A,()=>{if(e.type==="segment"){const t=fe.value;t&&te(()=>{t.classList.add("transition-disabled"),t.offsetWidth,t.classList.remove("transition-disabled")})}});const je={syncBarPosition:()=>{G()}},pe=q(()=>{const{value:t}=P,{type:a}=e,o={card:"Card",bar:"Bar",line:"Line",segment:"Segment"}[a],l=`${t}${o}`,{self:{barColor:$,closeIconColor:E,closeIconColorHover:F,closeIconColorPressed:N,tabColor:Ge,tabBorderColor:He,paneTextColor:Ie,tabFontWeight:Fe,tabBorderRadius:Oe,tabFontWeightActive:De,colorSegment:Ne,fontWeightStrong:Xe,tabColorSegment:Ue,closeSize:Ye,closeIconSize:qe,closeColorHover:Ke,closeColorPressed:Je,closeBorderRadius:Qe,[k("panePadding",t)]:X,[k("tabPadding",l)]:Ze,[k("tabPaddingVertical",l)]:et,[k("tabGap",l)]:tt,[k("tabGap",`${l}Vertical`)]:at,[k("tabTextColor",a)]:rt,[k("tabTextColorActive",a)]:nt,[k("tabTextColorHover",a)]:ot,[k("tabTextColorDisabled",a)]:it,[k("tabFontSize",t)]:lt},common:{cubicBezierEaseInOut:st}}=y.value;return{"--n-bezier":st,"--n-color-segment":Ne,"--n-bar-color":$,"--n-tab-font-size":lt,"--n-tab-text-color":rt,"--n-tab-text-color-active":nt,"--n-tab-text-color-disabled":it,"--n-tab-text-color-hover":ot,"--n-pane-text-color":Ie,"--n-tab-border-color":He,"--n-tab-border-radius":Oe,"--n-close-size":Ye,"--n-close-icon-size":qe,"--n-close-color-hover":Ke,"--n-close-color-pressed":Je,"--n-close-border-radius":Qe,"--n-close-icon-color":E,"--n-close-icon-color-hover":F,"--n-close-icon-color-pressed":N,"--n-tab-color":Ge,"--n-tab-font-weight":Fe,"--n-tab-font-weight-active":De,"--n-tab-padding":Ze,"--n-tab-padding-vertical":et,"--n-tab-gap":tt,"--n-tab-gap-vertical":at,"--n-pane-padding-left":Y(X,"left"),"--n-pane-padding-right":Y(X,"right"),"--n-pane-padding-top":Y(X,"top"),"--n-pane-padding-bottom":Y(X,"bottom"),"--n-font-weight-strong":Xe,"--n-tab-color-segment":Ue}}),I=p?Tt("tabs",q(()=>`${P.value[0]}${e.type[0]}`),pe,e):void 0;return Object.assign({mergedClsPrefix:u,mergedValue:A,renderedNames:new Set,tabsRailElRef:fe,tabsPaneWrapperRef:O,tabsElRef:h,barElRef:C,addTabInstRef:x,xScrollInstRef:v,scrollWrapperElRef:S,addTabFixed:D,tabWrapperStyle:g,handleNavResize:Ae,mergedSize:P,handleScroll:Me,handleTabsResize:Ve,cssVars:p?void 0:pe,themeClass:I==null?void 0:I.themeClass,animationDirection:de,renderNameListRef:se,onAnimationBeforeLeave:Re,onAnimationEnter:ze,onAnimationAfterEnter:Le,onRender:I==null?void 0:I.onRender},je)},render(){const{mergedClsPrefix:e,type:n,placement:s,addTabFixed:f,addable:d,mergedSize:m,renderNameListRef:u,onRender:p,paneWrapperClass:y,paneWrapperStyle:h,$slots:{default:C,prefix:S,suffix:x}}=this;p==null||p();const v=C?Z(C()).filter(g=>g.type.__TAB_PANE__===!0):[],w=C?Z(C()).filter(g=>g.type.__TAB__===!0):[],R=!w.length,P=n==="card",_=n==="segment",z=!P&&!_&&this.justifyContent;u.value=[];const A=()=>{const g=c("div",{style:this.tabWrapperStyle,class:[`${e}-tabs-wrapper`]},z?null:c("div",{class:`${e}-tabs-scroll-padding`,style:{width:`${this.tabsPadding}px`}}),R?v.map((b,L)=>(u.value.push(b.props.name),ne(c(oe,Object.assign({},b.props,{internalCreatedByPane:!0,internalLeftPadded:L!==0&&(!z||z==="center"||z==="start"||z==="end")}),b.children?{default:b.children.tab}:void 0)))):w.map((b,L)=>(u.value.push(b.props.name),ne(L!==0&&!z?Ce(b):b))),!f&&d&&P?ye(d,(R?v.length:w.length)!==0):null,z?null:c("div",{class:`${e}-tabs-scroll-padding`,style:{width:`${this.tabsPadding}px`}}));return c("div",{ref:"tabsElRef",class:`${e}-tabs-nav-scroll-content`},P&&d?c(ge,{onResize:this.handleTabsResize},{default:()=>g}):g,P?c("div",{class:`${e}-tabs-pad`}):null,P?null:c("div",{ref:"barElRef",class:`${e}-tabs-bar`}))},V=_?"top":s;return c("div",{class:[`${e}-tabs`,this.themeClass,`${e}-tabs--${n}-type`,`${e}-tabs--${m}-size`,z&&`${e}-tabs--flex`,`${e}-tabs--${V}`],style:this.cssVars},c("div",{class:[`${e}-tabs-nav--${n}-type`,`${e}-tabs-nav--${V}`,`${e}-tabs-nav`]},ue(S,g=>g&&c("div",{class:`${e}-tabs-nav__prefix`},g)),_?c("div",{class:`${e}-tabs-rail`,ref:"tabsRailElRef"},R?v.map((g,b)=>(u.value.push(g.props.name),c(oe,Object.assign({},g.props,{internalCreatedByPane:!0,internalLeftPadded:b!==0}),g.children?{default:g.children.tab}:void 0))):w.map((g,b)=>(u.value.push(g.props.name),b===0?g:Ce(g)))):c(ge,{onResize:this.handleNavResize},{default:()=>c("div",{class:`${e}-tabs-nav-scroll-wrapper`,ref:"scrollWrapperElRef"},["top","bottom"].includes(V)?c(Et,{ref:"xScrollInstRef",onScroll:this.handleScroll},{default:A}):c("div",{class:`${e}-tabs-nav-y-scroll`,onScroll:this.handleScroll},A()))}),f&&d&&P?ye(d,!0):null,ue(x,g=>g&&c("div",{class:`${e}-tabs-nav__suffix`},g))),R&&(this.animated&&(V==="top"||V==="bottom")?c("div",{ref:"tabsPaneWrapperRef",style:h,class:[`${e}-tabs-pane-wrapper`,y]},me(v,this.mergedValue,this.renderedNames,this.onAnimationBeforeLeave,this.onAnimationEnter,this.onAnimationAfterEnter,this.animationDirection)):me(v,this.mergedValue,this.renderedNames)))}});function me(e,n,s,f,d,m,u){const p=[];return e.forEach(y=>{const{name:h,displayDirective:C,"display-directive":S}=y.props,x=w=>C===w||S===w,v=n===h;if(y.key!==void 0&&(y.key=h),v||x("show")||x("show:lazy")&&s.has(h)){s.has(h)||s.add(h);const w=!x("if");p.push(w?Pt(y,[[Rt,v]]):y)}}),u?c(zt,{name:`${u}-transition`,onBeforeLeave:f,onEnter:d,onAfterEnter:m},{default:()=>p}):p}function ye(e,n){return c(oe,{ref:"addTabInstRef",key:"__addable",name:"__addable",internalCreatedByPane:!0,internalAddable:!0,internalLeftPadded:n,disabled:typeof e=="object"&&e.disabled})}function Ce(e){const n=Lt(e);return n.props?n.props.internalLeftPadded=!0:n.props={internalLeftPadded:!0},n}function ne(e){return Array.isArray(e.dynamicProps)?e.dynamicProps.includes("internalLeftPadded")||e.dynamicProps.push("internalLeftPadded"):e.dynamicProps=["internalLeftPadded"],e}export{Qt as _,Zt as a};
