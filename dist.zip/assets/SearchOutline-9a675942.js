import{bS as k,c as $,bT as O,bj as p,aX as B,b as g,d as C,e as y,g as f,r as S,u as _,aU as P,bL as E,h as m,i as I,j as v,bM as V,aV as F,bU as H,aW as M,aC as N,aD as D,aF as T}from"./index-b27597f8.js";const K=o=>{const{baseColor:e,textColor2:r,bodyColor:i,cardColor:n,dividerColor:t,actionColor:h,scrollbarColor:d,scrollbarColorHover:l,invertedColor:c}=o;return{textColor:r,textColorInverted:"#FFF",color:i,colorEmbedded:h,headerColor:n,headerColorInverted:c,footerColor:h,footerColorInverted:c,headerBorderColor:t,headerBorderColorInverted:c,footerBorderColor:t,footerBorderColorInverted:c,siderBorderColor:t,siderBorderColorInverted:c,siderColor:n,siderColorInverted:c,siderToggleButtonBorder:`1px solid ${t}`,siderToggleButtonColor:e,siderToggleButtonIconColor:r,siderToggleButtonIconColorInverted:r,siderToggleBarColor:p(i,d),siderToggleBarColorHover:p(i,l),__invertScrollbar:"true"}},A=k({name:"Layout",common:$,peers:{Scrollbar:O},self:K}),w=A,re=B("n-layout-sider"),R={type:String,default:"static"},U=g("layout",`
 color: var(--n-text-color);
 background-color: var(--n-color);
 box-sizing: border-box;
 position: relative;
 z-index: auto;
 flex: auto;
 overflow: hidden;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
`,[g("layout-scroll-container",`
 overflow-x: hidden;
 box-sizing: border-box;
 height: 100%;
 `),C("absolute-positioned",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),W={embedded:Boolean,position:R,nativeScrollbar:{type:Boolean,default:!0},scrollbarProps:Object,onScroll:Function,contentStyle:{type:[String,Object],default:""},hasSider:Boolean,siderPlacement:{type:String,default:"left"}},X=B("n-layout");function Y(o){return y({name:o?"LayoutContent":"Layout",props:Object.assign(Object.assign({},f.props),W),setup(e){const r=S(null),i=S(null),{mergedClsPrefixRef:n,inlineThemeDisabled:t}=_(e),h=f("Layout","-layout",U,w,e,n);function d(s,a){if(e.nativeScrollbar){const{value:u}=r;u&&(a===void 0?u.scrollTo(s):u.scrollTo(s,a))}else{const{value:u}=i;u&&u.scrollTo(s,a)}}P(X,e);let l=0,c=0;const z=s=>{var a;const u=s.target;l=u.scrollLeft,c=u.scrollTop,(a=e.onScroll)===null||a===void 0||a.call(e,s)};E(()=>{if(e.nativeScrollbar){const s=r.value;s&&(s.scrollTop=c,s.scrollLeft=l)}});const L={display:"flex",flexWrap:"nowrap",width:"100%",flexDirection:"row"},j={scrollTo:d},x=m(()=>{const{common:{cubicBezierEaseInOut:s},self:a}=h.value;return{"--n-bezier":s,"--n-color":e.embedded?a.colorEmbedded:a.color,"--n-text-color":a.textColor}}),b=t?I("layout",m(()=>e.embedded?"e":""),x,e):void 0;return Object.assign({mergedClsPrefix:n,scrollableElRef:r,scrollbarInstRef:i,hasSiderStyle:L,mergedTheme:h,handleNativeElScroll:z,cssVars:t?void 0:x,themeClass:b==null?void 0:b.themeClass,onRender:b==null?void 0:b.onRender},j)},render(){var e;const{mergedClsPrefix:r,hasSider:i}=this;(e=this.onRender)===null||e===void 0||e.call(this);const n=i?this.hasSiderStyle:void 0,t=[this.themeClass,o&&`${r}-layout-content`,`${r}-layout`,`${r}-layout--${this.position}-positioned`];return v("div",{class:t,style:this.cssVars},this.nativeScrollbar?v("div",{ref:"scrollableElRef",class:`${r}-layout-scroll-container`,style:[this.contentStyle,n],onScroll:this.handleNativeElScroll},this.$slots):v(V,Object.assign({},this.scrollbarProps,{onScroll:this.onScroll,ref:"scrollbarInstRef",theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar,contentStyle:[this.contentStyle,n]}),this.$slots))}})}const te=Y(!1),q=g("layout-header",`
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 box-sizing: border-box;
 width: 100%;
 background-color: var(--n-color);
 color: var(--n-text-color);
`,[C("absolute-positioned",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 `),C("bordered",`
 border-bottom: solid 1px var(--n-border-color);
 `)]),G={position:R,inverted:Boolean,bordered:{type:Boolean,default:!1}},le=y({name:"LayoutHeader",props:Object.assign(Object.assign({},f.props),G),setup(o){const{mergedClsPrefixRef:e,inlineThemeDisabled:r}=_(o),i=f("Layout","-layout-header",q,w,o,e),n=m(()=>{const{common:{cubicBezierEaseInOut:h},self:d}=i.value,l={"--n-bezier":h};return o.inverted?(l["--n-color"]=d.headerColorInverted,l["--n-text-color"]=d.textColorInverted,l["--n-border-color"]=d.headerBorderColorInverted):(l["--n-color"]=d.headerColor,l["--n-text-color"]=d.textColor,l["--n-border-color"]=d.headerBorderColor),l}),t=r?I("layout-header",m(()=>o.inverted?"a":"b"),n,o):void 0;return{mergedClsPrefix:e,cssVars:r?void 0:n,themeClass:t==null?void 0:t.themeClass,onRender:t==null?void 0:t.onRender}},render(){var o;const{mergedClsPrefix:e}=this;return(o=this.onRender)===null||o===void 0||o.call(this),v("div",{class:[`${e}-layout-header`,this.themeClass,this.position&&`${e}-layout-header--${this.position}-positioned`,this.bordered&&`${e}-layout-header--bordered`],style:this.cssVars},this.$slots)}});function se(){const o=F(H,null);return o===null&&M("use-loading-bar","No outer <n-loading-bar-provider /> founded."),o}const J={xmlns:"http://www.w3.org/2000/svg","xmlns:xlink":"http://www.w3.org/1999/xlink",viewBox:"0 0 512 512"},Q=T("path",{d:"M221.09 64a157.09 157.09 0 1 0 157.09 157.09A157.1 157.1 0 0 0 221.09 64z",fill:"none",stroke:"currentColor","stroke-miterlimit":"10","stroke-width":"32"},null,-1),Z=T("path",{fill:"none",stroke:"currentColor","stroke-linecap":"round","stroke-miterlimit":"10","stroke-width":"32",d:"M338.29 338.29L448 448"},null,-1),ee=[Q,Z],ne=y({name:"SearchOutline",render:function(e,r){return N(),D("svg",J,ee)}});export{ne as S,le as _,re as a,w as b,te as c,Y as d,X as l,R as p,se as u};
