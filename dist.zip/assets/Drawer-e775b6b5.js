import{bS as ue,c as he,bT as fe,e as X,r as E,aV as me,dh as Y,h as z,u as V,bD as ge,w as be,b2 as ve,a_ as pe,di as we,aU as D,cy as ye,cz as ze,cx as xe,b7 as L,b8 as U,j as h,d1 as $e,T as q,c4 as Se,bM as Be,ci as Ce,a as n,bs as O,b as u,d as w,a$ as C,f as Ee,ch as ke,g as K,b0 as N,dj as Re,i as Te,cE as He,dk as Fe,bE as S,cD as Me}from"./index-b27597f8.js";import{a as j}from"./Popover-61edb1a7.js";import{f as _}from"./format-length-c9d165c6.js";const Ie=e=>{const{modalColor:r,textColor1:t,textColor2:v,boxShadow3:f,lineHeight:y,fontWeightStrong:c,dividerColor:g,closeColorHover:b,closeColorPressed:x,closeIconColor:k,closeIconColorHover:R,closeIconColorPressed:T,borderRadius:H,primaryColorHover:F}=e;return{bodyPadding:"16px 24px",headerPadding:"16px 24px",footerPadding:"16px 24px",color:r,textColor:v,titleTextColor:t,titleFontSize:"18px",titleFontWeight:c,boxShadow:f,lineHeight:y,headerBorderBottom:`1px solid ${g}`,footerBorderTop:`1px solid ${g}`,closeIconColor:k,closeIconColorHover:R,closeIconColorPressed:T,closeSize:"22px",closeIconSize:"18px",closeColorHover:b,closeColorPressed:x,closeBorderRadius:H,resizableTriggerColorHover:F}},De=ue({name:"Drawer",common:he,peers:{Scrollbar:fe},self:Ie}),Oe=De,Pe=X({name:"NDrawerContent",inheritAttrs:!1,props:{blockScroll:Boolean,show:{type:Boolean,default:void 0},displayDirective:{type:String,required:!0},placement:{type:String,required:!0},contentStyle:[Object,String],nativeScrollbar:{type:Boolean,required:!0},scrollbarProps:Object,trapFocus:{type:Boolean,default:!0},autoFocus:{type:Boolean,default:!0},showMask:{type:[Boolean,String],required:!0},maxWidth:Number,maxHeight:Number,minWidth:Number,minHeight:Number,resizable:Boolean,onClickoutside:Function,onAfterLeave:Function,onAfterEnter:Function,onEsc:Function},setup(e){const r=E(!!e.show),t=E(null),v=me(Y);let f=0,y="",c=null;const g=E(!1),b=E(!1),x=z(()=>e.placement==="top"||e.placement==="bottom"),{mergedClsPrefixRef:k,mergedRtlRef:R}=V(e),T=ge("Drawer",R,k),H=i=>{b.value=!0,f=x.value?i.clientY:i.clientX,y=document.body.style.cursor,document.body.style.cursor=x.value?"ns-resize":"ew-resize",document.body.addEventListener("mousemove",p),document.body.addEventListener("mouseleave",s),document.body.addEventListener("mouseup",o)},F=()=>{c!==null&&(window.clearTimeout(c),c=null),b.value?g.value=!0:c=window.setTimeout(()=>{g.value=!0},300)},P=()=>{c!==null&&(window.clearTimeout(c),c=null),g.value=!1},{doUpdateHeight:W,doUpdateWidth:A}=v,M=i=>{const{maxWidth:a}=e;if(a&&i>a)return a;const{minWidth:d}=e;return d&&i<d?d:i},I=i=>{const{maxHeight:a}=e;if(a&&i>a)return a;const{minHeight:d}=e;return d&&i<d?d:i},p=i=>{var a,d;if(b.value)if(x.value){let m=((a=t.value)===null||a===void 0?void 0:a.offsetHeight)||0;const $=f-i.clientY;m+=e.placement==="bottom"?$:-$,m=I(m),W(m),f=i.clientY}else{let m=((d=t.value)===null||d===void 0?void 0:d.offsetWidth)||0;const $=f-i.clientX;m+=e.placement==="right"?$:-$,m=M(m),A(m),f=i.clientX}},o=()=>{b.value&&(f=0,b.value=!1,document.body.style.cursor=y,document.body.removeEventListener("mousemove",p),document.body.removeEventListener("mouseup",o),document.body.removeEventListener("mouseleave",s))},s=o;be(()=>{e.show&&(r.value=!0)}),ve(()=>e.show,i=>{i||o()}),pe(()=>{o()});const l=z(()=>{const{show:i}=e,a=[[U,i]];return e.showMask||a.push([Ce,e.onClickoutside,void 0,{capture:!0}]),a});function B(){var i;r.value=!1,(i=e.onAfterLeave)===null||i===void 0||i.call(e)}return we(z(()=>e.blockScroll&&r.value)),D(ye,t),D(ze,null),D(xe,null),{bodyRef:t,rtlEnabled:T,mergedClsPrefix:v.mergedClsPrefixRef,isMounted:v.isMountedRef,mergedTheme:v.mergedThemeRef,displayed:r,transitionName:z(()=>({right:"slide-in-from-right-transition",left:"slide-in-from-left-transition",top:"slide-in-from-top-transition",bottom:"slide-in-from-bottom-transition"})[e.placement]),handleAfterLeave:B,bodyDirectives:l,handleMousedownResizeTrigger:H,handleMouseenterResizeTrigger:F,handleMouseleaveResizeTrigger:P,isDragging:b,isHoverOnResizeTrigger:g}},render(){const{$slots:e,mergedClsPrefix:r}=this;return this.displayDirective==="show"||this.displayed||this.show?L(h("div",{role:"none"},h($e,{disabled:!this.showMask||!this.trapFocus,active:this.show,autoFocus:this.autoFocus,onEsc:this.onEsc},{default:()=>h(q,{name:this.transitionName,appear:this.isMounted,onAfterEnter:this.onAfterEnter,onAfterLeave:this.handleAfterLeave},{default:()=>L(h("div",Se(this.$attrs,{role:"dialog",ref:"bodyRef","aria-modal":"true",class:[`${r}-drawer`,this.rtlEnabled&&`${r}-drawer--rtl`,`${r}-drawer--${this.placement}-placement`,this.isDragging&&`${r}-drawer--unselectable`,this.nativeScrollbar&&`${r}-drawer--native-scrollbar`]}),[this.resizable?h("div",{class:[`${r}-drawer__resize-trigger`,(this.isDragging||this.isHoverOnResizeTrigger)&&`${r}-drawer__resize-trigger--hover`],onMouseenter:this.handleMouseenterResizeTrigger,onMouseleave:this.handleMouseleaveResizeTrigger,onMousedown:this.handleMousedownResizeTrigger}):null,this.nativeScrollbar?h("div",{class:`${r}-drawer-content-wrapper`,style:this.contentStyle,role:"none"},e):h(Be,Object.assign({},this.scrollbarProps,{contentStyle:this.contentStyle,contentClass:`${r}-drawer-content-wrapper`,theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar}),e)]),this.bodyDirectives)})})),[[U,this.displayDirective==="if"||this.displayed||this.show]]):null}}),{cubicBezierEaseIn:We,cubicBezierEaseOut:Ae}=O;function Le({duration:e="0.3s",leaveDuration:r="0.2s",name:t="slide-in-from-right"}={}){return[n(`&.${t}-transition-leave-active`,{transition:`transform ${r} ${We}`}),n(`&.${t}-transition-enter-active`,{transition:`transform ${e} ${Ae}`}),n(`&.${t}-transition-enter-to`,{transform:"translateX(0)"}),n(`&.${t}-transition-enter-from`,{transform:"translateX(100%)"}),n(`&.${t}-transition-leave-from`,{transform:"translateX(0)"}),n(`&.${t}-transition-leave-to`,{transform:"translateX(100%)"})]}const{cubicBezierEaseIn:Ue,cubicBezierEaseOut:Ne}=O;function je({duration:e="0.3s",leaveDuration:r="0.2s",name:t="slide-in-from-left"}={}){return[n(`&.${t}-transition-leave-active`,{transition:`transform ${r} ${Ue}`}),n(`&.${t}-transition-enter-active`,{transition:`transform ${e} ${Ne}`}),n(`&.${t}-transition-enter-to`,{transform:"translateX(0)"}),n(`&.${t}-transition-enter-from`,{transform:"translateX(-100%)"}),n(`&.${t}-transition-leave-from`,{transform:"translateX(0)"}),n(`&.${t}-transition-leave-to`,{transform:"translateX(-100%)"})]}const{cubicBezierEaseIn:_e,cubicBezierEaseOut:Xe}=O;function Ye({duration:e="0.3s",leaveDuration:r="0.2s",name:t="slide-in-from-top"}={}){return[n(`&.${t}-transition-leave-active`,{transition:`transform ${r} ${_e}`}),n(`&.${t}-transition-enter-active`,{transition:`transform ${e} ${Xe}`}),n(`&.${t}-transition-enter-to`,{transform:"translateY(0)"}),n(`&.${t}-transition-enter-from`,{transform:"translateY(-100%)"}),n(`&.${t}-transition-leave-from`,{transform:"translateY(0)"}),n(`&.${t}-transition-leave-to`,{transform:"translateY(-100%)"})]}const{cubicBezierEaseIn:Ve,cubicBezierEaseOut:qe}=O;function Ke({duration:e="0.3s",leaveDuration:r="0.2s",name:t="slide-in-from-bottom"}={}){return[n(`&.${t}-transition-leave-active`,{transition:`transform ${r} ${Ve}`}),n(`&.${t}-transition-enter-active`,{transition:`transform ${e} ${qe}`}),n(`&.${t}-transition-enter-to`,{transform:"translateY(0)"}),n(`&.${t}-transition-enter-from`,{transform:"translateY(100%)"}),n(`&.${t}-transition-leave-from`,{transform:"translateY(0)"}),n(`&.${t}-transition-leave-to`,{transform:"translateY(100%)"})]}const Ge=n([u("drawer",`
 word-break: break-word;
 line-height: var(--n-line-height);
 position: absolute;
 pointer-events: all;
 box-shadow: var(--n-box-shadow);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 background-color: var(--n-color);
 color: var(--n-text-color);
 box-sizing: border-box;
 `,[Le(),je(),Ye(),Ke(),w("unselectable",`
 user-select: none; 
 -webkit-user-select: none;
 `),w("native-scrollbar",[u("drawer-content-wrapper",`
 overflow: auto;
 height: 100%;
 `)]),C("resize-trigger",`
 position: absolute;
 background-color: #0000;
 transition: background-color .3s var(--n-bezier);
 `,[w("hover",`
 background-color: var(--n-resize-trigger-color-hover);
 `)]),u("drawer-content-wrapper",`
 box-sizing: border-box;
 `),u("drawer-content",`
 height: 100%;
 display: flex;
 flex-direction: column;
 `,[w("native-scrollbar",[u("drawer-body-content-wrapper",`
 height: 100%;
 overflow: auto;
 `)]),u("drawer-body",`
 flex: 1 0 0;
 overflow: hidden;
 `),u("drawer-body-content-wrapper",`
 box-sizing: border-box;
 padding: var(--n-body-padding);
 `),u("drawer-header",`
 font-weight: var(--n-title-font-weight);
 line-height: 1;
 font-size: var(--n-title-font-size);
 color: var(--n-title-text-color);
 padding: var(--n-header-padding);
 transition: border .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-divider-color);
 border-bottom: var(--n-header-border-bottom);
 display: flex;
 justify-content: space-between;
 align-items: center;
 `,[C("close",`
 margin-left: 6px;
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `)]),u("drawer-footer",`
 display: flex;
 justify-content: flex-end;
 border-top: var(--n-footer-border-top);
 transition: border .3s var(--n-bezier);
 padding: var(--n-footer-padding);
 `)]),w("right-placement",`
 top: 0;
 bottom: 0;
 right: 0;
 `,[C("resize-trigger",`
 width: 3px;
 height: 100%;
 top: 0;
 left: 0;
 transform: translateX(-1.5px);
 cursor: ew-resize;
 `)]),w("left-placement",`
 top: 0;
 bottom: 0;
 left: 0;
 `,[C("resize-trigger",`
 width: 3px;
 height: 100%;
 top: 0;
 right: 0;
 transform: translateX(1.5px);
 cursor: ew-resize;
 `)]),w("top-placement",`
 top: 0;
 left: 0;
 right: 0;
 `,[C("resize-trigger",`
 width: 100%;
 height: 3px;
 bottom: 0;
 left: 0;
 transform: translateY(1.5px);
 cursor: ns-resize;
 `)]),w("bottom-placement",`
 left: 0;
 bottom: 0;
 right: 0;
 `,[C("resize-trigger",`
 width: 100%;
 height: 3px;
 top: 0;
 left: 0;
 transform: translateY(-1.5px);
 cursor: ns-resize;
 `)])]),n("body",[n(">",[u("drawer-container",{position:"fixed"})])]),u("drawer-container",`
 position: relative;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 `,[n("> *",{pointerEvents:"all"})]),u("drawer-mask",`
 background-color: rgba(0, 0, 0, .3);
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `,[w("invisible",`
 background-color: rgba(0, 0, 0, 0)
 `),Ee({enterDuration:"0.2s",leaveDuration:"0.2s",enterCubicBezier:"var(--n-bezier-in)",leaveCubicBezier:"var(--n-bezier-out)"})])]),Je=Object.assign(Object.assign({},K.props),{show:Boolean,width:[Number,String],height:[Number,String],placement:{type:String,default:"right"},maskClosable:{type:Boolean,default:!0},showMask:{type:[Boolean,String],default:!0},to:[String,Object],displayDirective:{type:String,default:"if"},nativeScrollbar:{type:Boolean,default:!0},zIndex:Number,onMaskClick:Function,scrollbarProps:Object,contentStyle:[Object,String],trapFocus:{type:Boolean,default:!0},onEsc:Function,autoFocus:{type:Boolean,default:!0},closeOnEsc:{type:Boolean,default:!0},blockScroll:{type:Boolean,default:!0},maxWidth:Number,maxHeight:Number,minWidth:Number,minHeight:Number,resizable:Boolean,defaultWidth:{type:[Number,String],default:251},defaultHeight:{type:[Number,String],default:251},onUpdateWidth:[Function,Array],onUpdateHeight:[Function,Array],"onUpdate:width":[Function,Array],"onUpdate:height":[Function,Array],"onUpdate:show":[Function,Array],onUpdateShow:[Function,Array],onAfterEnter:Function,onAfterLeave:Function,drawerStyle:[String,Object],drawerClass:String,target:null,onShow:Function,onHide:Function}),tt=X({name:"Drawer",inheritAttrs:!1,props:Je,setup(e){const{mergedClsPrefixRef:r,namespaceRef:t,inlineThemeDisabled:v}=V(e),f=ke(),y=K("Drawer","-drawer",Ge,Oe,e,r),c=E(e.defaultWidth),g=E(e.defaultHeight),b=j(N(e,"width"),c),x=j(N(e,"height"),g),k=z(()=>{const{placement:o}=e;return o==="top"||o==="bottom"?"":_(b.value)}),R=z(()=>{const{placement:o}=e;return o==="left"||o==="right"?"":_(x.value)}),T=o=>{const{onUpdateWidth:s,"onUpdate:width":l}=e;s&&S(s,o),l&&S(l,o),c.value=o},H=o=>{const{onUpdateHeight:s,"onUpdate:width":l}=e;s&&S(s,o),l&&S(l,o),g.value=o},F=z(()=>[{width:k.value,height:R.value},e.drawerStyle||""]);function P(o){const{onMaskClick:s,maskClosable:l}=e;l&&M(!1),s&&s(o)}const W=Re();function A(o){var s;(s=e.onEsc)===null||s===void 0||s.call(e),e.show&&e.closeOnEsc&&Fe(o)&&!W.value&&M(!1)}function M(o){const{onHide:s,onUpdateShow:l,"onUpdate:show":B}=e;l&&S(l,o),B&&S(B,o),s&&!o&&S(s,o)}D(Y,{isMountedRef:f,mergedThemeRef:y,mergedClsPrefixRef:r,doUpdateShow:M,doUpdateHeight:H,doUpdateWidth:T});const I=z(()=>{const{common:{cubicBezierEaseInOut:o,cubicBezierEaseIn:s,cubicBezierEaseOut:l},self:{color:B,textColor:i,boxShadow:a,lineHeight:d,headerPadding:m,footerPadding:$,bodyPadding:G,titleFontSize:J,titleTextColor:Q,titleFontWeight:Z,headerBorderBottom:ee,footerBorderTop:te,closeIconColor:re,closeIconColorHover:oe,closeIconColorPressed:ne,closeColorHover:ie,closeColorPressed:se,closeIconSize:ae,closeSize:le,closeBorderRadius:de,resizableTriggerColorHover:ce}}=y.value;return{"--n-line-height":d,"--n-color":B,"--n-text-color":i,"--n-box-shadow":a,"--n-bezier":o,"--n-bezier-out":l,"--n-bezier-in":s,"--n-header-padding":m,"--n-body-padding":G,"--n-footer-padding":$,"--n-title-text-color":Q,"--n-title-font-size":J,"--n-title-font-weight":Z,"--n-header-border-bottom":ee,"--n-footer-border-top":te,"--n-close-icon-color":re,"--n-close-icon-color-hover":oe,"--n-close-icon-color-pressed":ne,"--n-close-size":le,"--n-close-color-hover":ie,"--n-close-color-pressed":se,"--n-close-icon-size":ae,"--n-close-border-radius":de,"--n-resize-trigger-color-hover":ce}}),p=v?Te("drawer",void 0,I,e):void 0;return{mergedClsPrefix:r,namespace:t,mergedBodyStyle:F,handleMaskClick:P,handleEsc:A,mergedTheme:y,cssVars:v?void 0:I,themeClass:p==null?void 0:p.themeClass,onRender:p==null?void 0:p.onRender,isMounted:f}},render(){const{mergedClsPrefix:e}=this;return h(He,{to:this.to,show:this.show},{default:()=>{var r;return(r=this.onRender)===null||r===void 0||r.call(this),L(h("div",{class:[`${e}-drawer-container`,this.namespace,this.themeClass],style:this.cssVars,role:"none"},this.showMask?h(q,{name:"fade-in-transition",appear:this.isMounted},{default:()=>this.show?h("div",{"aria-hidden":!0,class:[`${e}-drawer-mask`,this.showMask==="transparent"&&`${e}-drawer-mask--invisible`],onClick:this.handleMaskClick}):null}):null,h(Pe,Object.assign({},this.$attrs,{class:[this.drawerClass,this.$attrs.class],style:[this.mergedBodyStyle,this.$attrs.style],blockScroll:this.blockScroll,contentStyle:this.contentStyle,placement:this.placement,scrollbarProps:this.scrollbarProps,show:this.show,displayDirective:this.displayDirective,nativeScrollbar:this.nativeScrollbar,onAfterEnter:this.onAfterEnter,onAfterLeave:this.onAfterLeave,trapFocus:this.trapFocus,autoFocus:this.autoFocus,resizable:this.resizable,maxHeight:this.maxHeight,minHeight:this.minHeight,maxWidth:this.maxWidth,minWidth:this.minWidth,showMask:this.showMask,onEsc:this.handleEsc,onClickoutside:this.handleMaskClick}),this.$slots)),[[Me,{zIndex:this.zIndex,enabled:this.show}]])}})}});export{tt as _};
