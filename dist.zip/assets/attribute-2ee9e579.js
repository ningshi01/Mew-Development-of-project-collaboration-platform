function e(t){switch(typeof t){case"string":return t||void 0;case"number":return String(t);default:return}}export{e as g};
