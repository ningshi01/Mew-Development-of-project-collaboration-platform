import{b8 as re,cw as ot,h as D,r as N,a_ as it,da as de,j as o,aX as Ie,e as V,aV as ie,p as oe,bi as nt,u as ye,bH as le,aA as Oe,aU as ze,b0 as A,bY as at,c4 as we,b5 as lt,b4 as st,aT as xe,c as Ae,bS as dt,c2 as ut,bK as ct,a as U,b as m,d as I,bI as Y,db as Ge,dc as Ue,co as $e,dd as Me,g as he,k as Ce,i as Ee,aW as me,bm as ft,bG as Fe,w as pt,aN as J,c1 as gt,bv as ht,bC as Re,a$ as H,c0 as mt,b$ as vt,de as bt,aJ as ge,bt as ke,b3 as yt,bE as Se,az as wt,be as xt,aK as Ct,bP as Rt,bN as kt,aC as Q,aD as K,aG as M,aI as $,aF as y,aM as B,aE as St,bw as Z,bg as Be,bx as _e,b7 as fe,by as Bt,aO as _t,cs as Te,bh as De,aL as F,aP as Tt,aQ as Dt}from"./index-b27597f8.js";import{w as Pe,H as Pt,I as Lt,J as jt,K as Nt}from"./index-eb756369.js";import{b as It,a as Ot,_ as zt}from"./Popover-61edb1a7.js";import{g as At}from"./get-slot-1efb97e5.js";import{g as Gt,a as We,_ as Ut,d as $t,N as Mt,b as se,e as Et,m as Ft,f as Wt}from"./Image-1a0c3b52.js";import{A as Vt}from"./Add-a453005a.js";import{f as ee}from"./format-length-c9d165c6.js";import{E as Ht,N as Zt}from"./Input-f8b5fbf4.js";import{u as Yt}from"./use-message-cf8630a3.js";import{N as Xt}from"./Divider-f8fc66cc.js";import{a as qt}from"./headers-87eb3e56.js";import{_ as Qt}from"./DrawerContent-f16998e5.js";import{_ as Jt}from"./Drawer-e775b6b5.js";import"./Tooltip-a25626bb.js";import"./use-locale-c044757c.js";import"./light-5e5d12e6.js";function Kt(e){if(typeof e=="number")return{"":e.toString()};const r={};return e.split(/ +/).forEach(i=>{if(i==="")return;const[t,n]=i.split(":");n===void 0?r[""]=t:r[t]=n}),r}function te(e,r){var i;if(e==null)return;const t=Kt(e);if(r===void 0)return t[""];if(typeof r=="string")return(i=t[r])!==null&&i!==void 0?i:t[""];if(Array.isArray(r)){for(let n=r.length-1;n>=0;--n){const l=r[n];if(l in t)return t[l]}return t[""]}else{let n,l=-1;return Object.keys(t).forEach(s=>{const c=Number(s);!Number.isNaN(c)&&r>=c&&c>=l&&(l=c,n=t[s])}),n}}function er(e){var r;const i=(r=e.dirs)===null||r===void 0?void 0:r.find(({dir:t})=>t===re);return!!(i&&i.value===!1)}const tr={xs:0,s:640,m:1024,l:1280,xl:1536,"2xl":1920};function rr(e){return`(min-width: ${e}px)`}const ae={};function or(e=tr){if(!ot)return D(()=>[]);if(typeof window.matchMedia!="function")return D(()=>[]);const r=N({}),i=Object.keys(e),t=(n,l)=>{n.matches?r.value[l]=!0:r.value[l]=!1};return i.forEach(n=>{const l=e[n];let s,c;ae[l]===void 0?(s=window.matchMedia(rr(l)),s.addEventListener?s.addEventListener("change",d=>{c.forEach(a=>{a(d,n)})}):s.addListener&&s.addListener(d=>{c.forEach(a=>{a(d,n)})}),c=new Set,ae[l]={mql:s,cbs:c}):(s=ae[l].mql,c=ae[l].cbs),c.add(t),s.matches&&c.forEach(d=>{d(s,n)})}),it(()=>{i.forEach(n=>{const{cbs:l}=ae[e[n]];l.has(t)&&l.delete(t)})}),D(()=>{const{value:n}=r;return i.filter(l=>n[l])})}const ir=de("attach",o("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},o("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},o("g",{fill:"currentColor","fill-rule":"nonzero"},o("path",{d:"M3.25735931,8.70710678 L7.85355339,4.1109127 C8.82986412,3.13460197 10.4127766,3.13460197 11.3890873,4.1109127 C12.365398,5.08722343 12.365398,6.67013588 11.3890873,7.64644661 L6.08578644,12.9497475 C5.69526215,13.3402718 5.06209717,13.3402718 4.67157288,12.9497475 C4.28104858,12.5592232 4.28104858,11.9260582 4.67157288,11.5355339 L9.97487373,6.23223305 C10.1701359,6.0369709 10.1701359,5.72038841 9.97487373,5.52512627 C9.77961159,5.32986412 9.4630291,5.32986412 9.26776695,5.52512627 L3.96446609,10.8284271 C3.18341751,11.6094757 3.18341751,12.8758057 3.96446609,13.6568542 C4.74551468,14.4379028 6.01184464,14.4379028 6.79289322,13.6568542 L12.0961941,8.35355339 C13.4630291,6.98671837 13.4630291,4.77064094 12.0961941,3.40380592 C10.7293591,2.0369709 8.51328163,2.0369709 7.14644661,3.40380592 L2.55025253,8 C2.35499039,8.19526215 2.35499039,8.51184464 2.55025253,8.70710678 C2.74551468,8.90236893 3.06209717,8.90236893 3.25735931,8.70710678 Z"}))))),nr=de("trash",o("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},o("path",{d:"M432,144,403.33,419.74A32,32,0,0,1,371.55,448H140.46a32,32,0,0,1-31.78-28.26L80,144",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),o("rect",{x:"32",y:"64",width:"448",height:"80",rx:"16",ry:"16",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),o("line",{x1:"312",y1:"240",x2:"200",y2:"352",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),o("line",{x1:"312",y1:"352",x2:"200",y2:"240",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),ar=de("download",o("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},o("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},o("g",{fill:"currentColor","fill-rule":"nonzero"},o("path",{d:"M3.5,13 L12.5,13 C12.7761424,13 13,13.2238576 13,13.5 C13,13.7454599 12.8231248,13.9496084 12.5898756,13.9919443 L12.5,14 L3.5,14 C3.22385763,14 3,13.7761424 3,13.5 C3,13.2545401 3.17687516,13.0503916 3.41012437,13.0080557 L3.5,13 L12.5,13 L3.5,13 Z M7.91012437,1.00805567 L8,1 C8.24545989,1 8.44960837,1.17687516 8.49194433,1.41012437 L8.5,1.5 L8.5,10.292 L11.1819805,7.6109127 C11.3555469,7.43734635 11.6249713,7.4180612 11.8198394,7.55305725 L11.8890873,7.6109127 C12.0626536,7.78447906 12.0819388,8.05390346 11.9469427,8.2487716 L11.8890873,8.31801948 L8.35355339,11.8535534 C8.17998704,12.0271197 7.91056264,12.0464049 7.7156945,11.9114088 L7.64644661,11.8535534 L4.1109127,8.31801948 C3.91565056,8.12275734 3.91565056,7.80617485 4.1109127,7.6109127 C4.28447906,7.43734635 4.55390346,7.4180612 4.7487716,7.55305725 L4.81801948,7.6109127 L7.5,10.292 L7.5,1.5 C7.5,1.25454011 7.67687516,1.05039163 7.91012437,1.00805567 L8,1 L7.91012437,1.00805567 Z"}))))),lr=de("cancel",o("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},o("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},o("g",{fill:"currentColor","fill-rule":"nonzero"},o("path",{d:"M2.58859116,2.7156945 L2.64644661,2.64644661 C2.82001296,2.47288026 3.08943736,2.45359511 3.2843055,2.58859116 L3.35355339,2.64644661 L8,7.293 L12.6464466,2.64644661 C12.8417088,2.45118446 13.1582912,2.45118446 13.3535534,2.64644661 C13.5488155,2.84170876 13.5488155,3.15829124 13.3535534,3.35355339 L8.707,8 L13.3535534,12.6464466 C13.5271197,12.820013 13.5464049,13.0894374 13.4114088,13.2843055 L13.3535534,13.3535534 C13.179987,13.5271197 12.9105626,13.5464049 12.7156945,13.4114088 L12.6464466,13.3535534 L8,8.707 L3.35355339,13.3535534 C3.15829124,13.5488155 2.84170876,13.5488155 2.64644661,13.3535534 C2.45118446,13.1582912 2.45118446,12.8417088 2.64644661,12.6464466 L7.293,8 L2.64644661,3.35355339 C2.47288026,3.17998704 2.45359511,2.91056264 2.58859116,2.7156945 L2.64644661,2.64644661 L2.58859116,2.7156945 Z"}))))),sr=de("retry",o("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},o("path",{d:"M320,146s24.36-12-64-12A160,160,0,1,0,416,294",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-miterlimit: 10; stroke-width: 32px;"}),o("polyline",{points:"256 58 336 138 256 218",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),Le=1,Ve=Ie("n-grid"),He=1,dr={span:{type:[Number,String],default:He},offset:{type:[Number,String],default:0},suffix:Boolean,privateOffset:Number,privateSpan:Number,privateColStart:Number,privateShow:{type:Boolean,default:!0}},ve=V({__GRID_ITEM__:!0,name:"GridItem",alias:["Gi"],props:dr,setup(){const{isSsrRef:e,xGapRef:r,itemStyleRef:i,overflowRef:t,layoutShiftDisabledRef:n}=ie(Ve),l=nt();return{overflow:t,itemStyle:i,layoutShiftDisabled:n,mergedXGap:D(()=>oe(r.value||0)),deriveStyle:()=>{e.value;const{privateSpan:s=He,privateShow:c=!0,privateColStart:d=void 0,privateOffset:a=0}=l.vnode.props,{value:u}=r,g=oe(u||0);return{display:c?"":"none",gridColumn:`${d??`span ${s}`} / span ${s}`,marginLeft:a?`calc((100% - (${s} - 1) * ${g}) / ${s} * ${a} + ${g} * ${a})`:""}}}},render(){var e,r;if(this.layoutShiftDisabled){const{span:i,offset:t,mergedXGap:n}=this;return o("div",{style:{gridColumn:`span ${i} / span ${i}`,marginLeft:t?`calc((100% - (${i} - 1) * ${n}) / ${i} * ${t} + ${n} * ${t})`:""}},this.$slots)}return o("div",{style:[this.itemStyle,this.deriveStyle()]},(r=(e=this.$slots).default)===null||r===void 0?void 0:r.call(e,{overflow:this.overflow}))}}),ur={xs:0,s:640,m:1024,l:1280,xl:1536,xxl:1920},Ze=24,be="__ssr__",cr={layoutShiftDisabled:Boolean,responsive:{type:[String,Boolean],default:"self"},cols:{type:[Number,String],default:Ze},itemResponsive:Boolean,collapsed:Boolean,collapsedRows:{type:Number,default:1},itemStyle:[Object,String],xGap:{type:[Number,String],default:0},yGap:{type:[Number,String],default:0}},fr=V({name:"Grid",inheritAttrs:!1,props:cr,setup(e){const{mergedClsPrefixRef:r,mergedBreakpointsRef:i}=ye(e),t=/^\d+$/,n=N(void 0),l=or((i==null?void 0:i.value)||ur),s=le(()=>!!(e.itemResponsive||!t.test(e.cols.toString())||!t.test(e.xGap.toString())||!t.test(e.yGap.toString()))),c=D(()=>{if(s.value)return e.responsive==="self"?n.value:l.value}),d=le(()=>{var C;return(C=Number(te(e.cols.toString(),c.value)))!==null&&C!==void 0?C:Ze}),a=le(()=>te(e.xGap.toString(),c.value)),u=le(()=>te(e.yGap.toString(),c.value)),g=C=>{n.value=C.contentRect.width},x=C=>{It(g,C)},h=N(!1),_=D(()=>{if(e.responsive==="self")return x}),b=N(!1),R=N();return Oe(()=>{const{value:C}=R;C&&C.hasAttribute(be)&&(C.removeAttribute(be),b.value=!0)}),ze(Ve,{layoutShiftDisabledRef:A(e,"layoutShiftDisabled"),isSsrRef:b,itemStyleRef:A(e,"itemStyle"),xGapRef:a,overflowRef:h}),{isSsr:!at,contentEl:R,mergedClsPrefix:r,style:D(()=>e.layoutShiftDisabled?{width:"100%",display:"grid",gridTemplateColumns:`repeat(${e.cols}, minmax(0, 1fr))`,columnGap:oe(e.xGap),rowGap:oe(e.yGap)}:{width:"100%",display:"grid",gridTemplateColumns:`repeat(${d.value}, minmax(0, 1fr))`,columnGap:oe(a.value),rowGap:oe(u.value)}),isResponsive:s,responsiveQuery:c,responsiveCols:d,handleResize:_,overflow:h}},render(){if(this.layoutShiftDisabled)return o("div",we({ref:"contentEl",class:`${this.mergedClsPrefix}-grid`,style:this.style},this.$attrs),this.$slots);const e=()=>{var r,i,t,n,l,s,c;this.overflow=!1;const d=st(At(this)),a=[],{collapsed:u,collapsedRows:g,responsiveCols:x,responsiveQuery:h}=this;d.forEach(v=>{var k,S,p,w,T;if(((k=v==null?void 0:v.type)===null||k===void 0?void 0:k.__GRID_ITEM__)!==!0)return;if(er(v)){const L=xe(v);L.props?L.props.privateShow=!1:L.props={privateShow:!1},a.push({child:L,rawChildSpan:0});return}v.dirs=((S=v.dirs)===null||S===void 0?void 0:S.filter(({dir:L})=>L!==re))||null,((p=v.dirs)===null||p===void 0?void 0:p.length)===0&&(v.dirs=null);const P=xe(v),f=Number((T=te((w=P.props)===null||w===void 0?void 0:w.span,h))!==null&&T!==void 0?T:Le);f!==0&&a.push({child:P,rawChildSpan:f})});let _=0;const b=(r=a[a.length-1])===null||r===void 0?void 0:r.child;if(b!=null&&b.props){const v=(i=b.props)===null||i===void 0?void 0:i.suffix;v!==void 0&&v!==!1&&(_=Number((n=te((t=b.props)===null||t===void 0?void 0:t.span,h))!==null&&n!==void 0?n:Le),b.props.privateSpan=_,b.props.privateColStart=x+1-_,b.props.privateShow=(l=b.props.privateShow)!==null&&l!==void 0?l:!0)}let R=0,C=!1;for(const{child:v,rawChildSpan:k}of a){if(C&&(this.overflow=!0),!C){const S=Number((c=te((s=v.props)===null||s===void 0?void 0:s.offset,h))!==null&&c!==void 0?c:0),p=Math.min(k+S,x);if(v.props?(v.props.privateSpan=p,v.props.privateOffset=S):v.props={privateSpan:p,privateOffset:S},u){const w=R%x;p+w>x&&(R+=x-w),p+R+_>g*x?C=!0:R+=p}}C&&(v.props?v.props.privateShow!==!0&&(v.props.privateShow=!1):v.props={privateShow:!1})}return o("div",we({ref:"contentEl",class:`${this.mergedClsPrefix}-grid`,style:this.style,[be]:this.isSsr||void 0},this.$attrs),a.map(({child:v})=>v))};return this.isResponsive&&this.responsive==="self"?o(lt,{onResize:this.handleResize},{default:e}):e()}}),pr=e=>{const{infoColor:r,successColor:i,warningColor:t,errorColor:n,textColor2:l,progressRailColor:s,fontSize:c,fontWeight:d}=e;return{fontSize:c,fontSizeCircle:"28px",fontWeightCircle:d,railColor:s,railHeight:"8px",iconSizeCircle:"36px",iconSizeLine:"18px",iconColor:r,iconColorInfo:r,iconColorSuccess:i,iconColorWarning:t,iconColorError:n,textColorCircle:l,textColorLineInner:"rgb(255, 255, 255)",textColorLineOuter:l,fillColor:r,fillColorInfo:r,fillColorSuccess:i,fillColorWarning:t,fillColorError:n,lineBgProcessing:"linear-gradient(90deg, rgba(255, 255, 255, .3) 0%, rgba(255, 255, 255, .5) 100%)"}},gr={name:"Progress",common:Ae,self:pr},Ye=gr,hr=e=>{const{iconColor:r,primaryColor:i,errorColor:t,textColor2:n,successColor:l,opacityDisabled:s,actionColor:c,borderColor:d,hoverColor:a,lineHeight:u,borderRadius:g,fontSize:x}=e;return{fontSize:x,lineHeight:u,borderRadius:g,draggerColor:c,draggerBorder:`1px dashed ${d}`,draggerBorderHover:`1px dashed ${i}`,itemColorHover:a,itemColorHoverError:ct(t,{alpha:.06}),itemTextColor:n,itemTextColorError:t,itemTextColorSuccess:l,itemIconColor:r,itemDisabledOpacity:s,itemBorderImageCardError:`1px solid ${t}`,itemBorderImageCard:`1px solid ${d}`}},mr=dt({name:"Upload",common:Ae,peers:{Button:ut,Progress:Ye},self:hr}),vr=mr,br=U([m("progress",{display:"inline-block"},[m("progress-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),I("line",`
 width: 100%;
 display: block;
 `,[m("progress-content",`
 display: flex;
 align-items: center;
 `,[m("progress-graph",{flex:1})]),m("progress-custom-content",{marginLeft:"14px"}),m("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[I("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),I("circle, dashboard",{width:"120px"},[m("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),m("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),m("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),I("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[m("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),m("progress-content",{position:"relative"}),m("progress-graph",{position:"relative"},[m("progress-graph-circle",[U("svg",{verticalAlign:"bottom"}),m("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[I("empty",{opacity:0})]),m("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),m("progress-graph-line",[I("indicator-inside",[m("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[m("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),m("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),I("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[m("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),m("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),m("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[m("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[I("processing",[U("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),U("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),yr={success:o(Ge,null),error:o(Ue,null),warning:o($e,null),info:o(Me,null)},wr=V({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:r}){const i=D(()=>ee(e.height)),t=D(()=>e.railBorderRadius!==void 0?ee(e.railBorderRadius):e.height!==void 0?ee(e.height,{c:.5}):""),n=D(()=>e.fillBorderRadius!==void 0?ee(e.fillBorderRadius):e.railBorderRadius!==void 0?ee(e.railBorderRadius):e.height!==void 0?ee(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:l,railColor:s,railStyle:c,percentage:d,unit:a,indicatorTextColor:u,status:g,showIndicator:x,fillColor:h,processing:_,clsPrefix:b}=e;return o("div",{class:`${b}-progress-content`,role:"none"},o("div",{class:`${b}-progress-graph`,"aria-hidden":!0},o("div",{class:[`${b}-progress-graph-line`,{[`${b}-progress-graph-line--indicator-${l}`]:!0}]},o("div",{class:`${b}-progress-graph-line-rail`,style:[{backgroundColor:s,height:i.value,borderRadius:t.value},c]},o("div",{class:[`${b}-progress-graph-line-fill`,_&&`${b}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:h,height:i.value,lineHeight:i.value,borderRadius:n.value}},l==="inside"?o("div",{class:`${b}-progress-graph-line-indicator`,style:{color:u}},r.default?r.default():`${d}${a}`):null)))),x&&l==="outside"?o("div",null,r.default?o("div",{class:`${b}-progress-custom-content`,style:{color:u},role:"none"},r.default()):g==="default"?o("div",{role:"none",class:`${b}-progress-icon ${b}-progress-icon--as-text`,style:{color:u}},d,a):o("div",{class:`${b}-progress-icon`,"aria-hidden":!0},o(Y,{clsPrefix:b},{default:()=>yr[g]}))):null)}}}),xr={success:o(Ge,null),error:o(Ue,null),warning:o($e,null),info:o(Me,null)},Cr=V({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:r}){function i(t,n,l){const{gapDegree:s,viewBoxWidth:c,strokeWidth:d}=e,a=50,u=0,g=a,x=0,h=2*a,_=50+d/2,b=`M ${_},${_} m ${u},${g}
      a ${a},${a} 0 1 1 ${x},${-h}
      a ${a},${a} 0 1 1 ${-x},${h}`,R=Math.PI*2*a,C={stroke:l,strokeDasharray:`${t/100*(R-s)}px ${c*8}px`,strokeDashoffset:`-${s/2}px`,transformOrigin:n?"center":void 0,transform:n?`rotate(${n}deg)`:void 0};return{pathString:b,pathStyle:C}}return()=>{const{fillColor:t,railColor:n,strokeWidth:l,offsetDegree:s,status:c,percentage:d,showIndicator:a,indicatorTextColor:u,unit:g,gapOffsetDegree:x,clsPrefix:h}=e,{pathString:_,pathStyle:b}=i(100,0,n),{pathString:R,pathStyle:C}=i(d,s,t),v=100+l;return o("div",{class:`${h}-progress-content`,role:"none"},o("div",{class:`${h}-progress-graph`,"aria-hidden":!0},o("div",{class:`${h}-progress-graph-circle`,style:{transform:x?`rotate(${x}deg)`:void 0}},o("svg",{viewBox:`0 0 ${v} ${v}`},o("g",null,o("path",{class:`${h}-progress-graph-circle-rail`,d:_,"stroke-width":l,"stroke-linecap":"round",fill:"none",style:b})),o("g",null,o("path",{class:[`${h}-progress-graph-circle-fill`,d===0&&`${h}-progress-graph-circle-fill--empty`],d:R,"stroke-width":l,"stroke-linecap":"round",fill:"none",style:C}))))),a?o("div",null,r.default?o("div",{class:`${h}-progress-custom-content`,role:"none"},r.default()):c!=="default"?o("div",{class:`${h}-progress-icon`,"aria-hidden":!0},o(Y,{clsPrefix:h},{default:()=>xr[c]})):o("div",{class:`${h}-progress-text`,style:{color:u},role:"none"},o("span",{class:`${h}-progress-text__percentage`},d),o("span",{class:`${h}-progress-text__unit`},g))):null)}}});function je(e,r,i=100){return`m ${i/2} ${i/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const Rr=V({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:r}){const i=D(()=>e.percentage.map((n,l)=>`${Math.PI*n/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*l)-e.circleGap*l)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:t,strokeWidth:n,circleGap:l,showIndicator:s,fillColor:c,railColor:d,railStyle:a,percentage:u,clsPrefix:g}=e;return o("div",{class:`${g}-progress-content`,role:"none"},o("div",{class:`${g}-progress-graph`,"aria-hidden":!0},o("div",{class:`${g}-progress-graph-circle`},o("svg",{viewBox:`0 0 ${t} ${t}`},u.map((x,h)=>o("g",{key:h},o("path",{class:`${g}-progress-graph-circle-rail`,d:je(t/2-n/2*(1+2*h)-l*h,n,t),"stroke-width":n,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:d[h]},a[h]]}),o("path",{class:[`${g}-progress-graph-circle-fill`,x===0&&`${g}-progress-graph-circle-fill--empty`],d:je(t/2-n/2*(1+2*h)-l*h,n,t),"stroke-width":n,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:i.value[h],strokeDashoffset:0,stroke:c[h]}})))))),s&&r.default?o("div",null,o("div",{class:`${g}-progress-text`},r.default())):null)}}}),kr=Object.assign(Object.assign({},he.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),Sr=V({name:"Progress",props:kr,setup(e){const r=D(()=>e.indicatorPlacement||e.indicatorPosition),i=D(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:t,inlineThemeDisabled:n}=ye(e),l=he("Progress","-progress",br,Ye,e,t),s=D(()=>{const{status:d}=e,{common:{cubicBezierEaseInOut:a},self:{fontSize:u,fontSizeCircle:g,railColor:x,railHeight:h,iconSizeCircle:_,iconSizeLine:b,textColorCircle:R,textColorLineInner:C,textColorLineOuter:v,lineBgProcessing:k,fontWeightCircle:S,[Ce("iconColor",d)]:p,[Ce("fillColor",d)]:w}}=l.value;return{"--n-bezier":a,"--n-fill-color":w,"--n-font-size":u,"--n-font-size-circle":g,"--n-font-weight-circle":S,"--n-icon-color":p,"--n-icon-size-circle":_,"--n-icon-size-line":b,"--n-line-bg-processing":k,"--n-rail-color":x,"--n-rail-height":h,"--n-text-color-circle":R,"--n-text-color-line-inner":C,"--n-text-color-line-outer":v}}),c=n?Ee("progress",D(()=>e.status[0]),s,e):void 0;return{mergedClsPrefix:t,mergedIndicatorPlacement:r,gapDeg:i,cssVars:n?void 0:s,themeClass:c==null?void 0:c.themeClass,onRender:c==null?void 0:c.onRender}},render(){const{type:e,cssVars:r,indicatorTextColor:i,showIndicator:t,status:n,railColor:l,railStyle:s,color:c,percentage:d,viewBoxWidth:a,strokeWidth:u,mergedIndicatorPlacement:g,unit:x,borderRadius:h,fillBorderRadius:_,height:b,processing:R,circleGap:C,mergedClsPrefix:v,gapDeg:k,gapOffsetDegree:S,themeClass:p,$slots:w,onRender:T}=this;return T==null||T(),o("div",{class:[p,`${v}-progress`,`${v}-progress--${e}`,`${v}-progress--${n}`],style:r,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":d,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?o(Cr,{clsPrefix:v,status:n,showIndicator:t,indicatorTextColor:i,railColor:l,fillColor:c,railStyle:s,offsetDegree:this.offsetDegree,percentage:d,viewBoxWidth:a,strokeWidth:u,gapDegree:k===void 0?e==="dashboard"?75:0:k,gapOffsetDegree:S,unit:x},w):e==="line"?o(wr,{clsPrefix:v,status:n,showIndicator:t,indicatorTextColor:i,railColor:l,fillColor:c,railStyle:s,percentage:d,processing:R,indicatorPlacement:g,unit:x,fillBorderRadius:_,railBorderRadius:h,height:b},w):e==="multiple-circle"?o(Rr,{clsPrefix:v,strokeWidth:u,railColor:l,fillColor:c,railStyle:s,viewBoxWidth:a,percentage:d,showIndicator:t,circleGap:C},w):null)}}),ne=Ie("n-upload"),Xe="__UPLOAD_DRAGGER__",Br=V({name:"UploadDragger",[Xe]:!0,setup(e,{slots:r}){const i=ie(ne,null);return i||me("upload-dragger","`n-upload-dragger` must be placed inside `n-upload`."),()=>{const{mergedClsPrefixRef:{value:t},mergedDisabledRef:{value:n},maxReachedRef:{value:l}}=i;return o("div",{class:[`${t}-upload-dragger`,(n||l)&&`${t}-upload-dragger--disabled`]},r)}}}),qe=V({name:"UploadTrigger",props:{abstract:Boolean},setup(e,{slots:r}){const i=ie(ne,null);i||me("upload-trigger","`n-upload-trigger` must be placed inside `n-upload`.");const{mergedClsPrefixRef:t,mergedDisabledRef:n,maxReachedRef:l,listTypeRef:s,dragOverRef:c,openOpenFileDialog:d,draggerInsideRef:a,handleFileAddition:u,mergedDirectoryDndRef:g,triggerStyleRef:x}=i,h=D(()=>s.value==="image-card");function _(){n.value||l.value||d()}function b(k){k.preventDefault(),c.value=!0}function R(k){k.preventDefault(),c.value=!0}function C(k){k.preventDefault(),c.value=!1}function v(k){var S;if(k.preventDefault(),!a.value||n.value||l.value){c.value=!1;return}const p=(S=k.dataTransfer)===null||S===void 0?void 0:S.items;p!=null&&p.length?Gt(Array.from(p).map(w=>w.webkitGetAsEntry()),g.value).then(w=>{u(w)}).finally(()=>{c.value=!1}):c.value=!1}return()=>{var k;const{value:S}=t;return e.abstract?(k=r.default)===null||k===void 0?void 0:k.call(r,{handleClick:_,handleDrop:v,handleDragOver:b,handleDragEnter:R,handleDragLeave:C}):o("div",{class:[`${S}-upload-trigger`,(n.value||l.value)&&`${S}-upload-trigger--disabled`,h.value&&`${S}-upload-trigger--image-card`],style:x.value,onClick:_,onDrop:v,onDragover:b,onDragenter:R,onDragleave:C},h.value?o(Br,null,{default:()=>ft(r.default,()=>[o(Y,{clsPrefix:S},{default:()=>o(Vt,null)})])}):r)}}}),_r=V({name:"UploadProgress",props:{show:Boolean,percentage:{type:Number,required:!0},status:{type:String,required:!0}},setup(){return{mergedTheme:ie(ne).mergedThemeRef}},render(){return o(Fe,null,{default:()=>this.show?o(Sr,{type:"line",showIndicator:!1,percentage:this.percentage,status:this.status,height:2,theme:this.mergedTheme.peers.Progress,themeOverrides:this.mergedTheme.peerOverrides.Progress}):null})}}),Tr=o("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},o("g",{fill:"none"},o("path",{d:"M21.75 3A3.25 3.25 0 0 1 25 6.25v15.5A3.25 3.25 0 0 1 21.75 25H6.25A3.25 3.25 0 0 1 3 21.75V6.25A3.25 3.25 0 0 1 6.25 3h15.5zm.583 20.4l-7.807-7.68a.75.75 0 0 0-.968-.07l-.084.07l-7.808 7.68c.183.065.38.1.584.1h15.5c.204 0 .4-.035.583-.1l-7.807-7.68l7.807 7.68zM21.75 4.5H6.25A1.75 1.75 0 0 0 4.5 6.25v15.5c0 .208.036.408.103.593l7.82-7.692a2.25 2.25 0 0 1 3.026-.117l.129.117l7.82 7.692c.066-.185.102-.385.102-.593V6.25a1.75 1.75 0 0 0-1.75-1.75zm-3.25 3a2.5 2.5 0 1 1 0 5a2.5 2.5 0 0 1 0-5zm0 1.5a1 1 0 1 0 0 2a1 1 0 0 0 0-2z",fill:"currentColor"}))),Dr=o("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},o("g",{fill:"none"},o("path",{d:"M6.4 2A2.4 2.4 0 0 0 4 4.4v19.2A2.4 2.4 0 0 0 6.4 26h15.2a2.4 2.4 0 0 0 2.4-2.4V11.578c0-.729-.29-1.428-.805-1.944l-6.931-6.931A2.4 2.4 0 0 0 14.567 2H6.4zm-.9 2.4a.9.9 0 0 1 .9-.9H14V10a2 2 0 0 0 2 2h6.5v11.6a.9.9 0 0 1-.9.9H6.4a.9.9 0 0 1-.9-.9V4.4zm16.44 6.1H16a.5.5 0 0 1-.5-.5V4.06l6.44 6.44z",fill:"currentColor"})));var Pr=globalThis&&globalThis.__awaiter||function(e,r,i,t){function n(l){return l instanceof i?l:new i(function(s){s(l)})}return new(i||(i=Promise))(function(l,s){function c(u){try{a(t.next(u))}catch(g){s(g)}}function d(u){try{a(t.throw(u))}catch(g){s(g)}}function a(u){u.done?l(u.value):n(u.value).then(c,d)}a((t=t.apply(e,r||[])).next())})};const pe={paddingMedium:"0 3px",heightMedium:"24px",iconSizeMedium:"18px"},Lr=V({name:"UploadFile",props:{clsPrefix:{type:String,required:!0},file:{type:Object,required:!0},listType:{type:String,required:!0}},setup(e){const r=ie(ne),i=N(null),t=N(""),n=D(()=>{const{file:p}=e;return p.status==="finished"?"success":p.status==="error"?"error":"info"}),l=D(()=>{const{file:p}=e;if(p.status==="error")return"error"}),s=D(()=>{const{file:p}=e;return p.status==="uploading"}),c=D(()=>{if(!r.showCancelButtonRef.value)return!1;const{file:p}=e;return["uploading","pending","error"].includes(p.status)}),d=D(()=>{if(!r.showRemoveButtonRef.value)return!1;const{file:p}=e;return["finished"].includes(p.status)}),a=D(()=>{if(!r.showDownloadButtonRef.value)return!1;const{file:p}=e;return["finished"].includes(p.status)}),u=D(()=>{if(!r.showRetryButtonRef.value)return!1;const{file:p}=e;return["error"].includes(p.status)}),g=le(()=>t.value||e.file.thumbnailUrl||e.file.url),x=D(()=>{if(!r.showPreviewButtonRef.value)return!1;const{file:{status:p},listType:w}=e;return["finished"].includes(p)&&g.value&&w==="image-card"});function h(){r.submit(e.file.id)}function _(p){p.preventDefault();const{file:w}=e;["finished","pending","error"].includes(w.status)?R(w):["uploading"].includes(w.status)?v(w):ht("upload","The button clicked type is unknown.")}function b(p){p.preventDefault(),C(e.file)}function R(p){const{xhrMap:w,doChange:T,onRemoveRef:{value:P},mergedFileListRef:{value:f}}=r;Promise.resolve(P?P({file:Object.assign({},p),fileList:f}):!0).then(L=>{if(L===!1)return;const O=Object.assign({},p,{status:"removed"});w.delete(p.id),T(O,void 0,{remove:!0})})}function C(p){const{onDownloadRef:{value:w}}=r;Promise.resolve(w?w(Object.assign({},p)):!0).then(T=>{T!==!1&&$t(p.url,p.name)})}function v(p){const{xhrMap:w}=r,T=w.get(p.id);T==null||T.abort(),R(Object.assign({},p))}function k(){const{onPreviewRef:{value:p}}=r;if(p)p(e.file);else if(e.listType==="image-card"){const{value:w}=i;if(!w)return;w.click()}}const S=()=>Pr(this,void 0,void 0,function*(){const{listType:p}=e;p!=="image"&&p!=="image-card"||r.shouldUseThumbnailUrlRef.value(e.file)&&(t.value=yield r.getFileThumbnailUrlResolver(e.file))});return pt(()=>{S()}),{mergedTheme:r.mergedThemeRef,progressStatus:n,buttonType:l,showProgress:s,disabled:r.mergedDisabledRef,showCancelButton:c,showRemoveButton:d,showDownloadButton:a,showRetryButton:u,showPreviewButton:x,mergedThumbnailUrl:g,shouldUseThumbnailUrl:r.shouldUseThumbnailUrlRef,renderIcon:r.renderIconRef,imageRef:i,handleRemoveOrCancelClick:_,handleDownloadClick:b,handleRetryClick:h,handlePreviewClick:k}},render(){const{clsPrefix:e,mergedTheme:r,listType:i,file:t,renderIcon:n}=this;let l;const s=i==="image";s||i==="image-card"?l=!this.shouldUseThumbnailUrl(t)||!this.mergedThumbnailUrl?o("span",{class:`${e}-upload-file-info__thumbnail`},n?n(t):We(t)?o(Y,{clsPrefix:e},{default:()=>Tr}):o(Y,{clsPrefix:e},{default:()=>Dr})):o("a",{rel:"noopener noreferer",target:"_blank",href:t.url||void 0,class:`${e}-upload-file-info__thumbnail`,onClick:this.handlePreviewClick},i==="image-card"?o(Ut,{src:this.mergedThumbnailUrl||void 0,previewSrc:t.url||void 0,alt:t.name,ref:"imageRef"}):o("img",{src:this.mergedThumbnailUrl||void 0,alt:t.name})):l=o("span",{class:`${e}-upload-file-info__thumbnail`},n?n(t):o(Y,{clsPrefix:e},{default:()=>o(ir,null)}));const d=o(_r,{show:this.showProgress,percentage:t.percentage||0,status:this.progressStatus}),a=i==="text"||i==="image";return o("div",{class:[`${e}-upload-file`,`${e}-upload-file--${this.progressStatus}-status`,t.url&&t.status!=="error"&&i!=="image-card"&&`${e}-upload-file--with-url`,`${e}-upload-file--${i}-type`]},o("div",{class:`${e}-upload-file-info`},l,o("div",{class:`${e}-upload-file-info__name`},a&&(t.url&&t.status!=="error"?o("a",{rel:"noopener noreferer",target:"_blank",href:t.url||void 0,onClick:this.handlePreviewClick},t.name):o("span",{onClick:this.handlePreviewClick},t.name)),s&&d),o("div",{class:[`${e}-upload-file-info__action`,`${e}-upload-file-info__action--${i}-type`]},this.showPreviewButton?o(J,{key:"preview",quaternary:!0,type:this.buttonType,onClick:this.handlePreviewClick,theme:r.peers.Button,themeOverrides:r.peerOverrides.Button,builtinThemeOverrides:pe},{icon:()=>o(Y,{clsPrefix:e},{default:()=>o(Ht,null)})}):null,(this.showRemoveButton||this.showCancelButton)&&!this.disabled&&o(J,{key:"cancelOrTrash",theme:r.peers.Button,themeOverrides:r.peerOverrides.Button,quaternary:!0,builtinThemeOverrides:pe,type:this.buttonType,onClick:this.handleRemoveOrCancelClick},{icon:()=>o(gt,null,{default:()=>this.showRemoveButton?o(Y,{clsPrefix:e,key:"trash"},{default:()=>o(nr,null)}):o(Y,{clsPrefix:e,key:"cancel"},{default:()=>o(lr,null)})})}),this.showRetryButton&&!this.disabled&&o(J,{key:"retry",quaternary:!0,type:this.buttonType,onClick:this.handleRetryClick,theme:r.peers.Button,themeOverrides:r.peerOverrides.Button,builtinThemeOverrides:pe},{icon:()=>o(Y,{clsPrefix:e},{default:()=>o(sr,null)})}),this.showDownloadButton?o(J,{key:"download",quaternary:!0,type:this.buttonType,onClick:this.handleDownloadClick,theme:r.peers.Button,themeOverrides:r.peerOverrides.Button,builtinThemeOverrides:pe},{icon:()=>o(Y,{clsPrefix:e},{default:()=>o(ar,null)})}):null)),!s&&d)}}),jr=V({name:"UploadFileList",setup(e,{slots:r}){const i=ie(ne,null);i||me("upload-file-list","`n-upload-file-list` must be placed inside `n-upload`.");const{abstractRef:t,mergedClsPrefixRef:n,listTypeRef:l,mergedFileListRef:s,fileListStyleRef:c,cssVarsRef:d,themeClassRef:a,maxReachedRef:u,showTriggerRef:g,imageGroupPropsRef:x}=i,h=D(()=>l.value==="image-card"),_=()=>s.value.map(R=>o(Lr,{clsPrefix:n.value,key:R.id,file:R,listType:l.value})),b=()=>h.value?o(Mt,Object.assign({},x.value),{default:_}):o(Fe,{group:!0},{default:_});return()=>{const{value:R}=n,{value:C}=t;return o("div",{class:[`${R}-upload-file-list`,h.value&&`${R}-upload-file-list--grid`,C?a==null?void 0:a.value:void 0],style:[C&&d?d.value:"",c.value]},b(),g.value&&!u.value&&h.value&&o(qe,null,r))}}}),Nr=U([m("upload","width: 100%;",[I("dragger-inside",[m("upload-trigger",`
 display: block;
 `)]),I("drag-over",[m("upload-dragger",`
 border: var(--n-dragger-border-hover);
 `)])]),m("upload-dragger",`
 cursor: pointer;
 box-sizing: border-box;
 width: 100%;
 text-align: center;
 border-radius: var(--n-border-radius);
 padding: 24px;
 opacity: 1;
 transition:
 opacity .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 background-color: var(--n-dragger-color);
 border: var(--n-dragger-border);
 `,[U("&:hover",`
 border: var(--n-dragger-border-hover);
 `),I("disabled",`
 cursor: not-allowed;
 `)]),m("upload-trigger",`
 display: inline-block;
 box-sizing: border-box;
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[U("+",[m("upload-file-list","margin-top: 8px;")]),I("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `),I("image-card",`
 width: 96px;
 height: 96px;
 `,[m("base-icon",`
 font-size: 24px;
 `),m("upload-dragger",`
 padding: 0;
 height: 100%;
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `)])]),m("upload-file-list",`
 line-height: var(--n-line-height);
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[U("a, img","outline: none;"),I("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `,[m("upload-file","cursor: not-allowed;")]),I("grid",`
 display: grid;
 grid-template-columns: repeat(auto-fill, 96px);
 grid-gap: 8px;
 margin-top: 0;
 `),m("upload-file",`
 display: block;
 box-sizing: border-box;
 cursor: default;
 padding: 0px 12px 0 6px;
 transition: background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 `,[Re(),m("progress",[Re({foldPadding:!0})]),U("&:hover",`
 background-color: var(--n-item-color-hover);
 `,[m("upload-file-info",[H("action",`
 opacity: 1;
 `)])]),I("image-type",`
 border-radius: var(--n-border-radius);
 text-decoration: underline;
 text-decoration-color: #0000;
 `,[m("upload-file-info",`
 padding-top: 0px;
 padding-bottom: 0px;
 width: 100%;
 height: 100%;
 display: flex;
 justify-content: space-between;
 align-items: center;
 padding: 6px 0;
 `,[m("progress",`
 padding: 2px 0;
 margin-bottom: 0;
 `),H("name",`
 padding: 0 8px;
 `),H("thumbnail",`
 width: 32px;
 height: 32px;
 font-size: 28px;
 display: flex;
 justify-content: center;
 align-items: center;
 `,[U("img",`
 width: 100%;
 `)])])]),I("text-type",[m("progress",`
 box-sizing: border-box;
 padding-bottom: 6px;
 margin-bottom: 6px;
 `)]),I("image-card-type",`
 position: relative;
 width: 96px;
 height: 96px;
 border: var(--n-item-border-image-card);
 border-radius: var(--n-border-radius);
 padding: 0;
 display: flex;
 align-items: center;
 justify-content: center;
 transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 overflow: hidden;
 `,[m("progress",`
 position: absolute;
 left: 8px;
 bottom: 8px;
 right: 8px;
 width: unset;
 `),m("upload-file-info",`
 padding: 0;
 width: 100%;
 height: 100%;
 `,[H("thumbnail",`
 width: 100%;
 height: 100%;
 display: flex;
 flex-direction: column;
 align-items: center;
 justify-content: center;
 font-size: 36px;
 `,[U("img",`
 width: 100%;
 `)])]),U("&::before",`
 position: absolute;
 z-index: 1;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border-radius: inherit;
 opacity: 0;
 transition: opacity .2s var(--n-bezier);
 content: "";
 `),U("&:hover",[U("&::before","opacity: 1;"),m("upload-file-info",[H("thumbnail","opacity: .12;")])])]),I("error-status",[U("&:hover",`
 background-color: var(--n-item-color-hover-error);
 `),m("upload-file-info",[H("name","color: var(--n-item-text-color-error);"),H("thumbnail","color: var(--n-item-text-color-error);")]),I("image-card-type",`
 border: var(--n-item-border-image-card-error);
 `)]),I("with-url",`
 cursor: pointer;
 `,[m("upload-file-info",[H("name",`
 color: var(--n-item-text-color-success);
 text-decoration-color: var(--n-item-text-color-success);
 `,[U("a",`
 text-decoration: underline;
 `)])])]),m("upload-file-info",`
 position: relative;
 padding-top: 6px;
 padding-bottom: 6px;
 display: flex;
 flex-wrap: nowrap;
 `,[H("thumbnail",`
 font-size: 18px;
 opacity: 1;
 transition: opacity .2s var(--n-bezier);
 color: var(--n-item-icon-color);
 `,[m("base-icon",`
 margin-right: 2px;
 vertical-align: middle;
 transition: color .3s var(--n-bezier);
 `)]),H("action",`
 padding-top: inherit;
 padding-bottom: inherit;
 position: absolute;
 right: 0;
 top: 0;
 bottom: 0;
 width: 80px;
 display: flex;
 align-items: center;
 transition: opacity .2s var(--n-bezier);
 justify-content: flex-end;
 opacity: 0;
 `,[m("button",[U("&:not(:last-child)",{marginRight:"4px"}),m("base-icon",[U("svg",[mt()])])]),I("image-type",`
 position: relative;
 max-width: 80px;
 width: auto;
 `),I("image-card-type",`
 z-index: 2;
 position: absolute;
 width: 100%;
 height: 100%;
 left: 0;
 right: 0;
 bottom: 0;
 top: 0;
 display: flex;
 justify-content: center;
 align-items: center;
 `)]),H("name",`
 color: var(--n-item-text-color);
 flex: 1;
 display: flex;
 justify-content: center;
 text-overflow: ellipsis;
 overflow: hidden;
 flex-direction: column;
 text-decoration-color: #0000;
 font-size: var(--n-font-size);
 transition:
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier); 
 `,[U("a",`
 color: inherit;
 text-decoration: underline;
 `)])])])]),m("upload-file-input",`
 display: block;
 width: 0;
 height: 0;
 opacity: 0;
 `)]);var Ne=globalThis&&globalThis.__awaiter||function(e,r,i,t){function n(l){return l instanceof i?l:new i(function(s){s(l)})}return new(i||(i=Promise))(function(l,s){function c(u){try{a(t.next(u))}catch(g){s(g)}}function d(u){try{a(t.throw(u))}catch(g){s(g)}}function a(u){u.done?l(u.value):n(u.value).then(c,d)}a((t=t.apply(e,r||[])).next())})};function Ir(e,r,i){const{doChange:t,xhrMap:n}=e;let l=0;function s(d){var a;let u=Object.assign({},r,{status:"error",percentage:l});n.delete(r.id),u=se(((a=e.onError)===null||a===void 0?void 0:a.call(e,{file:u,event:d}))||u),t(u,d)}function c(d){var a;if(e.isErrorState){if(e.isErrorState(i)){s(d);return}}else if(i.status<200||i.status>=300){s(d);return}let u=Object.assign({},r,{status:"finished",percentage:l});n.delete(r.id),u=se(((a=e.onFinish)===null||a===void 0?void 0:a.call(e,{file:u,event:d}))||u),t(u,d)}return{handleXHRLoad:c,handleXHRError:s,handleXHRAbort(d){const a=Object.assign({},r,{status:"removed",file:null,percentage:l});n.delete(r.id),t(a,d)},handleXHRProgress(d){const a=Object.assign({},r,{status:"uploading"});if(d.lengthComputable){const u=Math.ceil(d.loaded/d.total*100);a.percentage=u,l=u}t(a,d)}}}function Or(e){const{inst:r,file:i,data:t,headers:n,withCredentials:l,action:s,customRequest:c}=e,{doChange:d}=e.inst;let a=0;c({file:i,data:t,headers:n,withCredentials:l,action:s,onProgress(u){const g=Object.assign({},i,{status:"uploading"}),x=u.percent;g.percentage=x,a=x,d(g)},onFinish(){var u;let g=Object.assign({},i,{status:"finished",percentage:a});g=se(((u=r.onFinish)===null||u===void 0?void 0:u.call(r,{file:g}))||g),d(g)},onError(){var u;let g=Object.assign({},i,{status:"error",percentage:a});g=se(((u=r.onError)===null||u===void 0?void 0:u.call(r,{file:g}))||g),d(g)}})}function zr(e,r,i){const t=Ir(e,r,i);i.onabort=t.handleXHRAbort,i.onerror=t.handleXHRError,i.onload=t.handleXHRLoad,i.upload&&(i.upload.onprogress=t.handleXHRProgress)}function Qe(e,r){return typeof e=="function"?e({file:r}):e||{}}function Ar(e,r,i){const t=Qe(r,i);t&&Object.keys(t).forEach(n=>{e.setRequestHeader(n,t[n])})}function Gr(e,r,i){const t=Qe(r,i);t&&Object.keys(t).forEach(n=>{e.append(n,t[n])})}function Ur(e,r,i,{method:t,action:n,withCredentials:l,responseType:s,headers:c,data:d}){const a=new XMLHttpRequest;a.responseType=s,e.xhrMap.set(i.id,a),a.withCredentials=l;const u=new FormData;if(Gr(u,d,i),u.append(r,i.file),zr(e,i,a),n!==void 0){a.open(t.toUpperCase(),n),Ar(a,c,i),a.send(u);const g=Object.assign({},i,{status:"uploading"});e.doChange(g)}}const $r=Object.assign(Object.assign({},he.props),{name:{type:String,default:"file"},accept:String,action:String,customRequest:Function,directory:Boolean,directoryDnd:{type:Boolean,default:void 0},method:{type:String,default:"POST"},multiple:Boolean,showFileList:{type:Boolean,default:!0},data:[Object,Function],headers:[Object,Function],withCredentials:Boolean,responseType:{type:String,default:""},disabled:{type:Boolean,default:void 0},onChange:Function,onRemove:Function,onFinish:Function,onError:Function,onBeforeUpload:Function,isErrorState:Function,onDownload:Function,defaultUpload:{type:Boolean,default:!0},fileList:Array,"onUpdate:fileList":[Function,Array],onUpdateFileList:[Function,Array],fileListStyle:[String,Object],defaultFileList:{type:Array,default:()=>[]},showCancelButton:{type:Boolean,default:!0},showRemoveButton:{type:Boolean,default:!0},showDownloadButton:Boolean,showRetryButton:{type:Boolean,default:!0},showPreviewButton:{type:Boolean,default:!0},listType:{type:String,default:"text"},onPreview:Function,shouldUseThumbnailUrl:{type:Function,default:e=>Et?We(e):!1},createThumbnailUrl:Function,abstract:Boolean,max:Number,showTrigger:{type:Boolean,default:!0},imageGroupProps:Object,inputProps:Object,triggerStyle:[String,Object],renderIcon:Function}),Mr=V({name:"Upload",props:$r,setup(e){e.abstract&&e.listType==="image-card"&&me("upload","when the list-type is image-card, abstract is not supported.");const{mergedClsPrefixRef:r,inlineThemeDisabled:i}=ye(e),t=he("Upload","-upload",Nr,vr,e,r),n=vt(e),l=D(()=>{const{max:f}=e;return f!==void 0?h.value.length>=f:!1}),s=N(e.defaultFileList),c=A(e,"fileList"),d=N(null),a={value:!1},u=N(!1),g=new Map,x=Ot(c,s),h=D(()=>x.value.map(se));function _(){var f;(f=d.value)===null||f===void 0||f.click()}function b(f){const L=f.target;v(L.files?Array.from(L.files).map(O=>({file:O,entry:null,source:"input"})):null,f),L.value=""}function R(f){const{"onUpdate:fileList":L,onUpdateFileList:O}=e;L&&Se(L,f),O&&Se(O,f),s.value=f}const C=D(()=>e.multiple||e.directory);function v(f,L){if(!f||f.length===0)return;const{onBeforeUpload:O}=e;f=C.value?f:[f[0]];const{max:W,accept:E}=e;f=f.filter(({file:z,source:G})=>G==="dnd"&&(E!=null&&E.trim())?Ft(z.name,z.type,E):!0),W&&(f=f.slice(0,W-h.value.length));const j=ke();Promise.all(f.map(({file:z,entry:G})=>Ne(this,void 0,void 0,function*(){var X;const q={id:ke(),batchId:j,name:z.name,status:"pending",percentage:0,file:z,url:null,type:z.type,thumbnailUrl:null,fullPath:(X=G==null?void 0:G.fullPath)!==null&&X!==void 0?X:`/${z.webkitRelativePath||z.name}`};return!O||(yield O({file:q,fileList:h.value}))!==!1?q:null}))).then(z=>Ne(this,void 0,void 0,function*(){let G=Promise.resolve();z.forEach(X=>{G=G.then(yt).then(()=>{X&&S(X,L,{append:!0})})}),yield G})).then(()=>{e.defaultUpload&&k()})}function k(f){const{method:L,action:O,withCredentials:W,headers:E,data:j,name:z}=e,G=f!==void 0?h.value.filter(q=>q.id===f):h.value,X=f!==void 0;G.forEach(q=>{const{status:ce}=q;(ce==="pending"||ce==="error"&&X)&&(e.customRequest?Or({inst:{doChange:S,xhrMap:g,onFinish:e.onFinish,onError:e.onError},file:q,action:O,withCredentials:W,headers:E,data:j,customRequest:e.customRequest}):Ur({doChange:S,xhrMap:g,onFinish:e.onFinish,onError:e.onError,isErrorState:e.isErrorState},z,q,{method:L,action:O,withCredentials:W,responseType:e.responseType,headers:E,data:j}))})}const S=(f,L,O={append:!1,remove:!1})=>{const{append:W,remove:E}=O,j=Array.from(h.value),z=j.findIndex(G=>G.id===f.id);if(W||E||~z){W?j.push(f):E?j.splice(z,1):j.splice(z,1,f);const{onChange:G}=e;G&&G({file:f,fileList:j,event:L}),R(j)}};function p(f){var L;if(f.thumbnailUrl)return f.thumbnailUrl;const{createThumbnailUrl:O}=e;return O?(L=O(f.file,f))!==null&&L!==void 0?L:f.url||"":f.url?f.url:f.file?Wt(f.file):""}const w=D(()=>{const{common:{cubicBezierEaseInOut:f},self:{draggerColor:L,draggerBorder:O,draggerBorderHover:W,itemColorHover:E,itemColorHoverError:j,itemTextColorError:z,itemTextColorSuccess:G,itemTextColor:X,itemIconColor:q,itemDisabledOpacity:ce,lineHeight:Je,borderRadius:Ke,fontSize:et,itemBorderImageCardError:tt,itemBorderImageCard:rt}}=t.value;return{"--n-bezier":f,"--n-border-radius":Ke,"--n-dragger-border":O,"--n-dragger-border-hover":W,"--n-dragger-color":L,"--n-font-size":et,"--n-item-color-hover":E,"--n-item-color-hover-error":j,"--n-item-disabled-opacity":ce,"--n-item-icon-color":q,"--n-item-text-color":X,"--n-item-text-color-error":z,"--n-item-text-color-success":G,"--n-line-height":Je,"--n-item-border-image-card-error":tt,"--n-item-border-image-card":rt}}),T=i?Ee("upload",void 0,w,e):void 0;ze(ne,{mergedClsPrefixRef:r,mergedThemeRef:t,showCancelButtonRef:A(e,"showCancelButton"),showDownloadButtonRef:A(e,"showDownloadButton"),showRemoveButtonRef:A(e,"showRemoveButton"),showRetryButtonRef:A(e,"showRetryButton"),onRemoveRef:A(e,"onRemove"),onDownloadRef:A(e,"onDownload"),mergedFileListRef:h,triggerStyleRef:A(e,"triggerStyle"),shouldUseThumbnailUrlRef:A(e,"shouldUseThumbnailUrl"),renderIconRef:A(e,"renderIcon"),xhrMap:g,submit:k,doChange:S,showPreviewButtonRef:A(e,"showPreviewButton"),onPreviewRef:A(e,"onPreview"),getFileThumbnailUrlResolver:p,listTypeRef:A(e,"listType"),dragOverRef:u,openOpenFileDialog:_,draggerInsideRef:a,handleFileAddition:v,mergedDisabledRef:n.mergedDisabledRef,maxReachedRef:l,fileListStyleRef:A(e,"fileListStyle"),abstractRef:A(e,"abstract"),acceptRef:A(e,"accept"),cssVarsRef:i?void 0:w,themeClassRef:T==null?void 0:T.themeClass,onRender:T==null?void 0:T.onRender,showTriggerRef:A(e,"showTrigger"),imageGroupPropsRef:A(e,"imageGroupProps"),mergedDirectoryDndRef:D(()=>{var f;return(f=e.directoryDnd)!==null&&f!==void 0?f:e.directory})});const P={clear:()=>{s.value=[]},submit:k,openOpenFileDialog:_};return Object.assign({mergedClsPrefix:r,draggerInsideRef:a,inputElRef:d,mergedTheme:t,dragOver:u,mergedMultiple:C,cssVars:i?void 0:w,themeClass:T==null?void 0:T.themeClass,onRender:T==null?void 0:T.onRender,handleFileInputChange:b},P)},render(){var e,r;const{draggerInsideRef:i,mergedClsPrefix:t,$slots:n,directory:l,onRender:s}=this;if(n.default&&!this.abstract){const d=n.default()[0];!((e=d==null?void 0:d.type)===null||e===void 0)&&e[Xe]&&(i.value=!0)}const c=o("input",Object.assign({},this.inputProps,{ref:"inputElRef",type:"file",class:`${t}-upload-file-input`,accept:this.accept,multiple:this.mergedMultiple,onChange:this.handleFileInputChange,webkitdirectory:l||void 0,directory:l||void 0}));return this.abstract?o(ge,null,(r=n.default)===null||r===void 0?void 0:r.call(n),o(bt,{to:"body"},c)):(s==null||s(),o("div",{class:[`${t}-upload`,i.value&&`${t}-upload--dragger-inside`,this.dragOver&&`${t}-upload--drag-over`,this.themeClass],style:this.cssVars},c,this.showTrigger&&this.listType!=="image-card"&&o(qe,null,n),this.showFileList&&o(jr,null,n)))}});const ue=e=>(Tt("data-v-ccbf2cec"),e=e(),Dt(),e),Er={class:"head"},Fr={class:"name_degree"},Wr=["href"],Vr=ue(()=>y("span",null,"点击跳转到该学者的ORC主页",-1)),Hr={key:1,class:"name"},Zr={class:"rewards"},Yr={class:"reward"},Xr=["onClick"],qr=ue(()=>y("div",{class:"claim_describe"},[F(" 欢迎开始认领过程！请按照以下步骤操作："),y("br"),y("ol",null,[y("li",null,[y("span",{style:{"font-weight":"bold"}},"填写认领请求："),y("br"),F(" 在下方文本框中，请简明扼要地撰写一句认领请求。例如：“我是 "),y("span",{style:{"font-weight":"bold"}},"[您的姓名]"),F(" ，目前任职于 "),y("span",{style:{"font-weight":"bold"}},"[您的机构]"),F(" ，请求认领我的学者主页。”"),y("br")]),y("li",null,[y("span",{style:{"font-weight":"bold"}},"上传基本信息文件："),y("br"),F(" 请准备一份包含您的基本信息的文件。该文件应包含以下内容："),y("br"),F(" 姓名、联系方式（电子邮件地址等）、当前职位及工作单位、学术领域及研究兴趣、教育背景、重要论文及出版物（如适用）..."),y("br")])]),F(" 请确保您提供的信息准确无误，以便我们能快速有效地处理您的认领请求。"),y("br"),F(" 我们的联系邮箱：mewscience@163.com ")],-1)),Qr={class:"claim_buttons"},Jr={class:"bottom"},Kr={class:"visited_update_time"},eo={class:"bottom_number"},to={class:"content"},ro=ue(()=>y("p",null,"成果类型：专利",-1)),oo=ue(()=>y("p",null,"授权区域：中国",-1)),io={class:"projectContainer"},no=ue(()=>y("img",{class:"icon1",src:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGoAAABkCAIAAADhSTKwAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6REZERjA1RDE1RkFDMTFFQjk0QzhGM0EzQjk3MTBBOTEiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6REZERjA1RDI1RkFDMTFFQjk0QzhGM0EzQjk3MTBBOTEiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpERkRGMDVDRjVGQUMxMUVCOTRDOEYzQTNCOTcxMEE5MSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpERkRGMDVEMDVGQUMxMUVCOTRDOEYzQTNCOTcxMEE5MSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pt/A2wcAAAqsSURBVHja7J1bbBxXGYDnn5m9e+11SG0ncWjqQBFbRBylyAZc4iA7IFWREjVA85SLgDzakQjipcRRhHgAqfZjeGhsXiK1DjhFRWAXNVWC1BZHcVtiJEQdt+TWXLCzXtt7m3M4M+PdnZkz1/WO7VnNL8uePbM7u/Pt/5//NmcMGGNGLbO356am786nlhkvy47WxvbktkR92NV34ZUPhkcnRy5dv/LeDFMrcuzwnjN9vQSlS8cHWfvmU5lT594cHr3O1Jwk6iMXfvODg/ufcxHfoZMjY+PTTO3KOxd/2t25s+qHZWWbrW12RI6ffoNYmCv4zg69zdS6EH84MjpZfddBHAU5tGa0u7Otu6PNu7Bu3Z57933teY1N3Ow70VVlfB9O39V6q5f2XPjtD72ubkQt9h05rxyZmr5XfeOl4zv33PxaCjEgzYm4EcmyjC8+Ph+fj8/H54uPz8fn4/Px+eLj8/FtWOEreI1Y/Lk0STJwkkXuSm7tP95VG2nyWuAbGb3ef+7NUunxynszl8dv/vH80fbkFh+ftd4dO/06PbjvyPkbb/XROkjgnh2aoOuJVRHydn3Hu1xqYriCb2BoQnecWDEx5zN9vTRW9z46OT75elxqYrjiOj40rjiOjd/UjAy9dm0NTmBkXbuDzvA5qjiuTaN99s6cZ/Dt2GboYdu/ulUzcvTw82twAsdeet4z+M7099rf1d3Z5mqHP1EffvWVA0cP7/GM65CJnKUcyJn+Hl1MA/095McPXFRECKmR0cmpf4ktuvbkVgKUYPXDZtvTzeE9x9bVZPyc18fni4/Px+fj8/H5+Hzx8fn4fHw+Pl98fG5LJSWD+VRmZPQf8qXC3Z1tezt3+o1KuzI1fXffkfOlRuXwpeuEnd+otCVy80yzvoQMHjo5cuOtfnr9HWE99No1l9oRifrIq68cWF/Fd9yo1F2bQwgOXbiq26h0Yy1PScbGb5KvbR0V391Gpavsiu9y1TOe129UrgqfRxuVAAzLAxdis1ggP3mMMIPXYe470997xeC6i74TL2hGjNpyVZS+E11GjUoCKNgQaGRjgQjLR3k2ABCAj5ceIAZjEHcHgY2wgSgbaOTDcTa4FvhMGpW68/dAf0//iS6XrJh4XtrXE2ppIZ8Wcoso37A9mvmfwBBY8k9RECbqh7O48ETICgxGGRxmeQJxR7ChziHHChuVQxeuTUlrCQnQvuMvHNyfND7JsNs3FJClgBEBl0JZASNRxUTzVFgoaDkrB5ZQfiGXm83OJ7jws+FNTXzMxayj1KgkjnVt0FgKUbcUyhVQcVKzMbPpPuWxsPz39O2n+Gh7tNmOJrKrM5/1Z0f8wKP8EjFDhBGla2DmT4yB3i8sjqdmpjOPLD2Mt0sGGVSYL2TyZXDYTLXU9MyfUmDQR8sP/rbwaQHj2sRH2C2SIKSMSuEgoORIFA/BQvto+byQ/nPqPwtCrtbwLaMCwafxuYZah2mVVCkV1jducfiJkBlfmJkXMrWDL0dCXyTozWVgNsOBk/dQ4E2j3PjCrQwu1AI+EqDkKHYGXgBUxoudgAXV2CLK/TU1Q742b+Mj4W4eIfsq5Ej7QLWhNehHhaXrS/e8ja/gLF0F47lPx/NqVJbm/XHm4We5lFfxiekExrZiYbCM9FRZB7bwM+WZ8Nrif72LzyysUxkqpmhSbhmbpyEAypHSTLiAsjeW73sPn4DVEZ6ObmEq7lMYL1jOfWBGU/Hoo8yDbNGHVI5v9vacS6utjJyGLV9hDwHlebFV1FM+yBIqfJKdq7xkcHZoYrBYiN/R2jjQ1+N2ZXSFHTAOq5xgmzSIb6LdjanDAZZcDsnnkuHNleA7fvp15V0SpUWCb8zemdP0iUpCKE9N31klvkCQB1FDJL8LJMUVf1qa4s1NcedVFRPW2OhR8eGKW3ksLD8oLDbxMWf4hkcnde8wOTD49t6ONnpp3qlzfxpc9co2jgOi48Cxko1h2WUSiGTj5YPtp37cpUAFOgYL+roI1kkbvQeKR8R382mCz9ncZ7L+jt5FWA9WY1VgiKgeC0oLKm1fvDz1u4sfKMYp1ww2Z0I6sNHNoEuhIfNp7olj12HS1rryvvaGse9W6RayBJ8Jhn/femg3sQDDpAxo5gBGrkP+9VBYqmbgQnf7E/WRqhw5HDKbYeKxkHHFBWyVBPQioNJ+kDhj6pAZVCApsDN8B3sNl27TDcO+E9W5xwHPc0ZGR9j95OUO2qhtJCF2yi8yRlxK8fBKtrJy2JSQdeY6CJHhS5P0tQME015qWRsZfOfiSTL9PVldp+0Lm2IsB/InJyeDZRfMMHXx4I8O7GpuritmI7jsOjQuBFsEPTpJGygnOqwMXUojKZTjnVooIXLo5O+VAbM8qKtoZHDwlwdWm2+IUZ88k4sNRjlqkTcIOIFBOrEGtvK1ljENVud6IGeF4tdXOk4OCY7jvvbk1ltXf0HCl1Kjch1uxoArivKwufViywPSaTJf2eeXGpXrt6jSMv0AKm3AWs+Ltf5AEzaD6ghYabzFSVmMRb0nYK1gtPGCZatI7Wew/nyoJBxheQ/gA7BvpGDLr2LTqBkbfgas/jRxLlhLl4aDRcVFBQqwxVcAelFiWatJChlnvYAPKniNrufFjl6L6c8Aiqc0cmEyEXrCeMH2eZsar81ivcGUoXnu9kA945VqM1TlWbgC/TUsw2wPeggf2MyxsBlYMK4fmMyNoOy/Y1lrI8C1BGI1ho8x7FdgC/Uy8zgYq+M+8c+XQptCwHvJeMGWtVFxH7ZWTYMvAfQqMVjKNFi5Us94qNPGAuiUjSxnPjDajekaFagrLUb11S8GGzbzUe/hK5qwUcqmvUBtcTnryDlR5VKdYJD87YiW1xCwT1OVkrGJ6TVYzlKB8Cxr6kGx0nj/8Jd/phdzyp2xaNDczYJ++lYeIkq6O7IlwZWvqeXbk9s0x5qavrv7xcGNuUgyFOYbG6MIsNwzQlLXDUtqh0vKxzILy9lPPntc1iBp13NfaTGvOmCrjKaeDX890qT6RtuTW7o72jSdijVugTuSli3xaCwod9pkgitWy0qOUVwCU3yoBtOxa7tR2GwnKOKB3V//TAhUpW/xTUzuyrcB5fP7C/mCYBG2gPZKn6bNdd/91k5TT2NwUVBx3zdjrY2c9lJ4EZ+82MUr+Mh53buTKuRtXFxb/E3Y/epn32NM8KjTNCqKhm9EW54NbdJxaPKfgf4eDxEs5NH9O0/yeWQnXWveXPfrn3+fEDTJaaXABWN9V0zYbfmaesorP0v5H1LJfDcwOHF54ubG9Lwa4Thobo3zEU687kSa8qTerDT3SdNf81Pxnu98+eD+ZDgaWGmSyB0ScQMVWyXlQXk5EpIHpQ3ioDpj254JJgw9CtZreG5Yv0Gbco7DaSGLpHS0dBEM+RWNBCKxoKCgpsYn9pgQLm3Le5EEUXw52YhB4Nt1rQnObOmPPj5vSQYJKSGTw4J04a6Klwk+xCBBja+kfURznw427I40g1WuyDPelzDLhdjogpBLC7k8NlmjYSvIawnWJUObG7iQrUieqQkhalLPheJcMC3kF1B2WShYvkLTaQsC2xKo3xFM1HEBB+9bA8ZLSxYJaZRbQvklRCIcoWy/ateBGAgDG2eDjXykmY+x4Lgv8H8BBgAeNU0hDUCsrwAAAABJRU5ErkJggg==",alt:""},null,-1)),ao={__name:"Profile",props:{identity:Boolean,scholar:{default:{display_name:"",updated_date:"",last_known_institution:{display_name:"",ror:""},id:"",claim_info:{},followed:!1},type:Object}},setup(e){Oe(()=>{setTimeout(()=>{i.value=a.value.claim_info.has_been_claimed,t.value=a.value.followed,l.value=t.value?"已关注":"关注"},1e3)}),xt();const r=Ct();N("博士"),N("");let i=N(!1),t=N(!1);N("认领");let n=N(""),l=N("关注"),s=N(!1);N(!1),N(!1),N(!1);const c=e,{identity:d,scholar:a}=Rt(c),u=Yt(),g=N(0),x=N(null);N(""),kt([{label:"科研小白"},{label:"学界大牛"},{label:"科研达人"},{label:"理工男"},{label:"电竞选手"}]);function h(){Pe().then(P=>{P.errno!==0?u.warning("您尚未登录！"):Pt({research_id:a.value.id}).then(f=>{t.value=!0})})}function _(){Lt({research_id:a.value.id}).then(P=>{t.value=!1})}function b(){Pe().then(P=>{P.errno!==0?u.warning("您尚未登录！"):s.value=!0})}let R=[];function C(P){g.value=P.fileList.length,R=P.fileList}function v(){let P=new FormData;P.append("file",R[0].file),P.append("research_id",a.value.id),P.append("message",n.value),jt(P).then(f=>{}),s.value=!1,u.success("已提交认证申请，管理员正在加急审核中...")}function k(){let P="学者名："+a.value.display_name+" 链接："+window.location.href+" 来源：Mew Science";var f=document.createElement("input");document.body.appendChild(f),f.setAttribute("value",P),f.select(),document.execCommand("Copy"),document.body.removeChild(f),u.success("已复制分享链接，您可以将链接粘贴发送给他人。")}const S=N(!1),p=N(),w=P=>{Nt({id:P}).then(function(f){S.value=!0,p.value=f.data})};function T(P){r.push({name:"Institution",query:{id:parseInt(P.match(/\d+$/))}})}return(P,f)=>{const L=zt,O=qt,W=Qt,E=Jt;return Q(),K(ge,null,[M(B(De),{embedded:"",bordered:!1,hoverable:!0},{default:$(()=>[y("div",null,[y("div",Er,[y("div",Fr,[B(a).orcid!=null?(Q(),St(L,{key:0,trigger:"hover",placement:"right"},{trigger:$(()=>[y("a",{class:"name",href:B(a).orcid},Z(B(a).display_name),9,Wr)]),default:$(()=>[Vr]),_:1})):Be("",!0),B(a).orcid==null?(Q(),K("div",Hr,Z(B(a).display_name),1)):Be("",!0),y("a",{class:"institution",onClick:f[0]||(f[0]=j=>T(B(a).last_known_institution.id))},Z(B(a).last_known_institution.display_name),1)])]),M(B(Xt),{style:{margin:"10px"}})]),y("div",Zr,[(Q(!0),K(ge,null,_e(B(a).rewards,(j,z)=>(Q(),K("div",Yr,[y("span",{style:{cursor:"pointer"},onClick:G=>w(j.id)},Z(j.title)+"("+Z(j.year)+")",9,Xr)]))),256))]),M(B(fr),{cols:3,class:"buttons"},{default:$(()=>[M(B(ve),null,{default:$(()=>[fe(y("button",{class:"button",onClick:h},"关注",512),[[re,!B(t)]]),fe(y("button",{class:"button follow",onClick:_},"已关注",512),[[re,B(t)]])]),_:1}),M(B(ve),null,{default:$(()=>[y("button",{class:Bt(["button",{claim:B(i)}]),onClick:b},[fe(y("span",null,"已被认领",512),[[re,B(i)]]),fe(y("span",null,"认领",512),[[re,!B(i)]])],2),M(B(_t),{show:B(s),"onUpdate:show":f[2]||(f[2]=j=>Te(s)?s.value=j:s=j)},{default:$(()=>[M(B(De),{style:{width:"600px"},title:"认领您的学者主页",bordered:!1,size:"huge",role:"dialog","aria-modal":"true",class:"claim_show"},{footer:$(()=>[y("div",Qr,[M(B(J),{strong:"",secondary:"",round:"",onClick:P.cancelClaim,class:"claim_button"},{default:$(()=>[F(" 取消 ")]),_:1},8,["onClick"]),M(B(J),{strong:"",secondary:"",round:"",type:"success",disabled:!g.value,onClick:v,class:"claim_button"},{default:$(()=>[F(" 提交 ")]),_:1},8,["disabled"])])]),default:$(()=>[qr,M(B(Zt),{value:B(n),"onUpdate:value":f[1]||(f[1]=j=>Te(n)?n.value=j:n=j),type:"textarea",placeholder:"请输入认领请求",style:{"margin-top":"10px"}},null,8,["value"]),M(B(Mr),{ref_key:"upload",ref:x,"default-upload":!1,multiple:"",action:"http://121.36.65.25:8080/api/portal/claim",headers:{"X-Csrftoken":"W2Umf5amOWWQxTCDLAZ28AkXIvOd9tKY"},data:{research_id:B(a).id,message:B(n)},change:C},{default:$(()=>[M(B(J),{strong:"",secondary:"",round:"",class:"claim_button",style:{"margin-top":"10px"}},{default:$(()=>[F("选择文件")]),_:1})]),_:1},8,["data"])]),_:1})]),_:1},8,["show"])]),_:1}),M(B(ve),null,{default:$(()=>[y("button",{class:"button",onClick:k},"分享")]),_:1})]),_:1}),y("div",Jr,[y("div",Kr,[F("更新时间 "),y("span",eo,Z(B(a).updated_date),1)])])]),_:1}),M(E,{show:S.value,"onUpdate:show":f[3]||(f[3]=j=>S.value=j),width:502,placement:P.placement},{default:$(()=>[M(W,null,{default:$(()=>[y("h2",null,Z(p.value.title),1),M(O,{prefix:"bar","align-text":"",type:"info"},{default:$(()=>[F(" 基本信息 ")]),_:1}),y("div",to,[y("p",null,"作者:"+Z(p.value.authors),1),ro,y("p",null,"授奖机构："+Z(p.value.award_institution),1),y("p",null,"获奖日期："+Z(p.value.year),1),oo]),M(O,{prefix:"bar","align-text":"",type:"info",class:"title1"},{default:$(()=>[F(" 相关项目 ")]),_:1}),(Q(!0),K(ge,null,_e(p.value.projects,(j,z)=>(Q(),K("div",io,[no,y("p",null,Z(j.title),1)]))),256))]),_:1})]),_:1},8,["show","placement"])],64)}}},ko=wt(ao,[["__scopeId","data-v-ccbf2cec"]]);export{ko as default};
