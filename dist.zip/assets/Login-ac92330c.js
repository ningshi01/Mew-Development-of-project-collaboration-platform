import{aR as St,aS as Ct,c as Rt,aT as Ge,aU as zt,aV as Pt,aW as kt,aX as It,e as ae,u as xe,r as I,aY as Nt,j as R,aZ as Tt,h as m,aA as Je,a_ as Qe,b as Dt,a$ as c,a as j,d as p,b0 as Vt,w as $t,b1 as Et,b2 as pe,b3 as je,g as et,i as Mt,b4 as Bt,b5 as Oe,b6 as Ue,b7 as At,b8 as Lt,T as jt,b9 as Xe,ba as ne,bb as Ot,bc as Ut,bd as oe,aK as Xt,be as Ft,aC as ke,aD as Yt,aG as h,aI as C,aL as M,aF as me,bf as Kt,aE as Fe,bg as Ye,aJ as Wt,aN as Zt,bh as qt,aP as Ht,aQ as Gt,az as Jt}from"./index-b27597f8.js";import{a as Qt,b as en}from"./index-eb756369.js";import{N as tn}from"./text-ef93c62a.js";import{c as nn,_ as on}from"./Image-1a0c3b52.js";import{a as an}from"./Popover-61edb1a7.js";import{u as ln}from"./use-message-cf8630a3.js";import{N as sn}from"./Input-f8b5fbf4.js";import{_ as rn}from"./Space-895d0d22.js";import"./light-5e5d12e6.js";import"./Tooltip-a25626bb.js";import"./use-locale-c044757c.js";import"./format-length-c9d165c6.js";import"./get-slot-1efb97e5.js";function un(e){return St(Ct(e).toLowerCase())}var cn=nn(function(e,o,a){return o=o.toLowerCase(),e+(a?un(o):o)});const Ke=cn,dn=e=>({dotSize:"8px",dotColor:"rgba(255, 255, 255, .3)",dotColorActive:"rgba(255, 255, 255, 1)",dotColorFocus:"rgba(255, 255, 255, .5)",dotLineWidth:"16px",dotLineWidthActive:"24px",arrowColor:"#eee"}),fn={name:"Carousel",common:Rt,self:dn},vn=fn;function pn(e){const{length:o}=e;return o>1&&(e.push(We(e[0],0,"append")),e.unshift(We(e[o-1],o-1,"prepend"))),e}function We(e,o,a){return Ge(e,{key:`carousel-item-duplicate-${o}-${a}`})}function Ze(e,o,a){return a?e===0?o-3:e===o-1?0:e-1:e}function Ie(e,o){return o?e+1:e}function hn(e,o,a){return e<0?null:e===0?a?o-1:null:e-1}function gn(e,o,a){return e>o-1?null:e===o-1?a?0:null:e+1}function mn(e,o){return o&&e>3?e-2:e}function qe(e){return window.TouchEvent&&e instanceof window.TouchEvent}function He(e,o){let{offsetWidth:a,offsetHeight:s}=e;if(o){const d=getComputedStyle(e);a=a-parseFloat(d.getPropertyValue("padding-left"))-parseFloat(d.getPropertyValue("padding-right")),s=s-parseFloat(d.getPropertyValue("padding-top"))-parseFloat(d.getPropertyValue("padding-bottom"))}return{width:a,height:s}}function he(e,o,a){return e<o?o:e>a?a:e}function xn(e){if(e===void 0)return 0;if(typeof e=="number")return e;const o=/^((\d+)?\.?\d+?)(ms|s)?$/,a=e.match(o);if(a){const[,s,,d="ms"]=a;return Number(s)*(d==="ms"?1:1e3)}return 0}const tt=It("n-carousel-methods"),bn=e=>{zt(tt,e)},Te=(e="unknown",o="component")=>{const a=Pt(tt);return a||kt(e,`\`${o}\` must be placed inside \`n-carousel\`.`),a},wn={total:{type:Number,default:0},currentIndex:{type:Number,default:0},dotType:{type:String,default:"dot"},trigger:{type:String,default:"click"},keyboard:Boolean},yn=ae({name:"CarouselDots",props:wn,setup(e){const{mergedClsPrefixRef:o}=xe(e),a=I([]),s=Te();function d(g,f){switch(g.key){case"Enter":case" ":g.preventDefault(),s.to(f);return}e.keyboard&&z(g)}function w(g){e.trigger==="hover"&&s.to(g)}function N(g){e.trigger==="click"&&s.to(g)}function z(g){var f;if(g.shiftKey||g.altKey||g.ctrlKey||g.metaKey)return;const x=(f=document.activeElement)===null||f===void 0?void 0:f.nodeName.toLowerCase();if(x==="input"||x==="textarea")return;const{code:k}=g,O=k==="PageUp"||k==="ArrowUp",X=k==="PageDown"||k==="ArrowDown",T=k==="PageUp"||k==="ArrowRight",y=k==="PageDown"||k==="ArrowLeft",v=s.isVertical(),_=v?O:T,$=v?X:y;!_&&!$||(g.preventDefault(),_&&!s.isNextDisabled()?(s.next(),P(s.currentIndexRef.value)):$&&!s.isPrevDisabled()&&(s.prev(),P(s.currentIndexRef.value)))}function P(g){var f;(f=a.value[g])===null||f===void 0||f.focus()}return Nt(()=>a.value.length=0),{mergedClsPrefix:o,dotEls:a,handleKeydown:d,handleMouseenter:w,handleClick:N}},render(){const{mergedClsPrefix:e,dotEls:o}=this;return R("div",{class:[`${e}-carousel__dots`,`${e}-carousel__dots--${this.dotType}`],role:"tablist"},Tt(this.total,a=>{const s=a===this.currentIndex;return R("div",{"aria-selected":s,ref:d=>o.push(d),role:"button",tabindex:"0",class:[`${e}-carousel__dot`,s&&`${e}-carousel__dot--active`],key:a,onClick:()=>{this.handleClick(a)},onMouseenter:()=>{this.handleMouseenter(a)},onKeydown:d=>{this.handleKeydown(d,a)}})}))}}),_n=R("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},R("g",{fill:"none"},R("path",{d:"M10.26 3.2a.75.75 0 0 1 .04 1.06L6.773 8l3.527 3.74a.75.75 0 1 1-1.1 1.02l-4-4.25a.75.75 0 0 1 0-1.02l4-4.25a.75.75 0 0 1 1.06-.04z",fill:"currentColor"}))),Sn=R("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},R("g",{fill:"none"},R("path",{d:"M5.74 3.2a.75.75 0 0 0-.04 1.06L9.227 8L5.7 11.74a.75.75 0 1 0 1.1 1.02l4-4.25a.75.75 0 0 0 0-1.02l-4-4.25a.75.75 0 0 0-1.06-.04z",fill:"currentColor"}))),Cn=ae({name:"CarouselArrow",setup(e){const{mergedClsPrefixRef:o}=xe(e),{isVertical:a,isPrevDisabled:s,isNextDisabled:d,prev:w,next:N}=Te();return{mergedClsPrefix:o,isVertical:a,isPrevDisabled:s,isNextDisabled:d,prev:w,next:N}},render(){const{mergedClsPrefix:e}=this;return R("div",{class:`${e}-carousel__arrow-group`},R("div",{class:[`${e}-carousel__arrow`,this.isPrevDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.prev},_n),R("div",{class:[`${e}-carousel__arrow`,this.isNextDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.next},Sn))}}),ge="CarouselItem",Rn=e=>{var o;return((o=e.type)===null||o===void 0?void 0:o.name)===ge},zn=ae({name:ge,setup(e){const{mergedClsPrefixRef:o}=xe(e),a=Te(Ke(ge),`n-${Ke(ge)}`),s=I(),d=m(()=>{const{value:f}=s;return f?a.getSlideIndex(f):-1}),w=m(()=>a.isPrev(d.value)),N=m(()=>a.isNext(d.value)),z=m(()=>a.isActive(d.value)),P=m(()=>a.getSlideStyle(d.value));Je(()=>{a.addSlide(s.value)}),Qe(()=>{a.removeSlide(s.value)});function g(f){const{value:x}=d;x!==void 0&&(a==null||a.onCarouselItemClick(x,f))}return{mergedClsPrefix:o,selfElRef:s,isPrev:w,isNext:N,isActive:z,index:d,style:P,handleClick:g}},render(){var e;const{$slots:o,mergedClsPrefix:a,isPrev:s,isNext:d,isActive:w,index:N,style:z}=this,P=[`${a}-carousel__slide`,{[`${a}-carousel__slide--current`]:w,[`${a}-carousel__slide--prev`]:s,[`${a}-carousel__slide--next`]:d}];return R("div",{ref:"selfElRef",class:P,role:"option",tabindex:"-1","data-index":N,"aria-hidden":!w,style:z,onClickCapture:this.handleClick},(e=o.default)===null||e===void 0?void 0:e.call(o,{isPrev:s,isNext:d,isActive:w,index:N}))}}),Pn=Dt("carousel",`
 position: relative;
 width: 100%;
 height: 100%;
 touch-action: pan-y;
 overflow: hidden;
`,[c("slides",`
 display: flex;
 width: 100%;
 height: 100%;
 transition-timing-function: var(--n-bezier);
 transition-property: transform;
 `,[c("slide",`
 flex-shrink: 0;
 position: relative;
 width: 100%;
 height: 100%;
 outline: none;
 overflow: hidden;
 `,[j("> img",`
 display: block;
 `)])]),c("dots",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `,[p("dot",[c("dot",`
 height: var(--n-dot-size);
 width: var(--n-dot-size);
 background-color: var(--n-dot-color);
 border-radius: 50%;
 cursor: pointer;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[j("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),p("active",`
 background-color: var(--n-dot-color-active);
 `)])]),p("line",[c("dot",`
 border-radius: 9999px;
 width: var(--n-dot-line-width);
 height: 4px;
 background-color: var(--n-dot-color);
 cursor: pointer;
 transition:
 width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[j("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),p("active",`
 width: var(--n-dot-line-width-active);
 background-color: var(--n-dot-color-active);
 `)])])]),c("arrow",`
 transition: background-color .3s var(--n-bezier);
 cursor: pointer;
 height: 28px;
 width: 28px;
 display: flex;
 align-items: center;
 justify-content: center;
 background-color: rgba(255, 255, 255, .2);
 color: var(--n-arrow-color);
 border-radius: 8px;
 user-select: none;
 -webkit-user-select: none;
 font-size: 18px;
 `,[j("svg",`
 height: 1em;
 width: 1em;
 `),j("&:hover",`
 background-color: rgba(255, 255, 255, .3);
 `)]),p("vertical",`
 touch-action: pan-x;
 `,[c("slides",`
 flex-direction: column;
 `),p("fade",[c("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%);
 `)]),p("card",[c("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%) translateZ(-400px);
 `,[p("current",`
 transform: translateY(-50%) translateZ(0);
 `),p("prev",`
 transform: translateY(-100%) translateZ(-200px);
 `),p("next",`
 transform: translateY(0%) translateZ(-200px);
 `)])])]),p("usercontrol",[c("slides",[j(">",[j("div",`
 position: absolute;
 top: 50%;
 left: 50%;
 width: 100%;
 height: 100%;
 transform: translate(-50%, -50%);
 `)])])]),p("left",[c("dots",`
 transform: translateY(-50%);
 top: 50%;
 left: 12px;
 flex-direction: column;
 `,[p("line",[c("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[p("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),c("dot",`
 margin: 4px 0;
 `)]),c("arrow-group",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `),p("vertical",[c("arrow",`
 transform: rotate(90deg);
 `)]),p("show-arrow",[p("bottom",[c("dots",`
 transform: translateX(0);
 bottom: 18px;
 left: 18px;
 `)]),p("top",[c("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),p("left",[c("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),p("right",[c("dots",`
 transform: translateX(0);
 top: 18px;
 right: 18px;
 `)])]),p("left",[c("arrow-group",`
 bottom: 12px;
 left: 12px;
 flex-direction: column;
 `,[j("> *:first-child",`
 margin-bottom: 12px;
 `)])]),p("right",[c("dots",`
 transform: translateY(-50%);
 top: 50%;
 right: 12px;
 flex-direction: column;
 `,[p("line",[c("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[p("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),c("dot",`
 margin: 4px 0;
 `),c("arrow-group",`
 bottom: 12px;
 right: 12px;
 flex-direction: column;
 `,[j("> *:first-child",`
 margin-bottom: 12px;
 `)])]),p("top",[c("dots",`
 transform: translateX(-50%);
 top: 12px;
 left: 50%;
 `,[p("line",[c("dot",`
 margin: 0 4px;
 `)])]),c("dot",`
 margin: 0 4px;
 `),c("arrow-group",`
 top: 12px;
 right: 12px;
 `,[j("> *:first-child",`
 margin-right: 12px;
 `)])]),p("bottom",[c("dots",`
 transform: translateX(-50%);
 bottom: 12px;
 left: 50%;
 `,[p("line",[c("dot",`
 margin: 0 4px;
 `)])]),c("dot",`
 margin: 0 4px;
 `),c("arrow-group",`
 bottom: 12px;
 right: 12px;
 `,[j("> *:first-child",`
 margin-right: 12px;
 `)])]),p("fade",[c("slide",`
 position: absolute;
 opacity: 0;
 transition-property: opacity;
 pointer-events: none;
 `,[p("current",`
 opacity: 1;
 pointer-events: auto;
 `)])]),p("card",[c("slides",`
 perspective: 1000px;
 `),c("slide",`
 position: absolute;
 left: 50%;
 opacity: 0;
 transform: translateX(-50%) translateZ(-400px);
 transition-property: opacity, transform;
 `,[p("current",`
 opacity: 1;
 transform: translateX(-50%) translateZ(0);
 z-index: 1;
 `),p("prev",`
 opacity: 0.4;
 transform: translateX(-100%) translateZ(-200px);
 `),p("next",`
 opacity: 0.4;
 transform: translateX(0%) translateZ(-200px);
 `)])])]),kn=["transitionDuration","transitionTimingFunction"],In=Object.assign(Object.assign({},et.props),{defaultIndex:{type:Number,default:0},currentIndex:Number,showArrow:Boolean,dotType:{type:String,default:"dot"},dotPlacement:{type:String,default:"bottom"},slidesPerView:{type:[Number,String],default:1},spaceBetween:{type:Number,default:0},centeredSlides:Boolean,direction:{type:String,default:"horizontal"},autoplay:Boolean,interval:{type:Number,default:5e3},loop:{type:Boolean,default:!0},effect:{type:String,default:"slide"},showDots:{type:Boolean,default:!0},trigger:{type:String,default:"click"},transitionStyle:{type:Object,default:()=>({transitionDuration:"300ms"})},transitionProps:Object,draggable:Boolean,prevSlideStyle:[Object,String],nextSlideStyle:[Object,String],touchable:{type:Boolean,default:!0},mousewheel:Boolean,keyboard:Boolean,"onUpdate:currentIndex":Function,onUpdateCurrentIndex:Function});let Ne=!1;const Nn=ae({name:"Carousel",props:In,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:a}=xe(e),s=I(null),d=I(null),w=I([]),N={value:[]},z=m(()=>e.direction==="vertical"),P=m(()=>z.value?"height":"width"),g=m(()=>z.value?"bottom":"right"),f=m(()=>e.effect==="slide"),x=m(()=>e.loop&&e.slidesPerView===1&&f.value),k=m(()=>e.effect==="custom"),O=m(()=>!f.value||e.centeredSlides?1:e.slidesPerView),X=m(()=>k.value?1:e.slidesPerView),T=m(()=>O.value==="auto"||e.slidesPerView==="auto"&&e.centeredSlides),y=I({width:0,height:0}),v=m(()=>{const{value:t}=w;if(!t.length)return[];const{value:n}=T;if(n)return t.map(S=>He(S));const{value:l}=X,{value:i}=y,{value:u}=P;let r=i[u];if(l!=="auto"){const{spaceBetween:S}=e,E=r-(l-1)*S,ve=1/Math.max(1,l);r=E*ve}const b=Object.assign(Object.assign({},i),{[u]:r});return t.map(()=>b)}),_=m(()=>{const{value:t}=v;if(!t.length)return[];const{centeredSlides:n,spaceBetween:l}=e,{value:i}=P,{[i]:u}=y.value;let r=0;return t.map(({[i]:b})=>{let S=r;return n&&(S+=(b-u)/2),r+=b+l,S})}),$=I(!1),G=m(()=>{const{transitionStyle:t}=e;return t?Xe(t,kn):{}}),J=m(()=>k.value?0:xn(G.value.transitionDuration)),U=m(()=>{const{value:t}=w;if(!t.length)return[];const n=!(T.value||X.value===1),l=b=>{if(n){const{value:S}=P;return{[S]:`${v.value[b][S]}px`}}};if(k.value)return t.map((b,S)=>l(S));const{effect:i,spaceBetween:u}=e,{value:r}=g;return t.reduce((b,S,E)=>{const ve=Object.assign(Object.assign({},l(E)),{[`margin-${r}`]:`${u}px`});return b.push(ve),$.value&&(i==="fade"||i==="card")&&Object.assign(ve,G.value),b},[])}),V=m(()=>{const{value:t}=O,{length:n}=w.value;if(t!=="auto")return Math.max(n-t,0)+1;{const{value:l}=v,{length:i}=l;if(!i)return n;const{value:u}=_,{value:r}=P,b=y.value[r];let S=l[l.length-1][r],E=i;for(;E>1&&S<b;)E--,S+=u[E]-u[E-1];return he(E+1,1,i)}}),K=m(()=>mn(V.value,x.value)),D=Ie(e.defaultIndex,x.value),be=I(Ze(D,V.value,x.value)),B=an(Vt(e,"currentIndex"),be),A=m(()=>Ie(B.value,x.value));function Q(t){var n,l;t=he(t,0,V.value-1);const i=Ze(t,V.value,x.value),{value:u}=B;i!==B.value&&(be.value=i,(n=e["onUpdate:currentIndex"])===null||n===void 0||n.call(e,i,u),(l=e.onUpdateCurrentIndex)===null||l===void 0||l.call(e,i,u))}function le(t=A.value){return hn(t,V.value,e.loop)}function se(t=A.value){return gn(t,V.value,e.loop)}function ot(t){const n=W(t);return n!==null&&le()===n}function at(t){const n=W(t);return n!==null&&se()===n}function De(t){return A.value===W(t)}function lt(t){return B.value===t}function Ve(){return le()===null}function $e(){return se()===null}function we(t){const n=he(Ie(t,x.value),0,V.value);(t!==B.value||n!==A.value)&&Q(n)}function ye(){const t=le();t!==null&&Q(t)}function re(){const t=se();t!==null&&Q(t)}function st(){(!L||!x.value)&&ye()}function rt(){(!L||!x.value)&&re()}let L=!1,Y=0;const _e=I({});function ie(t,n=0){_e.value=Object.assign({},G.value,{transform:z.value?`translateY(${-t}px)`:`translateX(${-t}px)`,transitionDuration:`${n}ms`})}function ee(t=0){f.value?Se(A.value,t):Y!==0&&(!L&&t>0&&(L=!0),ie(Y=0,t))}function Se(t,n){const l=Ee(t);l!==Y&&n>0&&(L=!0),Y=Ee(A.value),ie(l,n)}function Ee(t){let n;return t>=V.value-1?n=Me():n=_.value[t]||0,n}function Me(){if(O.value==="auto"){const{value:t}=P,{[t]:n}=y.value,{value:l}=_,i=l[l.length-1];let u;if(i===void 0)u=n;else{const{value:r}=v;u=i+r[r.length-1][t]}return u-n}else{const{value:t}=_;return t[V.value-1]||0}}const te={currentIndexRef:B,to:we,prev:st,next:rt,isVertical:()=>z.value,isHorizontal:()=>!z.value,isPrev:ot,isNext:at,isActive:De,isPrevDisabled:Ve,isNextDisabled:$e,getSlideIndex:W,getSlideStyle:ct,addSlide:it,removeSlide:ut,onCarouselItemClick:dt};bn(te);function it(t){t&&w.value.push(t)}function ut(t){if(!t)return;const n=W(t);n!==-1&&w.value.splice(n,1)}function W(t){return typeof t=="number"?t:t?w.value.indexOf(t):-1}function ct(t){const n=W(t);if(n!==-1){const l=[U.value[n]],i=te.isPrev(n),u=te.isNext(n);return i&&l.push(e.prevSlideStyle||""),u&&l.push(e.nextSlideStyle||""),Ot(l)}}function dt(t,n){let l=!L&&!de&&!Pe;e.effect==="card"&&l&&!De(t)&&(we(t),l=!1),l||(n.preventDefault(),n.stopPropagation())}let ue=null;function ce(){ue&&(clearInterval(ue),ue=null)}function Z(){ce(),!e.autoplay||K.value<2||(ue=window.setInterval(re,e.interval))}let Ce=0,Re=0,F=0,ze=0,de=!1,Pe=!1;function Be(t){var n;if(Ne||!(!((n=d.value)===null||n===void 0)&&n.contains(Ut(t))))return;Ne=!0,de=!0,Pe=!1,ze=Date.now(),ce(),t.type!=="touchstart"&&!t.target.isContentEditable&&t.preventDefault();const l=qe(t)?t.touches[0]:t;z.value?Re=l.clientY:Ce=l.clientX,e.touchable&&(oe("touchmove",document,fe,{passive:!0}),oe("touchend",document,q),oe("touchcancel",document,q)),e.draggable&&(oe("mousemove",document,fe),oe("mouseup",document,q))}function fe(t){const{value:n}=z,{value:l}=P,i=qe(t)?t.touches[0]:t,u=n?i.clientY-Re:i.clientX-Ce,r=y.value[l];F=he(u,-r,r),t.cancelable&&t.preventDefault(),f.value&&ie(Y-F,0)}function q(){const{value:t}=A;let n=t;if(!L&&F!==0&&f.value){const l=Y-F,i=[..._.value.slice(0,V.value-1),Me()];let u=null;for(let r=0;r<i.length;r++){const b=Math.abs(i[r]-l);if(u!==null&&u<b)break;u=b,n=r}}if(n===t){const l=Date.now()-ze,{value:i}=P,u=y.value[i];F>u/2||F/l>.4?n=le(t):(F<-u/2||F/l<-.4)&&(n=se(t))}n!==null&&n!==t?(Pe=!0,Q(n),je(()=>{(!x.value||be.value!==B.value)&&ee(J.value)})):ee(J.value),Ae(),Z()}function Ae(){de&&(Ne=!1),de=!1,Ce=0,Re=0,F=0,ze=0,ne("touchmove",document,fe),ne("touchend",document,q),ne("touchcancel",document,q),ne("mousemove",document,fe),ne("mouseup",document,q)}function ft(){if(f.value&&L){const{value:t}=A;Se(t,0)}else Z();f.value&&(_e.value.transitionDuration="0ms"),L=!1}function vt(t){if(t.preventDefault(),L)return;let{deltaX:n,deltaY:l}=t;t.shiftKey&&!n&&(n=l);const i=-1,u=1,r=(n||l)>0?u:i;let b=0,S=0;z.value?S=r:b=r;const E=10;(S*l>=E||b*n>=E)&&(r===u&&!$e()?re():r===i&&!Ve()&&ye())}function pt(){y.value=He(s.value,!0),Z()}function ht(){var t,n;T.value&&((n=(t=v.effect).scheduler)===null||n===void 0||n.call(t),v.effect.run())}function gt(){e.autoplay&&ce()}function mt(){e.autoplay&&Z()}Je(()=>{$t(Z),requestAnimationFrame(()=>$.value=!0)}),Qe(()=>{Ae(),ce()}),Et(()=>{const{value:t}=w,{value:n}=N,l=new Map,i=r=>l.has(r)?l.get(r):-1;let u=!1;for(let r=0;r<t.length;r++){const b=n.findIndex(S=>S.el===t[r]);b!==r&&(u=!0),l.set(t[r],b)}u&&t.sort((r,b)=>i(r)-i(b))}),pe(A,(t,n)=>{if(t!==n)if(Z(),f.value){if(x.value&&K.value>2){const{value:l}=V;t===l-2&&n===1?t=0:t===1&&n===l-2&&(t=l-1)}Se(t,J.value)}else ee()},{immediate:!0}),pe([x,O],()=>void je(()=>{Q(A.value)})),pe(_,()=>{f.value&&ee()},{deep:!0}),pe(f,t=>{t?ee():(L=!1,ie(Y=0))});const xt=m(()=>({onTouchstartPassive:e.touchable?Be:void 0,onMousedown:e.draggable?Be:void 0,onWheel:e.mousewheel?vt:void 0})),bt=m(()=>Object.assign(Object.assign({},Xe(te,["to","prev","next","isPrevDisabled","isNextDisabled"])),{total:K.value,currentIndex:B.value})),wt=m(()=>({total:K.value,currentIndex:B.value,to:te.to})),yt={getCurrentIndex:()=>B.value,to:we,prev:ye,next:re},_t=et("Carousel","-carousel",Pn,vn,e,o),Le=m(()=>{const{common:{cubicBezierEaseInOut:t},self:{dotSize:n,dotColor:l,dotColorActive:i,dotColorFocus:u,dotLineWidth:r,dotLineWidthActive:b,arrowColor:S}}=_t.value;return{"--n-bezier":t,"--n-dot-color":l,"--n-dot-color-focus":u,"--n-dot-color-active":i,"--n-dot-size":n,"--n-dot-line-width":r,"--n-dot-line-width-active":b,"--n-arrow-color":S}}),H=a?Mt("carousel",void 0,Le,e):void 0;return Object.assign(Object.assign({mergedClsPrefix:o,selfElRef:s,slidesElRef:d,slideVNodes:N,duplicatedable:x,userWantsControl:k,autoSlideSize:T,displayIndex:B,realIndex:A,slideStyles:U,translateStyle:_e,slidesControlListeners:xt,handleTransitionEnd:ft,handleResize:pt,handleSlideResize:ht,handleMouseenter:gt,handleMouseleave:mt,isActive:lt,arrowSlotProps:bt,dotSlotProps:wt},yt),{cssVars:a?void 0:Le,themeClass:H==null?void 0:H.themeClass,onRender:H==null?void 0:H.onRender})},render(){var e;const{mergedClsPrefix:o,showArrow:a,userWantsControl:s,slideStyles:d,dotType:w,dotPlacement:N,slidesControlListeners:z,transitionProps:P={},arrowSlotProps:g,dotSlotProps:f,$slots:{default:x,dots:k,arrow:O}}=this,X=x&&Bt(x())||[];let T=Tn(X);return T.length||(T=X.map(y=>R(zn,null,{default:()=>Ge(y)}))),this.duplicatedable&&(T=pn(T)),this.slideVNodes.value=T,this.autoSlideSize&&(T=T.map(y=>R(Oe,{onResize:this.handleSlideResize},{default:()=>y}))),(e=this.onRender)===null||e===void 0||e.call(this),R("div",Object.assign({ref:"selfElRef",class:[this.themeClass,`${o}-carousel`,this.direction==="vertical"&&`${o}-carousel--vertical`,this.showArrow&&`${o}-carousel--show-arrow`,`${o}-carousel--${N}`,`${o}-carousel--${this.direction}`,`${o}-carousel--${this.effect}`,s&&`${o}-carousel--usercontrol`],style:this.cssVars},z,{onMouseenter:this.handleMouseenter,onMouseleave:this.handleMouseleave}),R(Oe,{onResize:this.handleResize},{default:()=>R("div",{ref:"slidesElRef",class:`${o}-carousel__slides`,role:"listbox",style:this.translateStyle,onTransitionend:this.handleTransitionEnd},s?T.map((y,v)=>R("div",{style:d[v],key:v},At(R(jt,Object.assign({},P),{default:()=>y}),[[Lt,this.isActive(v)]]))):T)}),this.showDots&&f.total>1&&Ue(k,f,()=>[R(yn,{key:w+N,total:f.total,currentIndex:f.currentIndex,dotType:w,trigger:this.trigger,keyboard:this.keyboard})]),a&&Ue(O,g,()=>[R(Cn,null)]))}});function Tn(e){return e.reduce((o,a)=>(Rn(a)&&o.push(a),o),[])}const Dn="/assets/scholarPage-b770aa5d.jpg",nt=e=>(Ht("data-v-dd683f7f"),e=e(),Gt(),e),Vn=nt(()=>me("div",{style:{background:"linear-gradient(#add8e6,#87cefa,#b0e0e6)",width:"60%",height:"100%"}},null,-1)),$n=nt(()=>me("img",{class:"carousel-img",src:Dn},null,-1)),En={style:{display:"flex","flex-direction":"column","align-items":"center",left:"16%",top:"67%",position:"absolute"}},Mn=ae({__name:"Login",setup(e){const o=ln(),a=Xt();Ft();const s=I(!0),d=I(!1),w=I(""),N=I(""),z=I(""),P=I(""),g=I(""),f=I(""),x=I(""),k=I(0),O=()=>{Qt({username:w.value,password:N.value}).then(y=>{console.log(y),k.value=y.data.identify,k.value==0&&a.push("/Introduction"),k.value==1&&a.push("/admin")})},X=()=>{en({username:z.value,password:P.value,email:g.value,first_name:f.value,last_name:x.value}).then(y=>{y.errno==0&&(o.success("注册成功"),s.value=!0,d.value=!1),y.errno==10001&&o.error("用户名已存在")})},T=()=>{a.push("/Introduction")};return(y,v)=>{const _=tn,$=Zt,G=Nn,J=on,U=sn,V=qt,K=rn;return ke(),Yt(Wt,null,[Vn,h(K,{class:"card-container"},{default:C(()=>[h($,{onClick:T,bordered:!1,class:"introButton"},{default:C(()=>[h(_,{style:{"font-weight":"bold",color:"#f8f8f8","font-size":"16px"}},{default:C(()=>[M("平台介绍")]),_:1})]),_:1}),h(G,{autoplay:"",class:"carousel",interval:"4000"},{default:C(()=>[$n]),_:1}),me("div",En,[h(_,{style:{"font-weight":"bold",color:"black","font-size":"23px"}},{default:C(()=>[M("MewSci学者门户")]),_:1}),h(_,{style:{"font-size":"18px",color:"black","margin-top":"4%"}},{default:C(()=>[M("详尽的数据陈列，生动的图表展示，让科研变得更简单")]),_:1})]),h(J,{src:"src/assets/tempLogo.png",class:"logo",onClick:v[0]||(v[0]=Kt(()=>{},["prevent"]))}),s.value?(ke(),Fe(V,{key:0,class:"card"},{default:C(()=>[h(_,{class:"text"},{default:C(()=>[M(" 欢迎使用MewScience ")]),_:1}),h(U,{value:w.value,"onUpdate:value":v[1]||(v[1]=D=>w.value=D),size:"large",round:"",placeholder:"请输入用户名",class:"input"},null,8,["value"]),h(U,{value:N.value,"onUpdate:value":v[2]||(v[2]=D=>N.value=D),size:"large",round:"",placeholder:"请输入密码",class:"input"},null,8,["value"]),h($,{round:"",type:"info",class:"loginButton",onClick:O},{default:C(()=>[h(_,{class:"loginText"},{default:C(()=>[M(" 登录 ")]),_:1})]),_:1}),h($,{quaternary:"",round:"",type:"info",class:"registerButton"},{default:C(()=>[h(_,{class:"text1",onClick:v[3]||(v[3]=D=>{s.value=!1,d.value=!0})},{default:C(()=>[M(" 立即注册 ")]),_:1})]),_:1}),h(_,{class:"text2"},{default:C(()=>[M(" | ")]),_:1}),h($,{quaternary:"",round:"",type:"info",class:"forgetButton"},{default:C(()=>[h(_,{class:"text3"},{default:C(()=>[M(" 忘记密码 ")]),_:1})]),_:1})]),_:1})):Ye("",!0),d.value?(ke(),Fe(V,{key:1,class:"card"},{default:C(()=>[me("div",null,[h(_,{class:"text"},{default:C(()=>[M(" 欢迎加入MewScience ")]),_:1})]),h(_,{class:"text4"},{default:C(()=>[M(" 已有账号？使用 ")]),_:1}),h($,{quaternary:"",round:"",type:"info",class:"returnButton"},{default:C(()=>[h(_,{class:"text5",onClick:v[4]||(v[4]=D=>{s.value=!0,d.value=!1})},{default:C(()=>[M(" 账号密码登录 ")]),_:1})]),_:1}),h(U,{value:z.value,"onUpdate:value":v[5]||(v[5]=D=>z.value=D),size:"large",round:"",placeholder:"设置您的用户名",class:"input3"},null,8,["value"]),h(U,{value:P.value,"onUpdate:value":v[6]||(v[6]=D=>P.value=D),size:"large",round:"",placeholder:"设置您的登录密码",class:"input"},null,8,["value"]),h(U,{value:g.value,"onUpdate:value":v[7]||(v[7]=D=>g.value=D),size:"large",round:"",placeholder:"请输入邮箱",class:"input"},null,8,["value"]),h(U,{value:f.value,"onUpdate:value":v[8]||(v[8]=D=>f.value=D),size:"large",round:"",placeholder:"名",class:"input1"},null,8,["value"]),h(U,{value:x.value,"onUpdate:value":v[9]||(v[9]=D=>x.value=D),size:"large",round:"",placeholder:"姓",class:"input2"},null,8,["value"]),h($,{round:"",type:"info",class:"loginButton",onClick:X},{default:C(()=>[h(_,{class:"loginText"},{default:C(()=>[M(" 注册 ")]),_:1})]),_:1})]),_:1})):Ye("",!0)]),_:1})],64)}}});const Hn=Jt(Mn,[["__scopeId","data-v-dd683f7f"]]);export{Hn as default};
