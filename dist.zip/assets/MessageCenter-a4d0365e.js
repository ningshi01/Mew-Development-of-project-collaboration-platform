import Ie from"src/assets/y1.jpg";import{S as Fe}from"./nav-9fc93e5e.js";import{x as je,y as W,z as le,A as ie,B as re}from"./index-eb756369.js";import{e as J,r as x,h as O,b2 as ve,b3 as ce,b0 as q,j as v,a as P,bs as Ee,b as z,ck as Ue,d as j,a$ as K,bz as De,bG as Me,cl as Ye,c as _e,c6 as ue,u as se,g as G,cm as Le,aA as he,bD as Ae,k as Ve,i as ye,bo as We,T as qe,bm as ae,cn as Je,bS as Xe,c2 as Ke,aX as Ge,aV as He,aN as de,bn as Ze,bI as Qe,co as et,br as tt,aU as nt,b9 as at,c7 as ot,bE as pe,be as st,aK as lt,aC as _,aD as I,aG as u,aF as oe,aI as o,aJ as F,aM as $,aE as N,aL as m,bg as M,bx as D,bw as h}from"./index-b27597f8.js";import{g as it}from"./attribute-2ee9e579.js";import{p as rt,_ as ct,c as ut}from"./Popover-61edb1a7.js";import{u as fe}from"./use-locale-c044757c.js";import{u as dt}from"./use-message-cf8630a3.js";import{a as pt,_ as ft}from"./Tabs-c6e50ba4.js";import{_ as mt}from"./Thing-5d12aa7f.js";import{a as gt,N as vt}from"./ListItem-f81f04ef.js";import{_ as _t}from"./Scrollbar-9f2820eb.js";import{_ as ht}from"./Tag-80143942.js";import{_ as yt}from"./a-c9a05025.js";import"./PersonCircleSharp-b3b772bc.js";import"./Icon-98a0c14c.js";import"./format-length-c9d165c6.js";import"./Add-a453005a.js";import"./toNumber-3f46f0be.js";import"./light-5e5d12e6.js";const me=J({name:"SlotMachineNumber",props:{clsPrefix:{type:String,required:!0},value:{type:[Number,String],required:!0},oldOriginalNumber:{type:Number,default:void 0},newOriginalNumber:{type:Number,default:void 0}},setup(t){const l=x(null),c=x(t.value),p=x(t.value),d=x("up"),i=x(!1),k=O(()=>i.value?`${t.clsPrefix}-base-slot-machine-current-number--${d.value}-scroll`:null),f=O(()=>i.value?`${t.clsPrefix}-base-slot-machine-old-number--${d.value}-scroll`:null);ve(q(t,"value"),(a,b)=>{c.value=b,p.value=a,ce(g)});function g(){const a=t.newOriginalNumber,b=t.oldOriginalNumber;b===void 0||a===void 0||(a>b?w("up"):b>a&&w("down"))}function w(a){d.value=a,i.value=!1,ce(()=>{var b;(b=l.value)===null||b===void 0||b.offsetWidth,i.value=!0})}return()=>{const{clsPrefix:a}=t;return v("span",{ref:l,class:`${a}-base-slot-machine-number`},c.value!==null?v("span",{class:[`${a}-base-slot-machine-old-number ${a}-base-slot-machine-old-number--top`,f.value]},c.value):null,v("span",{class:[`${a}-base-slot-machine-current-number`,k.value]},v("span",{ref:"numberWrapper",class:[`${a}-base-slot-machine-current-number__inner`,typeof t.value!="number"&&`${a}-base-slot-machine-current-number__inner--not-number`]},p.value)),c.value!==null?v("span",{class:[`${a}-base-slot-machine-old-number ${a}-base-slot-machine-old-number--bottom`,f.value]},c.value):null)}}}),{cubicBezierEaseOut:A}=Ee;function bt({duration:t=".2s"}={}){return[P("&.fade-up-width-expand-transition-leave-active",{transition:`
 opacity ${t} ${A},
 max-width ${t} ${A},
 transform ${t} ${A}
 `}),P("&.fade-up-width-expand-transition-enter-active",{transition:`
 opacity ${t} ${A},
 max-width ${t} ${A},
 transform ${t} ${A}
 `}),P("&.fade-up-width-expand-transition-enter-to",{opacity:1,transform:"translateX(0) translateY(0)"}),P("&.fade-up-width-expand-transition-enter-from",{maxWidth:"0 !important",opacity:0,transform:"translateY(60%)"}),P("&.fade-up-width-expand-transition-leave-from",{opacity:1,transform:"translateY(0)"}),P("&.fade-up-width-expand-transition-leave-to",{maxWidth:"0 !important",opacity:0,transform:"translateY(60%)"})]}const kt=P([P("@keyframes n-base-slot-machine-fade-up-in",`
 from {
 transform: translateY(60%);
 opacity: 0;
 }
 to {
 transform: translateY(0);
 opacity: 1;
 }
 `),P("@keyframes n-base-slot-machine-fade-down-in",`
 from {
 transform: translateY(-60%);
 opacity: 0;
 }
 to {
 transform: translateY(0);
 opacity: 1;
 }
 `),P("@keyframes n-base-slot-machine-fade-up-out",`
 from {
 transform: translateY(0%);
 opacity: 1;
 }
 to {
 transform: translateY(-60%);
 opacity: 0;
 }
 `),P("@keyframes n-base-slot-machine-fade-down-out",`
 from {
 transform: translateY(0%);
 opacity: 1;
 }
 to {
 transform: translateY(60%);
 opacity: 0;
 }
 `),z("base-slot-machine",`
 overflow: hidden;
 white-space: nowrap;
 display: inline-block;
 height: 18px;
 line-height: 18px;
 `,[z("base-slot-machine-number",`
 display: inline-block;
 position: relative;
 height: 18px;
 width: .6em;
 max-width: .6em;
 `,[bt({duration:".2s"}),Ue({duration:".2s",delay:"0s"}),z("base-slot-machine-old-number",`
 display: inline-block;
 opacity: 0;
 position: absolute;
 left: 0;
 right: 0;
 `,[j("top",{transform:"translateY(-100%)"}),j("bottom",{transform:"translateY(100%)"}),j("down-scroll",{animation:"n-base-slot-machine-fade-down-out .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),j("up-scroll",{animation:"n-base-slot-machine-fade-up-out .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1})]),z("base-slot-machine-current-number",`
 display: inline-block;
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 1;
 transform: translateY(0);
 width: .6em;
 `,[j("down-scroll",{animation:"n-base-slot-machine-fade-down-in .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),j("up-scroll",{animation:"n-base-slot-machine-fade-up-in .2s cubic-bezier(0, 0, .2, 1)",animationIterationCount:1}),K("inner",`
 display: inline-block;
 position: absolute;
 right: 0;
 top: 0;
 width: .6em;
 `,[j("not-number",`
 right: unset;
 left: 0;
 `)])])])])]),wt=J({name:"BaseSlotMachine",props:{clsPrefix:{type:String,required:!0},value:{type:[Number,String],default:0},max:{type:Number,default:void 0},appeared:{type:Boolean,required:!0}},setup(t){De("-base-slot-machine",kt,q(t,"clsPrefix"));const l=x(),c=x(),p=O(()=>{if(typeof t.value=="string")return[];if(t.value<1)return[0];const d=[];let i=t.value;for(t.max!==void 0&&(i=Math.min(t.max,i));i>=1;)d.push(i%10),i/=10,i=Math.floor(i);return d.reverse(),d});return ve(q(t,"value"),(d,i)=>{typeof d=="string"?(c.value=void 0,l.value=void 0):typeof i=="string"?(c.value=d,l.value=void 0):(c.value=d,l.value=i)}),()=>{const{value:d,clsPrefix:i}=t;return typeof d=="number"?v("span",{class:`${i}-base-slot-machine`},v(Ye,{name:"fade-up-width-expand-transition",tag:"span"},{default:()=>p.value.map((k,f)=>v(me,{clsPrefix:i,key:p.value.length-f-1,oldOriginalNumber:l.value,newOriginalNumber:c.value,value:k}))}),v(Me,{key:"+",width:!0},{default:()=>t.max!==void 0&&t.max<d?v(me,{clsPrefix:i,value:"+"}):null})):v("span",{class:`${i}-base-slot-machine`},d)}}}),xt=t=>{const{errorColor:l,infoColor:c,successColor:p,warningColor:d,fontFamily:i}=t;return{color:l,colorInfo:c,colorSuccess:p,colorError:l,colorWarning:d,fontSize:"12px",fontFamily:i}},Ct={name:"Badge",common:_e,self:xt},Pt=Ct,$t=P([P("@keyframes badge-wave-spread",{from:{boxShadow:"0 0 0.5px 0px var(--n-ripple-color)",opacity:.6},to:{boxShadow:"0 0 0.5px 4.5px var(--n-ripple-color)",opacity:0}}),z("badge",`
 display: inline-flex;
 position: relative;
 vertical-align: middle;
 color: var(--n-color);
 font-family: var(--n-font-family);
 `,[j("as-is",[z("badge-sup",{position:"static",transform:"translateX(0)"},[ue({transformOrigin:"left bottom",originalTransform:"translateX(0)"})])]),j("dot",[z("badge-sup",`
 height: 8px;
 width: 8px;
 padding: 0;
 min-width: 8px;
 left: 100%;
 bottom: calc(100% - 4px);
 `,[P("::before","border-radius: 4px;")])]),z("badge-sup",`
 background: var(--n-color);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 color: #FFF;
 position: absolute;
 height: 18px;
 line-height: 18px;
 border-radius: 9px;
 padding: 0 6px;
 text-align: center;
 font-size: var(--n-font-size);
 transform: translateX(-50%);
 left: 100%;
 bottom: calc(100% - 9px);
 font-variant-numeric: tabular-nums;
 z-index: 1;
 display: flex;
 align-items: center;
 `,[ue({transformOrigin:"left bottom",originalTransform:"translateX(-50%)"}),z("base-wave",{zIndex:1,animationDuration:"2s",animationIterationCount:"infinite",animationDelay:"1s",animationTimingFunction:"var(--n-ripple-bezier)",animationName:"badge-wave-spread"}),P("&::before",`
 opacity: 0;
 transform: scale(1);
 border-radius: 9px;
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)])])]),Nt=Object.assign(Object.assign({},G.props),{value:[String,Number],max:Number,dot:Boolean,type:{type:String,default:"default"},show:{type:Boolean,default:!0},showZero:Boolean,processing:Boolean,color:String,offset:Array}),Rt=J({name:"Badge",props:Nt,setup(t,{slots:l}){const{mergedClsPrefixRef:c,inlineThemeDisabled:p,mergedRtlRef:d}=se(t),i=G("Badge","-badge",$t,Pt,t,c),k=x(!1),f=()=>{k.value=!0},g=()=>{k.value=!1},w=O(()=>t.show&&(t.dot||t.value!==void 0&&!(!t.showZero&&Number(t.value)<=0)||!Le(l.value)));he(()=>{w.value&&(k.value=!0)});const a=Ae("Badge",d,c),b=O(()=>{const{type:T,color:R}=t,{common:{cubicBezierEaseInOut:B,cubicBezierEaseOut:V},self:{[Ve("color",T)]:Y,fontFamily:Z,fontSize:Q}}=i.value;return{"--n-font-size":Q,"--n-font-family":Z,"--n-color":R||Y,"--n-ripple-color":R||Y,"--n-bezier":B,"--n-ripple-bezier":V}}),C=p?ye("badge",O(()=>{let T="";const{type:R,color:B}=t;return R&&(T+=R[0]),B&&(T+=We(B)),T}),b,t):void 0,H=O(()=>{const{offset:T}=t;if(!T)return;const[R,B]=T,V=typeof R=="number"?`${R}px`:R,Y=typeof B=="number"?`${B}px`:B;return{transform:`translate(calc(${a!=null&&a.value?"50%":"-50%"} + ${V}), ${Y})`}});return{rtlEnabled:a,mergedClsPrefix:c,appeared:k,showBadge:w,handleAfterEnter:f,handleAfterLeave:g,cssVars:p?void 0:b,themeClass:C==null?void 0:C.themeClass,onRender:C==null?void 0:C.onRender,offsetStyle:H}},render(){var t;const{mergedClsPrefix:l,onRender:c,themeClass:p,$slots:d}=this;c==null||c();const i=(t=d.default)===null||t===void 0?void 0:t.call(d);return v("div",{class:[`${l}-badge`,this.rtlEnabled&&`${l}-badge--rtl`,p,{[`${l}-badge--dot`]:this.dot,[`${l}-badge--as-is`]:!i}],style:this.cssVars},i,v(qe,{name:"fade-in-scale-up-transition",onAfterEnter:this.handleAfterEnter,onAfterLeave:this.handleAfterLeave},{default:()=>this.showBadge?v("sup",{class:`${l}-badge-sup`,title:it(this.value),style:this.offsetStyle},ae(d.value,()=>[this.dot?null:v(wt,{clsPrefix:l,appeared:this.appeared,max:this.max,value:this.value})]),this.processing?v(Je,{clsPrefix:l}):null):null}))}}),St={iconSize:"22px"},zt=t=>{const{fontSize:l,warningColor:c}=t;return Object.assign(Object.assign({},St),{fontSize:l,iconColor:c})},Tt=Xe({name:"Popconfirm",common:_e,peers:{Button:Ke,Popover:rt},self:zt}),Bt=Tt,be=Ge("n-popconfirm"),ke={positiveText:String,negativeText:String,showIcon:{type:Boolean,default:!0},onPositiveClick:{type:Function,required:!0},onNegativeClick:{type:Function,required:!0}},ge=tt(ke),Ot=J({name:"NPopconfirmPanel",props:ke,setup(t){const{localeRef:l}=fe("Popconfirm"),{inlineThemeDisabled:c}=se(),{mergedClsPrefixRef:p,mergedThemeRef:d,props:i}=He(be),k=O(()=>{const{common:{cubicBezierEaseInOut:g},self:{fontSize:w,iconSize:a,iconColor:b}}=d.value;return{"--n-bezier":g,"--n-font-size":w,"--n-icon-size":a,"--n-icon-color":b}}),f=c?ye("popconfirm-panel",void 0,k,i):void 0;return Object.assign(Object.assign({},fe("Popconfirm")),{mergedClsPrefix:p,cssVars:c?void 0:k,localizedPositiveText:O(()=>t.positiveText||l.value.positiveText),localizedNegativeText:O(()=>t.negativeText||l.value.negativeText),positiveButtonProps:q(i,"positiveButtonProps"),negativeButtonProps:q(i,"negativeButtonProps"),handlePositiveClick(g){t.onPositiveClick(g)},handleNegativeClick(g){t.onNegativeClick(g)},themeClass:f==null?void 0:f.themeClass,onRender:f==null?void 0:f.onRender})},render(){var t;const{mergedClsPrefix:l,showIcon:c,$slots:p}=this,d=ae(p.action,()=>this.negativeText===null&&this.positiveText===null?[]:[this.negativeText!==null&&v(de,Object.assign({size:"small",onClick:this.handleNegativeClick},this.negativeButtonProps),{default:()=>this.localizedNegativeText}),this.positiveText!==null&&v(de,Object.assign({size:"small",type:"primary",onClick:this.handlePositiveClick},this.positiveButtonProps),{default:()=>this.localizedPositiveText})]);return(t=this.onRender)===null||t===void 0||t.call(this),v("div",{class:[`${l}-popconfirm__panel`,this.themeClass],style:this.cssVars},Ze(p.default,i=>c||i?v("div",{class:`${l}-popconfirm__body`},c?v("div",{class:`${l}-popconfirm__icon`},ae(p.icon,()=>[v(Qe,{clsPrefix:l},{default:()=>v(et,null)})])):null,i):null),d?v("div",{class:[`${l}-popconfirm__action`]},d):null)}}),It=z("popconfirm",[K("body",`
 font-size: var(--n-font-size);
 display: flex;
 align-items: center;
 flex-wrap: nowrap;
 position: relative;
 `,[K("icon",`
 display: flex;
 font-size: var(--n-icon-size);
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 margin: 0 8px 0 0;
 `)]),K("action",`
 display: flex;
 justify-content: flex-end;
 `,[P("&:not(:first-child)","margin-top: 8px"),z("button",[P("&:not(:last-child)","margin-right: 8px;")])])]),Ft=Object.assign(Object.assign(Object.assign({},G.props),ut),{positiveText:String,negativeText:String,showIcon:{type:Boolean,default:!0},trigger:{type:String,default:"click"},positiveButtonProps:Object,negativeButtonProps:Object,onPositiveClick:Function,onNegativeClick:Function}),jt=J({name:"Popconfirm",props:Ft,__popover__:!0,setup(t){const{mergedClsPrefixRef:l}=se(),c=G("Popconfirm","-popconfirm",It,Bt,t,l),p=x(null);function d(f){var g;if(!(!((g=p.value)===null||g===void 0)&&g.getMergedShow()))return;const{onPositiveClick:w,"onUpdate:show":a}=t;Promise.resolve(w?w(f):!0).then(b=>{var C;b!==!1&&((C=p.value)===null||C===void 0||C.setShow(!1),a&&pe(a,!1))})}function i(f){var g;if(!(!((g=p.value)===null||g===void 0)&&g.getMergedShow()))return;const{onNegativeClick:w,"onUpdate:show":a}=t;Promise.resolve(w?w(f):!0).then(b=>{var C;b!==!1&&((C=p.value)===null||C===void 0||C.setShow(!1),a&&pe(a,!1))})}return nt(be,{mergedThemeRef:c,mergedClsPrefixRef:l,props:t}),{setShow(f){var g;(g=p.value)===null||g===void 0||g.setShow(f)},syncPosition(){var f;(f=p.value)===null||f===void 0||f.syncPosition()},mergedTheme:c,popoverInstRef:p,handlePositiveClick:d,handleNegativeClick:i}},render(){const{$slots:t,$props:l,mergedTheme:c}=this;return v(ct,ot(l,ge,{theme:c.peers.Popover,themeOverrides:c.peerOverrides.Popover,internalExtraClass:["popconfirm"],ref:"popoverInstRef"}),{trigger:t.activator||t.trigger,default:()=>{const p=at(l,ge);return v(Ot,Object.assign(Object.assign({},p),{onPositiveClick:this.handlePositiveClick,onNegativeClick:this.handleNegativeClick}),t)}})}});const Et={ref:"container",class:"container"},Ut=oe("div",{class:"PageContainer"},[oe("img",{src:Ie,class:"background",alt:" "})],-1),sn={__name:"MessageCenter",setup(t){st();const l=lt(),c=x([{id:"",research_id:"passed",timestamp:"2023-12-24 15:57:05",link_content:"Jack.",link_id:5003911e3,msg_type:"Follow Update",work_type:"not a work transfer message",title:"",type:"",content:"",status:"",message:""}]),p=x([{id:"",research_id:"passed",timestamp:"2023-12-24 15:57:05",link_content:"Jack.",link_id:5003911e3,msg_type:"Follow Update",work_type:"not a work transfer message",title:"",type:"",content:"",status:"",message:""}]),d=x([{id:"",research_id:"passed",timestamp:"2023-12-24 15:57:05",link_content:"Jack.",link_id:5003911e3,msg_type:"Follow Update",work_type:"not a work transfer message",title:"",type:"",content:"",status:"",message:""}]),i=x([{id:"",research_id:"passed",timestamp:"2023-12-24 15:57:05",link_content:"Jack.",link_id:5003911e3,msg_type:"Follow Update",work_type:"not a work transfer message",title:"",type:"",content:"",status:"",message:""}]),k=x([{id:"",research_id:"passed",timestamp:"2023-12-24 15:57:05",link_content:"Jack.",link_id:5003911e3,msg_type:"Follow Update",work_type:"not a work transfer message",title:"",type:"",content:"",status:"",message:""}]),f=x([{id:"",research_id:"passed",timestamp:"2023-12-24 15:57:05",link_content:"Jack.",link_id:5003911e3,msg_type:"Follow Update",work_type:"not a work transfer message",title:"",type:"",content:"",status:"",message:""}]),g=x([{id:"",research_id:"passed",timestamp:"2023-12-24 15:57:05",link_content:"Jack.",link_id:5003911e3,msg_type:"Follow Update",work_type:"not a work transfer message",title:"",type:"",content:"",status:"",message:""}]),w=x([{id:"",research_id:"passed",timestamp:"2023-12-24 15:57:05",link_content:"Jack.",link_id:5003911e3,msg_type:"Follow Update",work_type:"not a work transfer message",title:"",type:"",content:"",status:"",message:""}]),a=x([{research_id:"passed",timestamp:"2023-12-23 18:06:17",link_content:"Mike Dong",link_id:5018291858,msg_type:"Claim Review",work_type:"not a work transfer message",title:"",type:"",content:"",status:"false",message:"",id:""},{research_id:5014654576,timestamp:"2023-12-23 19:43:54",link_content:"A PDE Formalization of Retinex Theory",link_id:2159871081,msg_type:"Follow Update",work_type:"not a work transfer message",title:"",type:"",content:"",status:"false",message:"",id:""},{research_id:5003911e3,timestamp:"2023-12-24 16:03:22",link_content:"一种肠道微生物一体式采集、分装及保存装置",link_id:12101,msg_type:"Works Transfer",work_type:"Patent",title:"",type:"",content:"",status:"false",message:"",id:""},{research_id:"passed",timestamp:"2023-12-24 16:13:48",link_content:"Jack.",link_id:5003911e3,msg_type:"Transfer Response",work_type:"Patent",title:"",type:"",content:"",status:"flase",message:"",id:""}]),b=(e,r)=>{c.value.splice(e,1),p.value.push(r),console.log(r.link_id),W({id:r.id}).then(s=>{console.log(s),s.errno})},C=(e,r)=>{d.value.splice(e,1),i.value.push(r),console.log(r.link_id),W({id:r.id}).then(s=>{console.log(s),s.errno})},H=(e,r)=>{g.value.splice(e,1),w.value.push(r),console.log(r.link_id),W({id:r.id}).then(s=>{console.log(s),s.errno})},T=(e,r)=>{k.value.splice(e,1),f.value.push(r),console.log(r.link_id),W({id:r.id}).then(s=>{console.log(s),s.errno}),r.work_type==="Patent"?le({opinion:"agree",transfer_id:r.id,patent_id:r.link_id}).then(s=>{console.log(s),s.errno}):r.work_type==="Reward"?ie({opinion:"agree",transfer_id:r.id,reward_id:r.link_id}).then(s=>{console.log(s),s.errno}):r.work_type==="Project"&&re({opinion:"agree",transfer_id:r.id,project_id:r.link_id}).then(s=>{console.log(s),s.errno})},R=(e,r)=>{k.value.splice(e,1),f.value.push(r),console.log(r.link_id),W({id:r.id}).then(s=>{console.log(s),s.errno}),r.work_type==="Patent"?le({opinion:"refuse",transfer_id:r.id,patent_id:r.link_id}).then(s=>{console.log(s),s.errno}):r.work_type==="Reward"?ie({opinion:"refuse",transfer_id:r.id,reward_id:r.link_id}).then(s=>{console.log(s),s.errno}):r.work_type==="Project"&&re({opinion:"refuse",transfer_id:r.id,project_id:r.link_id}).then(s=>{console.log(s),s.errno})},B=e=>{c.value.push(e),console.log(c.value[1].research_id)},V=e=>{p.value.push(e),console.log(p.value[1].research_id)},Y=e=>{d.value.push(e),console.log(d.value[1].research_id)},Z=e=>{i.value.push(e),console.log(i.value[1].research_id)},Q=e=>{k.value.push(e),console.log(k.value[1].research_id)},we=e=>{f.value.push(e),console.log(f.value[1].research_id)},xe=e=>{g.value.push(e),console.log(g.value[1].research_id)},Ce=e=>{w.value.push(e),console.log(w.value[1].research_id)},Pe=dt();he(()=>{je().then(e=>{console.log(e.errno),e.errno===1002?(console.log(e.errno),Pe.warning("请先登录！")):(a.value=e.data,console.log(e.data))}),ze()});function $e(e,r,s){l.push({name:"DisplayPaper",query:{id:e}}),b(r,s)}function Ne(e,r,s){l.push({name:"ScholarPage",query:{id:e}}),C(r,s)}function Re(e){l.push({name:"DisplayPaper",query:{id:e}})}function Se(e){l.push({name:"ScholarPage",query:{id:e}})}const ze=()=>{console.log(a.value.length);for(let e=0;e<a.value.length;e++)Te(a.value[e]),a.value[e].msg_type==="Follow Update"&&a.value[e].status==="false"?B(a.value[e]):a.value[e].msg_type==="Follow Update"&&a.value[e].status==="true"?V(a.value[e]):a.value[e].msg_type==="Claim Review"&&a.value[e].status==="false"?Y(a.value[e]):a.value[e].msg_type==="Claim Review"&&a.value[e].status==="true"?Z(a.value[e]):a.value[e].msg_type==="Works Transfer"&&a.value[e].status==="false"?Q(a.value[e]):a.value[e].msg_type==="Works Transfer"&&a.value[e].status==="true"?we(a.value[e]):a.value[e].msg_type==="Transfer Response"&&a.value[e].status==="false"?xe(a.value[e]):a.value[e].msg_type==="Transfer Response"&&a.value[e].status==="true"&&Ce(a.value[e])},Te=e=>{e.msg_type==="Follow Update"?(e.title="关注者更新",e.type="info",e.content="您关注的ID为 "+e.research_id+" 的研究者更新了 "):e.msg_type==="Works Transfer"?(e.title="转让请求",e.type="warning",e.content="ID为 "+e.research_id+" 的用户向你发来 "+e.work_type+" 的转让请求 "):e.msg_type==="Transfer Response"?(e.title="转让回应",e.type="success",e.research_id==="passed"?e.content="ID为 "+e.link_id+" 的用户 "+e.link_content+" 接受了你的 "+e.work_type+" 转让请求 ":e.content="ID为 "+e.link_id+" 的用户 "+e.link_content+" 拒绝了你的 "+e.work_type+" 转让请求 "):e.msg_type==="Claim Review"&&(e.title="门户认领",e.type="error",e.content="您申请的ID为 "+e.link_id+" 的门户",e.research_id==="passed"?e.message=" 成功了！":e.content=" 失败了！")};return(e,r)=>{const s=mt,S=gt,E=ht,X=Rt,L=yt,ee=vt,te=_t,ne=ft,Be=jt,Oe=pt;return _(),I(F,null,[u(Fe),oe("div",Et,[u(Oe,{class:"card",type:"segment"},{default:o(()=>[u(ne,{class:"m1",name:"chap1",tab:"系统通知"},{default:o(()=>[u(te,{style:{"max-height":"88vh"}},{default:o(()=>[u(ee,{hoverable:"",clickable:""},{default:o(()=>[$(c).length===1&&$(p).length===1&&$(d).length===1&&$(i).length===1?(_(),N(S,{key:0},{default:o(()=>[u(s,{class:"thing-container","content-style":"margin-top: 10px;"},{default:o(()=>[m(" 当前暂无系统消息！ ")]),_:1})]),_:1})):M("",!0),(_(!0),I(F,null,D($(c).slice(1),(n,y)=>(_(),N(S,{key:y},{default:o(()=>[u(s,{class:"thing-container",title:n.title,"content-style":"margin-top: 10px;",onClick:U=>b(y,n)},{description:o(()=>[u(E,{bordered:!1,type:n.type,size:"large"},{default:o(()=>[m(h(n.timestamp),1)]),_:2},1032,["type"]),u(X,{class:"dot",value:e.value,dot:""},null,8,["value"])]),default:o(()=>[m(" "+h(n.content)+" ",1),u(L,{onClick:U=>$e(n.link_id,y,n)},{default:o(()=>[m(h(n.link_content),1)]),_:2},1032,["onClick"])]),_:2},1032,["title","onClick"])]),_:2},1024))),128)),(_(!0),I(F,null,D($(p).slice(1),(n,y)=>(_(),N(S,{key:y},{default:o(()=>[u(s,{class:"thing-container",title:n.title,"content-style":"margin-top: 10px;"},{description:o(()=>[u(E,{bordered:!1,type:n.type,size:"large"},{default:o(()=>[m(h(n.timestamp),1)]),_:2},1032,["type"])]),default:o(()=>[m(" "+h(n.content)+" ",1),u(L,{onClick:U=>Re(n.link_id)},{default:o(()=>[m(h(n.link_content),1)]),_:2},1032,["onClick"])]),_:2},1032,["title"])]),_:2},1024))),128)),(_(!0),I(F,null,D($(d).slice(1),(n,y)=>(_(),N(S,{key:y,onClick:U=>C(y,n)},{default:o(()=>[u(s,{class:"thing-container",title:n.title,"content-style":"margin-top: 10px;"},{description:o(()=>[u(E,{bordered:!1,type:n.type,size:"large"},{default:o(()=>[m(h(n.timestamp),1)]),_:2},1032,["type"]),u(X,{class:"dot",value:e.value,dot:""},null,8,["value"])]),default:o(()=>[m(" "+h(n.content)+" ",1),n.research_id==="passed"?(_(),N(L,{key:0,onClick:U=>Ne(n.link_id,y,n)},{default:o(()=>[m(h(n.link_content),1)]),_:2},1032,["onClick"])):M("",!0),n.research_id==="failed"?(_(),N(L,{key:1},{default:o(()=>[m(h(n.link_content),1)]),_:2},1024)):M("",!0),m(" "+h(n.message),1)]),_:2},1032,["title"])]),_:2},1032,["onClick"]))),128)),(_(!0),I(F,null,D($(i).slice(1),(n,y)=>(_(),N(S,{key:y},{default:o(()=>[u(s,{class:"thing-container",title:n.title,"content-style":"margin-top: 10px;"},{description:o(()=>[u(E,{bordered:!1,type:n.type,size:"large"},{default:o(()=>[m(h(n.timestamp),1)]),_:2},1032,["type"])]),default:o(()=>[m(" "+h(n.content)+" ",1),n.research_id==="passed"?(_(),N(L,{key:0,onClick:U=>Se(n.link_id)},{default:o(()=>[m(h(n.link_content),1)]),_:2},1032,["onClick"])):M("",!0),n.research_id==="failed"?(_(),N(L,{key:1},{default:o(()=>[m(h(n.link_content),1)]),_:2},1024)):M("",!0),m(" "+h(n.message),1)]),_:2},1032,["title"])]),_:2},1024))),128))]),_:1})]),_:1})]),_:1}),u(ne,{name:"chap2",tab:"转让请求"},{default:o(()=>[u(te,{style:{"max-height":"88vh"}},{default:o(()=>[u(ee,{hoverable:"",clickable:""},{default:o(()=>[$(k).length===1&&$(f).length===1?(_(),N(S,{key:0},{default:o(()=>[u(s,{class:"thing-container","content-style":"margin-top: 10px;"},{default:o(()=>[m(" 当前暂无转让请求！ ")]),_:1})]),_:1})):M("",!0),(_(!0),I(F,null,D($(k).slice(1),(n,y)=>(_(),N(S,{key:y},{default:o(()=>[u(s,{title:n.title,"content-style":"margin-top: 10px;"},{description:o(()=>[u(E,{bordered:!1,type:n.type,size:"large"},{default:o(()=>[m(h(n.timestamp),1)]),_:2},1032,["type"]),u(Be,{onPositiveClick:U=>T(y,n),onNegativeClick:U=>R(y,n)},{trigger:o(()=>[u(X,{class:"dot",value:e.value,dot:""},null,8,["value"])]),default:o(()=>[m(" 您是否同意该转让请求？ ")]),_:2},1032,["onPositiveClick","onNegativeClick"])]),default:o(()=>[m(" "+h(n.content),1)]),_:2},1032,["title"])]),_:2},1024))),128)),(_(!0),I(F,null,D($(f).slice(1),(n,y)=>(_(),N(S,{key:y},{default:o(()=>[u(s,{title:n.title,"content-style":"margin-top: 10px;"},{description:o(()=>[u(E,{bordered:!1,type:n.type,size:"large"},{default:o(()=>[m(h(n.timestamp),1)]),_:2},1032,["type"])]),default:o(()=>[m(" "+h(n.content),1)]),_:2},1032,["title"])]),_:2},1024))),128))]),_:1})]),_:1})]),_:1}),u(ne,{name:"chap3",tab:"转让回应"},{default:o(()=>[u(te,{style:{"max-height":"88vh"}},{default:o(()=>[u(ee,{hoverable:"",clickable:""},{default:o(()=>[$(g).length===1&&$(w).length===1?(_(),N(S,{key:0},{default:o(()=>[u(s,{class:"thing-container","content-style":"margin-top: 10px;"},{default:o(()=>[m(" 当前暂无转让回应！ ")]),_:1})]),_:1})):M("",!0),(_(!0),I(F,null,D($(g).slice(1),(n,y)=>(_(),N(S,{key:y,onClick:U=>H(y,n)},{default:o(()=>[u(s,{title:n.title,"content-style":"margin-top: 10px;"},{description:o(()=>[u(E,{bordered:!1,type:n.type,size:"large"},{default:o(()=>[m(h(n.timestamp),1)]),_:2},1032,["type"]),u(X,{class:"dot",value:e.value,dot:""},null,8,["value"])]),default:o(()=>[m(" "+h(n.content),1)]),_:2},1032,["title"])]),_:2},1032,["onClick"]))),128)),(_(!0),I(F,null,D($(w).slice(1),(n,y)=>(_(),N(S,{key:y},{default:o(()=>[u(s,{title:n.title,"content-style":"margin-top: 10px;"},{description:o(()=>[u(E,{bordered:!1,type:n.type,size:"large"},{default:o(()=>[m(h(n.timestamp),1)]),_:2},1032,["type"])]),default:o(()=>[m(" "+h(n.content),1)]),_:2},1032,["title"])]),_:2},1024))),128))]),_:1})]),_:1})]),_:1})]),_:1})],512),Ut],64)}}};export{sn as default};
