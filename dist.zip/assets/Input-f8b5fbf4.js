import{e as W,j as t,da as lr,b as m,a as y,a$ as s,c0 as ir,bz as Pe,b0 as xe,c1 as sr,bm as Z,bI as ae,N as cr,c as dr,bK as ge,aX as ur,r as w,b2 as me,aV as hr,h as R,b6 as fr,d as F,bp as Y,u as vr,g as Ee,df as pr,b$ as gr,bH as $e,aA as br,bi as xr,w as Ae,aU as mr,bD as wr,i as Cr,bn as ne,bM as yr,aJ as zr,b5 as Sr,b3 as Fe,bd as _e,bE as C,k as be,cf as $r,ba as Re}from"./index-b27597f8.js";import{u as Ar}from"./use-locale-c044757c.js";import{a as Fr}from"./Popover-61edb1a7.js";const _r=W({name:"Eye",render(){return t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M255.66 112c-77.94 0-157.89 45.11-220.83 135.33a16 16 0 0 0-.27 17.77C82.92 340.8 161.8 400 255.66 400c92.84 0 173.34-59.38 221.79-135.25a16.14 16.14 0 0 0 0-17.47C428.89 172.28 347.8 112 255.66 112z",fill:"none",stroke:"currentColor","stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"32"}),t("circle",{cx:"256",cy:"256",r:"80",fill:"none",stroke:"currentColor","stroke-miterlimit":"10","stroke-width":"32"}))}}),Rr=W({name:"EyeOff",render(){return t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M432 448a15.92 15.92 0 0 1-11.31-4.69l-352-352a16 16 0 0 1 22.62-22.62l352 352A16 16 0 0 1 432 448z",fill:"currentColor"}),t("path",{d:"M255.66 384c-41.49 0-81.5-12.28-118.92-36.5c-34.07-22-64.74-53.51-88.7-91v-.08c19.94-28.57 41.78-52.73 65.24-72.21a2 2 0 0 0 .14-2.94L93.5 161.38a2 2 0 0 0-2.71-.12c-24.92 21-48.05 46.76-69.08 76.92a31.92 31.92 0 0 0-.64 35.54c26.41 41.33 60.4 76.14 98.28 100.65C162 402 207.9 416 255.66 416a239.13 239.13 0 0 0 75.8-12.58a2 2 0 0 0 .77-3.31l-21.58-21.58a4 4 0 0 0-3.83-1a204.8 204.8 0 0 1-51.16 6.47z",fill:"currentColor"}),t("path",{d:"M490.84 238.6c-26.46-40.92-60.79-75.68-99.27-100.53C349 110.55 302 96 255.66 96a227.34 227.34 0 0 0-74.89 12.83a2 2 0 0 0-.75 3.31l21.55 21.55a4 4 0 0 0 3.88 1a192.82 192.82 0 0 1 50.21-6.69c40.69 0 80.58 12.43 118.55 37c34.71 22.4 65.74 53.88 89.76 91a.13.13 0 0 1 0 .16a310.72 310.72 0 0 1-64.12 72.73a2 2 0 0 0-.15 2.95l19.9 19.89a2 2 0 0 0 2.7.13a343.49 343.49 0 0 0 68.64-78.48a32.2 32.2 0 0 0-.1-34.78z",fill:"currentColor"}),t("path",{d:"M256 160a95.88 95.88 0 0 0-21.37 2.4a2 2 0 0 0-1 3.38l112.59 112.56a2 2 0 0 0 3.38-1A96 96 0 0 0 256 160z",fill:"currentColor"}),t("path",{d:"M165.78 233.66a2 2 0 0 0-3.38 1a96 96 0 0 0 115 115a2 2 0 0 0 1-3.38z",fill:"currentColor"}))}}),Br=W({name:"ChevronDown",render(){return t("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M3.14645 5.64645C3.34171 5.45118 3.65829 5.45118 3.85355 5.64645L8 9.79289L12.1464 5.64645C12.3417 5.45118 12.6583 5.45118 12.8536 5.64645C13.0488 5.84171 13.0488 6.15829 12.8536 6.35355L8.35355 10.8536C8.15829 11.0488 7.84171 11.0488 7.64645 10.8536L3.14645 6.35355C2.95118 6.15829 2.95118 5.84171 3.14645 5.64645Z",fill:"currentColor"}))}}),Pr=lr("clear",t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M8,2 C11.3137085,2 14,4.6862915 14,8 C14,11.3137085 11.3137085,14 8,14 C4.6862915,14 2,11.3137085 2,8 C2,4.6862915 4.6862915,2 8,2 Z M6.5343055,5.83859116 C6.33943736,5.70359511 6.07001296,5.72288026 5.89644661,5.89644661 L5.89644661,5.89644661 L5.83859116,5.9656945 C5.70359511,6.16056264 5.72288026,6.42998704 5.89644661,6.60355339 L5.89644661,6.60355339 L7.293,8 L5.89644661,9.39644661 L5.83859116,9.4656945 C5.70359511,9.66056264 5.72288026,9.92998704 5.89644661,10.1035534 L5.89644661,10.1035534 L5.9656945,10.1614088 C6.16056264,10.2964049 6.42998704,10.2771197 6.60355339,10.1035534 L6.60355339,10.1035534 L8,8.707 L9.39644661,10.1035534 L9.4656945,10.1614088 C9.66056264,10.2964049 9.92998704,10.2771197 10.1035534,10.1035534 L10.1035534,10.1035534 L10.1614088,10.0343055 C10.2964049,9.83943736 10.2771197,9.57001296 10.1035534,9.39644661 L10.1035534,9.39644661 L8.707,8 L10.1035534,6.60355339 L10.1614088,6.5343055 C10.2964049,6.33943736 10.2771197,6.07001296 10.1035534,5.89644661 L10.1035534,5.89644661 L10.0343055,5.83859116 C9.83943736,5.70359511 9.57001296,5.72288026 9.39644661,5.89644661 L9.39644661,5.89644661 L8,7.293 L6.60355339,5.89644661 Z"}))))),Er=m("base-clear",`
 flex-shrink: 0;
 height: 1em;
 width: 1em;
 position: relative;
`,[y(">",[s("clear",`
 font-size: var(--n-clear-size);
 height: 1em;
 width: 1em;
 cursor: pointer;
 color: var(--n-clear-color);
 transition: color .3s var(--n-bezier);
 display: flex;
 `,[y("&:hover",`
 color: var(--n-clear-color-hover)!important;
 `),y("&:active",`
 color: var(--n-clear-color-pressed)!important;
 `)]),s("placeholder",`
 display: flex;
 `),s("clear, placeholder",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[ir({originalTransform:"translateX(-50%) translateY(-50%)",left:"50%",top:"50%"})])])]),we=W({name:"BaseClear",props:{clsPrefix:{type:String,required:!0},show:Boolean,onClear:Function},setup(r){return Pe("-base-clear",Er,xe(r,"clsPrefix")),{handleMouseDown(u){var n;u.preventDefault(),(n=r.onClear)===null||n===void 0||n.call(r,u)}}},render(){const{clsPrefix:r}=this;return t("div",{class:`${r}-base-clear`},t(sr,null,{default:()=>{var u,n;return this.show?t("div",{key:"dismiss",class:`${r}-base-clear__clear`,onClick:this.onClear,onMousedown:this.handleMouseDown,"data-clear":!0},Z(this.$slots.icon,()=>[t(ae,{clsPrefix:r},{default:()=>t(Pr,null)})])):t("div",{key:"icon",class:`${r}-base-clear__placeholder`},(n=(u=this.$slots).placeholder)===null||n===void 0?void 0:n.call(u))}}))}}),Tr=W({name:"InternalSelectionSuffix",props:{clsPrefix:{type:String,required:!0},showArrow:{type:Boolean,default:void 0},showClear:{type:Boolean,default:void 0},loading:{type:Boolean,default:!1},onClear:Function},setup(r,{slots:u}){return()=>{const{clsPrefix:n}=r;return t(cr,{clsPrefix:n,class:`${n}-base-suffix`,strokeWidth:24,scale:.85,show:r.loading},{default:()=>r.showArrow?t(we,{clsPrefix:n,show:r.showClear,onClear:r.onClear},{placeholder:()=>t(ae,{clsPrefix:n,class:`${n}-base-suffix__arrow`},{default:()=>Z(u.default,()=>[t(Br,null)])})}):null})}}}),kr={paddingTiny:"0 8px",paddingSmall:"0 10px",paddingMedium:"0 12px",paddingLarge:"0 14px",clearSize:"16px"},Ir=r=>{const{textColor2:u,textColor3:n,textColorDisabled:$,primaryColor:z,primaryColorHover:g,inputColor:h,inputColorDisabled:c,borderColor:d,warningColor:l,warningColorHover:i,errorColor:f,errorColorHover:b,borderRadius:B,lineHeight:S,fontSizeTiny:le,fontSizeSmall:V,fontSizeMedium:ie,fontSizeLarge:A,heightTiny:T,heightSmall:O,heightMedium:P,heightLarge:se,actionColor:E,clearColor:k,clearColorHover:_,clearColorPressed:I,placeholderColor:N,placeholderColorDisabled:K,iconColor:ce,iconColorDisabled:de,iconColorHover:j,iconColorPressed:ue}=r;return Object.assign(Object.assign({},kr),{countTextColorDisabled:$,countTextColor:n,heightTiny:T,heightSmall:O,heightMedium:P,heightLarge:se,fontSizeTiny:le,fontSizeSmall:V,fontSizeMedium:ie,fontSizeLarge:A,lineHeight:S,lineHeightTextarea:S,borderRadius:B,iconSize:"16px",groupLabelColor:E,groupLabelTextColor:u,textColor:u,textColorDisabled:$,textDecorationColor:u,caretColor:z,placeholderColor:N,placeholderColorDisabled:K,color:h,colorDisabled:c,colorFocus:h,groupLabelBorder:`1px solid ${d}`,border:`1px solid ${d}`,borderHover:`1px solid ${g}`,borderDisabled:`1px solid ${d}`,borderFocus:`1px solid ${g}`,boxShadowFocus:`0 0 0 2px ${ge(z,{alpha:.2})}`,loadingColor:z,loadingColorWarning:l,borderWarning:`1px solid ${l}`,borderHoverWarning:`1px solid ${i}`,colorFocusWarning:h,borderFocusWarning:`1px solid ${i}`,boxShadowFocusWarning:`0 0 0 2px ${ge(l,{alpha:.2})}`,caretColorWarning:l,loadingColorError:f,borderError:`1px solid ${f}`,borderHoverError:`1px solid ${b}`,colorFocusError:h,borderFocusError:`1px solid ${b}`,boxShadowFocusError:`0 0 0 2px ${ge(f,{alpha:.2})}`,caretColorError:f,clearColor:k,clearColorHover:_,clearColorPressed:I,iconColor:ce,iconColorDisabled:de,iconColorHover:j,iconColorPressed:ue,suffixTextColor:u})},Mr={name:"Input",common:dr,self:Ir},Dr=Mr,Te=ur("n-input");function Lr(r){let u=0;for(const n of r)u++;return u}function te(r){return r===""||r==null}function Wr(r){const u=w(null);function n(){const{value:g}=r;if(!(g!=null&&g.focus)){z();return}const{selectionStart:h,selectionEnd:c,value:d}=g;if(h==null||c==null){z();return}u.value={start:h,end:c,beforeText:d.slice(0,h),afterText:d.slice(c)}}function $(){var g;const{value:h}=u,{value:c}=r;if(!h||!c)return;const{value:d}=c,{start:l,beforeText:i,afterText:f}=h;let b=d.length;if(d.endsWith(f))b=d.length-f.length;else if(d.startsWith(i))b=i.length;else{const B=i[l-1],S=d.indexOf(B,l-1);S!==-1&&(b=S+1)}(g=c.setSelectionRange)===null||g===void 0||g.call(c,b,b)}function z(){u.value=null}return me(r,z),{recordCursor:n,restoreCursor:$}}const Be=W({name:"InputWordCount",setup(r,{slots:u}){const{mergedValueRef:n,maxlengthRef:$,mergedClsPrefixRef:z,countGraphemesRef:g}=hr(Te),h=R(()=>{const{value:c}=n;return c===null||Array.isArray(c)?0:(g.value||Lr)(c)});return()=>{const{value:c}=$,{value:d}=n;return t("span",{class:`${z.value}-input-word-count`},fr(u.default,{value:d===null||Array.isArray(d)?"":d},()=>[c===void 0?h.value:`${h.value} / ${c}`]))}}}),Vr=m("input",`
 max-width: 100%;
 cursor: text;
 line-height: 1.5;
 z-index: auto;
 outline: none;
 box-sizing: border-box;
 position: relative;
 display: inline-flex;
 border-radius: var(--n-border-radius);
 background-color: var(--n-color);
 transition: background-color .3s var(--n-bezier);
 font-size: var(--n-font-size);
 --n-padding-vertical: calc((var(--n-height) - 1.5 * var(--n-font-size)) / 2);
`,[s("input, textarea",`
 overflow: hidden;
 flex-grow: 1;
 position: relative;
 `),s("input-el, textarea-el, input-mirror, textarea-mirror, separator, placeholder",`
 box-sizing: border-box;
 font-size: inherit;
 line-height: 1.5;
 font-family: inherit;
 border: none;
 outline: none;
 background-color: #0000;
 text-align: inherit;
 transition:
 -webkit-text-fill-color .3s var(--n-bezier),
 caret-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier);
 `),s("input-el, textarea-el",`
 -webkit-appearance: none;
 scrollbar-width: none;
 width: 100%;
 min-width: 0;
 text-decoration-color: var(--n-text-decoration-color);
 color: var(--n-text-color);
 caret-color: var(--n-caret-color);
 background-color: transparent;
 `,[y("&::-webkit-scrollbar, &::-webkit-scrollbar-track-piece, &::-webkit-scrollbar-thumb",`
 width: 0;
 height: 0;
 display: none;
 `),y("&::placeholder",`
 color: #0000;
 -webkit-text-fill-color: transparent !important;
 `),y("&:-webkit-autofill ~",[s("placeholder","display: none;")])]),F("round",[Y("textarea","border-radius: calc(var(--n-height) / 2);")]),s("placeholder",`
 pointer-events: none;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 overflow: hidden;
 color: var(--n-placeholder-color);
 `,[y("span",`
 width: 100%;
 display: inline-block;
 `)]),F("textarea",[s("placeholder","overflow: visible;")]),Y("autosize","width: 100%;"),F("autosize",[s("textarea-el, input-el",`
 position: absolute;
 top: 0;
 left: 0;
 height: 100%;
 `)]),m("input-wrapper",`
 overflow: hidden;
 display: inline-flex;
 flex-grow: 1;
 position: relative;
 padding-left: var(--n-padding-left);
 padding-right: var(--n-padding-right);
 `),s("input-mirror",`
 padding: 0;
 height: var(--n-height);
 line-height: var(--n-height);
 overflow: hidden;
 visibility: hidden;
 position: static;
 white-space: pre;
 pointer-events: none;
 `),s("input-el",`
 padding: 0;
 height: var(--n-height);
 line-height: var(--n-height);
 `,[y("+",[s("placeholder",`
 display: flex;
 align-items: center; 
 `)])]),Y("textarea",[s("placeholder","white-space: nowrap;")]),s("eye",`
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `),F("textarea","width: 100%;",[m("input-word-count",`
 position: absolute;
 right: var(--n-padding-right);
 bottom: var(--n-padding-vertical);
 `),F("resizable",[m("input-wrapper",`
 resize: vertical;
 min-height: var(--n-height);
 `)]),s("textarea-el, textarea-mirror, placeholder",`
 height: 100%;
 padding-left: 0;
 padding-right: 0;
 padding-top: var(--n-padding-vertical);
 padding-bottom: var(--n-padding-vertical);
 word-break: break-word;
 display: inline-block;
 vertical-align: bottom;
 box-sizing: border-box;
 line-height: var(--n-line-height-textarea);
 margin: 0;
 resize: none;
 white-space: pre-wrap;
 scroll-padding-block-end: var(--n-padding-vertical);
 `),s("textarea-mirror",`
 width: 100%;
 pointer-events: none;
 overflow: hidden;
 visibility: hidden;
 position: static;
 white-space: pre-wrap;
 overflow-wrap: break-word;
 `)]),F("pair",[s("input-el, placeholder","text-align: center;"),s("separator",`
 display: flex;
 align-items: center;
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 white-space: nowrap;
 `,[m("icon",`
 color: var(--n-icon-color);
 `),m("base-icon",`
 color: var(--n-icon-color);
 `)])]),F("disabled",`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `,[s("border","border: var(--n-border-disabled);"),s("input-el, textarea-el",`
 cursor: not-allowed;
 color: var(--n-text-color-disabled);
 text-decoration-color: var(--n-text-color-disabled);
 `),s("placeholder","color: var(--n-placeholder-color-disabled);"),s("separator","color: var(--n-text-color-disabled);",[m("icon",`
 color: var(--n-icon-color-disabled);
 `),m("base-icon",`
 color: var(--n-icon-color-disabled);
 `)]),m("input-word-count",`
 color: var(--n-count-text-color-disabled);
 `),s("suffix, prefix","color: var(--n-text-color-disabled);",[m("icon",`
 color: var(--n-icon-color-disabled);
 `),m("internal-icon",`
 color: var(--n-icon-color-disabled);
 `)])]),Y("disabled",[s("eye",`
 color: var(--n-icon-color);
 cursor: pointer;
 `,[y("&:hover",`
 color: var(--n-icon-color-hover);
 `),y("&:active",`
 color: var(--n-icon-color-pressed);
 `)]),y("&:hover",[s("state-border","border: var(--n-border-hover);")]),F("focus","background-color: var(--n-color-focus);",[s("state-border",`
 border: var(--n-border-focus);
 box-shadow: var(--n-box-shadow-focus);
 `)])]),s("border, state-border",`
 box-sizing: border-box;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border-radius: inherit;
 border: var(--n-border);
 transition:
 box-shadow .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `),s("state-border",`
 border-color: #0000;
 z-index: 1;
 `),s("prefix","margin-right: 4px;"),s("suffix",`
 margin-left: 4px;
 `),s("suffix, prefix",`
 transition: color .3s var(--n-bezier);
 flex-wrap: nowrap;
 flex-shrink: 0;
 line-height: var(--n-height);
 white-space: nowrap;
 display: inline-flex;
 align-items: center;
 justify-content: center;
 color: var(--n-suffix-text-color);
 `,[m("base-loading",`
 font-size: var(--n-icon-size);
 margin: 0 2px;
 color: var(--n-loading-color);
 `),m("base-clear",`
 font-size: var(--n-icon-size);
 `,[s("placeholder",[m("base-icon",`
 transition: color .3s var(--n-bezier);
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 `)])]),y(">",[m("icon",`
 transition: color .3s var(--n-bezier);
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 `)]),m("base-icon",`
 font-size: var(--n-icon-size);
 `)]),m("input-word-count",`
 pointer-events: none;
 line-height: 1.5;
 font-size: .85em;
 color: var(--n-count-text-color);
 transition: color .3s var(--n-bezier);
 margin-left: 4px;
 font-variant: tabular-nums;
 `),["warning","error"].map(r=>F(`${r}-status`,[Y("disabled",[m("base-loading",`
 color: var(--n-loading-color-${r})
 `),s("input-el, textarea-el",`
 caret-color: var(--n-caret-color-${r});
 `),s("state-border",`
 border: var(--n-border-${r});
 `),y("&:hover",[s("state-border",`
 border: var(--n-border-hover-${r});
 `)]),y("&:focus",`
 background-color: var(--n-color-focus-${r});
 `,[s("state-border",`
 box-shadow: var(--n-box-shadow-focus-${r});
 border: var(--n-border-focus-${r});
 `)]),F("focus",`
 background-color: var(--n-color-focus-${r});
 `,[s("state-border",`
 box-shadow: var(--n-box-shadow-focus-${r});
 border: var(--n-border-focus-${r});
 `)])])]))]),Hr=m("input",[F("disabled",[s("input-el, textarea-el",`
 -webkit-text-fill-color: var(--n-text-color-disabled);
 `)])]),Or=Object.assign(Object.assign({},Ee.props),{bordered:{type:Boolean,default:void 0},type:{type:String,default:"text"},placeholder:[Array,String],defaultValue:{type:[String,Array],default:null},value:[String,Array],disabled:{type:Boolean,default:void 0},size:String,rows:{type:[Number,String],default:3},round:Boolean,minlength:[String,Number],maxlength:[String,Number],clearable:Boolean,autosize:{type:[Boolean,Object],default:!1},pair:Boolean,separator:String,readonly:{type:[String,Boolean],default:!1},passivelyActivated:Boolean,showPasswordOn:String,stateful:{type:Boolean,default:!0},autofocus:Boolean,inputProps:Object,resizable:{type:Boolean,default:!0},showCount:Boolean,loading:{type:Boolean,default:void 0},allowInput:Function,renderCount:Function,onMousedown:Function,onKeydown:Function,onKeyup:[Function,Array],onInput:[Function,Array],onFocus:[Function,Array],onBlur:[Function,Array],onClick:[Function,Array],onChange:[Function,Array],onClear:[Function,Array],countGraphemes:Function,status:String,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],textDecoration:[String,Array],attrSize:{type:Number,default:20},onInputBlur:[Function,Array],onInputFocus:[Function,Array],onDeactivate:[Function,Array],onActivate:[Function,Array],onWrapperFocus:[Function,Array],onWrapperBlur:[Function,Array],internalDeactivateOnEnter:Boolean,internalForceFocus:Boolean,internalLoadingBeforeSuffix:{type:Boolean,default:!0},showPasswordToggle:Boolean}),Ur=W({name:"Input",props:Or,setup(r){const{mergedClsPrefixRef:u,mergedBorderedRef:n,inlineThemeDisabled:$,mergedRtlRef:z}=vr(r),g=Ee("Input","-input",Vr,Dr,r,u);pr&&Pe("-input-safari",Hr,u);const h=w(null),c=w(null),d=w(null),l=w(null),i=w(null),f=w(null),b=w(null),B=Wr(b),S=w(null),{localeRef:le}=Ar("Input"),V=w(r.defaultValue),ie=xe(r,"value"),A=Fr(ie,V),T=gr(r),{mergedSizeRef:O,mergedDisabledRef:P,mergedStatusRef:se}=T,E=w(!1),k=w(!1),_=w(!1),I=w(!1);let N=null;const K=R(()=>{const{placeholder:e,pair:o}=r;return o?Array.isArray(e)?e:e===void 0?["",""]:[e,e]:e===void 0?[le.value.placeholder]:[e]}),ce=R(()=>{const{value:e}=_,{value:o}=A,{value:a}=K;return!e&&(te(o)||Array.isArray(o)&&te(o[0]))&&a[0]}),de=R(()=>{const{value:e}=_,{value:o}=A,{value:a}=K;return!e&&a[1]&&(te(o)||Array.isArray(o)&&te(o[1]))}),j=$e(()=>r.internalForceFocus||E.value),ue=$e(()=>{if(P.value||r.readonly||!r.clearable||!j.value&&!k.value)return!1;const{value:e}=A,{value:o}=j;return r.pair?!!(Array.isArray(e)&&(e[0]||e[1]))&&(k.value||o):!!e&&(k.value||o)}),he=R(()=>{const{showPasswordOn:e}=r;if(e)return e;if(r.showPasswordToggle)return"click"}),U=w(!1),ke=R(()=>{const{textDecoration:e}=r;return e?Array.isArray(e)?e.map(o=>({textDecoration:o})):[{textDecoration:e}]:["",""]}),Ce=w(void 0),Ie=()=>{var e,o;if(r.type==="textarea"){const{autosize:a}=r;if(a&&(Ce.value=(o=(e=S.value)===null||e===void 0?void 0:e.$el)===null||o===void 0?void 0:o.offsetWidth),!c.value||typeof a=="boolean")return;const{paddingTop:p,paddingBottom:x,lineHeight:v}=window.getComputedStyle(c.value),M=Number(p.slice(0,-2)),D=Number(x.slice(0,-2)),L=Number(v.slice(0,-2)),{value:G}=d;if(!G)return;if(a.minRows){const X=Math.max(a.minRows,1),pe=`${M+D+L*X}px`;G.style.minHeight=pe}if(a.maxRows){const X=`${M+D+L*a.maxRows}px`;G.style.maxHeight=X}}},Me=R(()=>{const{maxlength:e}=r;return e===void 0?void 0:Number(e)});br(()=>{const{value:e}=A;Array.isArray(e)||ve(e)});const De=xr().proxy;function q(e){const{onUpdateValue:o,"onUpdate:value":a,onInput:p}=r,{nTriggerFormInput:x}=T;o&&C(o,e),a&&C(a,e),p&&C(p,e),V.value=e,x()}function J(e){const{onChange:o}=r,{nTriggerFormChange:a}=T;o&&C(o,e),V.value=e,a()}function Le(e){const{onBlur:o}=r,{nTriggerFormBlur:a}=T;o&&C(o,e),a()}function We(e){const{onFocus:o}=r,{nTriggerFormFocus:a}=T;o&&C(o,e),a()}function Ve(e){const{onClear:o}=r;o&&C(o,e)}function He(e){const{onInputBlur:o}=r;o&&C(o,e)}function Oe(e){const{onInputFocus:o}=r;o&&C(o,e)}function Ne(){const{onDeactivate:e}=r;e&&C(e)}function Ke(){const{onActivate:e}=r;e&&C(e)}function je(e){const{onClick:o}=r;o&&C(o,e)}function Ue(e){const{onWrapperFocus:o}=r;o&&C(o,e)}function Ge(e){const{onWrapperBlur:o}=r;o&&C(o,e)}function Xe(){_.value=!0}function Ye(e){_.value=!1,e.target===f.value?Q(e,1):Q(e,0)}function Q(e,o=0,a="input"){const p=e.target.value;if(ve(p),e instanceof InputEvent&&!e.isComposing&&(_.value=!1),r.type==="textarea"){const{value:v}=S;v&&v.syncUnifiedContainer()}if(N=p,_.value)return;B.recordCursor();const x=Ze(p);if(x)if(!r.pair)a==="input"?q(p):J(p);else{let{value:v}=A;Array.isArray(v)?v=[v[0],v[1]]:v=["",""],v[o]=p,a==="input"?q(v):J(v)}De.$forceUpdate(),x||Fe(B.restoreCursor)}function Ze(e){const{countGraphemes:o,maxlength:a,minlength:p}=r;if(o){let v;if(a!==void 0&&(v===void 0&&(v=o(e)),v>Number(a))||p!==void 0&&(v===void 0&&(v=o(e)),v<Number(a)))return!1}const{allowInput:x}=r;return typeof x=="function"?x(e):!0}function qe(e){He(e),e.relatedTarget===h.value&&Ne(),e.relatedTarget!==null&&(e.relatedTarget===i.value||e.relatedTarget===f.value||e.relatedTarget===c.value)||(I.value=!1),ee(e,"blur"),b.value=null}function Je(e,o){Oe(e),E.value=!0,I.value=!0,Ke(),ee(e,"focus"),o===0?b.value=i.value:o===1?b.value=f.value:o===2&&(b.value=c.value)}function Qe(e){r.passivelyActivated&&(Ge(e),ee(e,"blur"))}function eo(e){r.passivelyActivated&&(E.value=!0,Ue(e),ee(e,"focus"))}function ee(e,o){e.relatedTarget!==null&&(e.relatedTarget===i.value||e.relatedTarget===f.value||e.relatedTarget===c.value||e.relatedTarget===h.value)||(o==="focus"?(We(e),E.value=!0):o==="blur"&&(Le(e),E.value=!1))}function oo(e,o){Q(e,o,"change")}function ro(e){je(e)}function no(e){Ve(e),r.pair?(q(["",""]),J(["",""])):(q(""),J(""))}function to(e){const{onMousedown:o}=r;o&&o(e);const{tagName:a}=e.target;if(a!=="INPUT"&&a!=="TEXTAREA"){if(r.resizable){const{value:p}=h;if(p){const{left:x,top:v,width:M,height:D}=p.getBoundingClientRect(),L=14;if(x+M-L<e.clientX&&e.clientX<x+M&&v+D-L<e.clientY&&e.clientY<v+D)return}}e.preventDefault(),E.value||ye()}}function ao(){var e;k.value=!0,r.type==="textarea"&&((e=S.value)===null||e===void 0||e.handleMouseEnterWrapper())}function lo(){var e;k.value=!1,r.type==="textarea"&&((e=S.value)===null||e===void 0||e.handleMouseLeaveWrapper())}function io(){P.value||he.value==="click"&&(U.value=!U.value)}function so(e){if(P.value)return;e.preventDefault();const o=p=>{p.preventDefault(),Re("mouseup",document,o)};if(_e("mouseup",document,o),he.value!=="mousedown")return;U.value=!0;const a=()=>{U.value=!1,Re("mouseup",document,a)};_e("mouseup",document,a)}function co(e){r.onKeyup&&C(r.onKeyup,e)}function uo(e){switch(r.onKeydown&&C(r.onKeydown,e),e.key){case"Escape":fe();break;case"Enter":ho(e);break}}function ho(e){var o,a;if(r.passivelyActivated){const{value:p}=I;if(p){r.internalDeactivateOnEnter&&fe();return}e.preventDefault(),r.type==="textarea"?(o=c.value)===null||o===void 0||o.focus():(a=i.value)===null||a===void 0||a.focus()}}function fe(){r.passivelyActivated&&(I.value=!1,Fe(()=>{var e;(e=h.value)===null||e===void 0||e.focus()}))}function ye(){var e,o,a;P.value||(r.passivelyActivated?(e=h.value)===null||e===void 0||e.focus():((o=c.value)===null||o===void 0||o.focus(),(a=i.value)===null||a===void 0||a.focus()))}function fo(){var e;!((e=h.value)===null||e===void 0)&&e.contains(document.activeElement)&&document.activeElement.blur()}function vo(){var e,o;(e=c.value)===null||e===void 0||e.select(),(o=i.value)===null||o===void 0||o.select()}function po(){P.value||(c.value?c.value.focus():i.value&&i.value.focus())}function go(){const{value:e}=h;e!=null&&e.contains(document.activeElement)&&e!==document.activeElement&&fe()}function bo(e){if(r.type==="textarea"){const{value:o}=c;o==null||o.scrollTo(e)}else{const{value:o}=i;o==null||o.scrollTo(e)}}function ve(e){const{type:o,pair:a,autosize:p}=r;if(!a&&p)if(o==="textarea"){const{value:x}=d;x&&(x.textContent=(e??"")+`\r
`)}else{const{value:x}=l;x&&(e?x.textContent=e:x.innerHTML="&nbsp;")}}function xo(){Ie()}const ze=w({top:"0"});function mo(e){var o;const{scrollTop:a}=e.target;ze.value.top=`${-a}px`,(o=S.value)===null||o===void 0||o.syncUnifiedContainer()}let oe=null;Ae(()=>{const{autosize:e,type:o}=r;e&&o==="textarea"?oe=me(A,a=>{!Array.isArray(a)&&a!==N&&ve(a)}):oe==null||oe()});let re=null;Ae(()=>{r.type==="textarea"?re=me(A,e=>{var o;!Array.isArray(e)&&e!==N&&((o=S.value)===null||o===void 0||o.syncUnifiedContainer())}):re==null||re()}),mr(Te,{mergedValueRef:A,maxlengthRef:Me,mergedClsPrefixRef:u,countGraphemesRef:xe(r,"countGraphemes")});const wo={wrapperElRef:h,inputElRef:i,textareaElRef:c,isCompositing:_,focus:ye,blur:fo,select:vo,deactivate:go,activate:po,scrollTo:bo},Co=wr("Input",z,u),Se=R(()=>{const{value:e}=O,{common:{cubicBezierEaseInOut:o},self:{color:a,borderRadius:p,textColor:x,caretColor:v,caretColorError:M,caretColorWarning:D,textDecorationColor:L,border:G,borderDisabled:X,borderHover:pe,borderFocus:yo,placeholderColor:zo,placeholderColorDisabled:So,lineHeightTextarea:$o,colorDisabled:Ao,colorFocus:Fo,textColorDisabled:_o,boxShadowFocus:Ro,iconSize:Bo,colorFocusWarning:Po,boxShadowFocusWarning:Eo,borderWarning:To,borderFocusWarning:ko,borderHoverWarning:Io,colorFocusError:Mo,boxShadowFocusError:Do,borderError:Lo,borderFocusError:Wo,borderHoverError:Vo,clearSize:Ho,clearColor:Oo,clearColorHover:No,clearColorPressed:Ko,iconColor:jo,iconColorDisabled:Uo,suffixTextColor:Go,countTextColor:Xo,countTextColorDisabled:Yo,iconColorHover:Zo,iconColorPressed:qo,loadingColor:Jo,loadingColorError:Qo,loadingColorWarning:er,[be("padding",e)]:or,[be("fontSize",e)]:rr,[be("height",e)]:nr}}=g.value,{left:tr,right:ar}=$r(or);return{"--n-bezier":o,"--n-count-text-color":Xo,"--n-count-text-color-disabled":Yo,"--n-color":a,"--n-font-size":rr,"--n-border-radius":p,"--n-height":nr,"--n-padding-left":tr,"--n-padding-right":ar,"--n-text-color":x,"--n-caret-color":v,"--n-text-decoration-color":L,"--n-border":G,"--n-border-disabled":X,"--n-border-hover":pe,"--n-border-focus":yo,"--n-placeholder-color":zo,"--n-placeholder-color-disabled":So,"--n-icon-size":Bo,"--n-line-height-textarea":$o,"--n-color-disabled":Ao,"--n-color-focus":Fo,"--n-text-color-disabled":_o,"--n-box-shadow-focus":Ro,"--n-loading-color":Jo,"--n-caret-color-warning":D,"--n-color-focus-warning":Po,"--n-box-shadow-focus-warning":Eo,"--n-border-warning":To,"--n-border-focus-warning":ko,"--n-border-hover-warning":Io,"--n-loading-color-warning":er,"--n-caret-color-error":M,"--n-color-focus-error":Mo,"--n-box-shadow-focus-error":Do,"--n-border-error":Lo,"--n-border-focus-error":Wo,"--n-border-hover-error":Vo,"--n-loading-color-error":Qo,"--n-clear-color":Oo,"--n-clear-size":Ho,"--n-clear-color-hover":No,"--n-clear-color-pressed":Ko,"--n-icon-color":jo,"--n-icon-color-hover":Zo,"--n-icon-color-pressed":qo,"--n-icon-color-disabled":Uo,"--n-suffix-text-color":Go}}),H=$?Cr("input",R(()=>{const{value:e}=O;return e[0]}),Se,r):void 0;return Object.assign(Object.assign({},wo),{wrapperElRef:h,inputElRef:i,inputMirrorElRef:l,inputEl2Ref:f,textareaElRef:c,textareaMirrorElRef:d,textareaScrollbarInstRef:S,rtlEnabled:Co,uncontrolledValue:V,mergedValue:A,passwordVisible:U,mergedPlaceholder:K,showPlaceholder1:ce,showPlaceholder2:de,mergedFocus:j,isComposing:_,activated:I,showClearButton:ue,mergedSize:O,mergedDisabled:P,textDecorationStyle:ke,mergedClsPrefix:u,mergedBordered:n,mergedShowPasswordOn:he,placeholderStyle:ze,mergedStatus:se,textAreaScrollContainerWidth:Ce,handleTextAreaScroll:mo,handleCompositionStart:Xe,handleCompositionEnd:Ye,handleInput:Q,handleInputBlur:qe,handleInputFocus:Je,handleWrapperBlur:Qe,handleWrapperFocus:eo,handleMouseEnter:ao,handleMouseLeave:lo,handleMouseDown:to,handleChange:oo,handleClick:ro,handleClear:no,handlePasswordToggleClick:io,handlePasswordToggleMousedown:so,handleWrapperKeydown:uo,handleWrapperKeyup:co,handleTextAreaMirrorResize:xo,getTextareaScrollContainer:()=>c.value,mergedTheme:g,cssVars:$?void 0:Se,themeClass:H==null?void 0:H.themeClass,onRender:H==null?void 0:H.onRender})},render(){var r,u;const{mergedClsPrefix:n,mergedStatus:$,themeClass:z,type:g,countGraphemes:h,onRender:c}=this,d=this.$slots;return c==null||c(),t("div",{ref:"wrapperElRef",class:[`${n}-input`,z,$&&`${n}-input--${$}-status`,{[`${n}-input--rtl`]:this.rtlEnabled,[`${n}-input--disabled`]:this.mergedDisabled,[`${n}-input--textarea`]:g==="textarea",[`${n}-input--resizable`]:this.resizable&&!this.autosize,[`${n}-input--autosize`]:this.autosize,[`${n}-input--round`]:this.round&&g!=="textarea",[`${n}-input--pair`]:this.pair,[`${n}-input--focus`]:this.mergedFocus,[`${n}-input--stateful`]:this.stateful}],style:this.cssVars,tabindex:!this.mergedDisabled&&this.passivelyActivated&&!this.activated?0:void 0,onFocus:this.handleWrapperFocus,onBlur:this.handleWrapperBlur,onClick:this.handleClick,onMousedown:this.handleMouseDown,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd,onKeyup:this.handleWrapperKeyup,onKeydown:this.handleWrapperKeydown},t("div",{class:`${n}-input-wrapper`},ne(d.prefix,l=>l&&t("div",{class:`${n}-input__prefix`},l)),g==="textarea"?t(yr,{ref:"textareaScrollbarInstRef",class:`${n}-input__textarea`,container:this.getTextareaScrollContainer,triggerDisplayManually:!0,useUnifiedContainer:!0,internalHoistYRail:!0},{default:()=>{var l,i;const{textAreaScrollContainerWidth:f}=this,b={width:this.autosize&&f&&`${f}px`};return t(zr,null,t("textarea",Object.assign({},this.inputProps,{ref:"textareaElRef",class:[`${n}-input__textarea-el`,(l=this.inputProps)===null||l===void 0?void 0:l.class],autofocus:this.autofocus,rows:Number(this.rows),placeholder:this.placeholder,value:this.mergedValue,disabled:this.mergedDisabled,maxlength:h?void 0:this.maxlength,minlength:h?void 0:this.minlength,readonly:this.readonly,tabindex:this.passivelyActivated&&!this.activated?-1:void 0,style:[this.textDecorationStyle[0],(i=this.inputProps)===null||i===void 0?void 0:i.style,b],onBlur:this.handleInputBlur,onFocus:B=>{this.handleInputFocus(B,2)},onInput:this.handleInput,onChange:this.handleChange,onScroll:this.handleTextAreaScroll})),this.showPlaceholder1?t("div",{class:`${n}-input__placeholder`,style:[this.placeholderStyle,b],key:"placeholder"},this.mergedPlaceholder[0]):null,this.autosize?t(Sr,{onResize:this.handleTextAreaMirrorResize},{default:()=>t("div",{ref:"textareaMirrorElRef",class:`${n}-input__textarea-mirror`,key:"mirror"})}):null)}}):t("div",{class:`${n}-input__input`},t("input",Object.assign({type:g==="password"&&this.mergedShowPasswordOn&&this.passwordVisible?"text":g},this.inputProps,{ref:"inputElRef",class:[`${n}-input__input-el`,(r=this.inputProps)===null||r===void 0?void 0:r.class],style:[this.textDecorationStyle[0],(u=this.inputProps)===null||u===void 0?void 0:u.style],tabindex:this.passivelyActivated&&!this.activated?-1:void 0,placeholder:this.mergedPlaceholder[0],disabled:this.mergedDisabled,maxlength:h?void 0:this.maxlength,minlength:h?void 0:this.minlength,value:Array.isArray(this.mergedValue)?this.mergedValue[0]:this.mergedValue,readonly:this.readonly,autofocus:this.autofocus,size:this.attrSize,onBlur:this.handleInputBlur,onFocus:l=>{this.handleInputFocus(l,0)},onInput:l=>{this.handleInput(l,0)},onChange:l=>{this.handleChange(l,0)}})),this.showPlaceholder1?t("div",{class:`${n}-input__placeholder`},t("span",null,this.mergedPlaceholder[0])):null,this.autosize?t("div",{class:`${n}-input__input-mirror`,key:"mirror",ref:"inputMirrorElRef"}," "):null),!this.pair&&ne(d.suffix,l=>l||this.clearable||this.showCount||this.mergedShowPasswordOn||this.loading!==void 0?t("div",{class:`${n}-input__suffix`},[ne(d["clear-icon-placeholder"],i=>(this.clearable||i)&&t(we,{clsPrefix:n,show:this.showClearButton,onClear:this.handleClear},{placeholder:()=>i,icon:()=>{var f,b;return(b=(f=this.$slots)["clear-icon"])===null||b===void 0?void 0:b.call(f)}})),this.internalLoadingBeforeSuffix?null:l,this.loading!==void 0?t(Tr,{clsPrefix:n,loading:this.loading,showArrow:!1,showClear:!1,style:this.cssVars}):null,this.internalLoadingBeforeSuffix?l:null,this.showCount&&this.type!=="textarea"?t(Be,null,{default:i=>{var f;return(f=d.count)===null||f===void 0?void 0:f.call(d,i)}}):null,this.mergedShowPasswordOn&&this.type==="password"?t("div",{class:`${n}-input__eye`,onMousedown:this.handlePasswordToggleMousedown,onClick:this.handlePasswordToggleClick},this.passwordVisible?Z(d["password-visible-icon"],()=>[t(ae,{clsPrefix:n},{default:()=>t(_r,null)})]):Z(d["password-invisible-icon"],()=>[t(ae,{clsPrefix:n},{default:()=>t(Rr,null)})])):null]):null)),this.pair?t("span",{class:`${n}-input__separator`},Z(d.separator,()=>[this.separator])):null,this.pair?t("div",{class:`${n}-input-wrapper`},t("div",{class:`${n}-input__input`},t("input",{ref:"inputEl2Ref",type:this.type,class:`${n}-input__input-el`,tabindex:this.passivelyActivated&&!this.activated?-1:void 0,placeholder:this.mergedPlaceholder[1],disabled:this.mergedDisabled,maxlength:h?void 0:this.maxlength,minlength:h?void 0:this.minlength,value:Array.isArray(this.mergedValue)?this.mergedValue[1]:void 0,readonly:this.readonly,style:this.textDecorationStyle[1],onBlur:this.handleInputBlur,onFocus:l=>{this.handleInputFocus(l,1)},onInput:l=>{this.handleInput(l,1)},onChange:l=>{this.handleChange(l,1)}}),this.showPlaceholder2?t("div",{class:`${n}-input__placeholder`},t("span",null,this.mergedPlaceholder[1])):null),ne(d.suffix,l=>(this.clearable||l)&&t("div",{class:`${n}-input__suffix`},[this.clearable&&t(we,{clsPrefix:n,show:this.showClearButton,onClear:this.handleClear},{icon:()=>{var i;return(i=d["clear-icon"])===null||i===void 0?void 0:i.call(d)},placeholder:()=>{var i;return(i=d["clear-icon-placeholder"])===null||i===void 0?void 0:i.call(d)}}),l]))):null,this.mergedBordered?t("div",{class:`${n}-input__border`}):null,this.mergedBordered?t("div",{class:`${n}-input__state-border`}):null,this.showCount&&g==="textarea"?t(Be,null,{default:l=>{var i;const{renderCount:f}=this;return f?f(l):(i=d.count)===null||i===void 0?void 0:i.call(d,l)}}):null)}});export{Br as C,_r as E,Ur as N,Tr as a,Dr as i};
