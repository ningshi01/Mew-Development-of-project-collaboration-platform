import R from"src/assets/tempLogo.png";import N from"src/assets/ScholarPage .jpg";import{b as o,a as i,a$ as p,e as C,u as y,bz as I,j as x,g as k,h as z,i as L,k as w,aK as $,aC as V,aD as G,aF as t,aG as l,aI as d,aL as v,aJ as T,aN as E}from"./index-b27597f8.js";import{i as j,N as D}from"./Input-f8b5fbf4.js";import{N as O}from"./Dropdown-488366d3.js";import"./use-locale-c044757c.js";import"./Popover-61edb1a7.js";import"./format-length-c9d165c6.js";import"./Icon-98a0c14c.js";import"./create-657dc0dd.js";const F=o("input-group",`
 display: inline-flex;
 width: 100%;
 flex-wrap: nowrap;
 vertical-align: bottom;
`,[i(">",[o("input",[i("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),i("&:not(:first-child)",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 margin-left: -1px!important;
 `)]),o("button",[i("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `,[p("state-border, border",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `)]),i("&:not(:first-child)",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `,[p("state-border, border",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `)])]),i("*",[i("&:not(:last-child)",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `,[i(">",[o("input",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),o("base-selection",[o("base-selection-label",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),o("base-selection-tags",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `),p("box-shadow, border, state-border",`
 border-top-right-radius: 0!important;
 border-bottom-right-radius: 0!important;
 `)])])]),i("&:not(:first-child)",`
 margin-left: -1px!important;
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `,[i(">",[o("input",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),o("base-selection",[o("base-selection-label",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),o("base-selection-tags",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `),p("box-shadow, border, state-border",`
 border-top-left-radius: 0!important;
 border-bottom-left-radius: 0!important;
 `)])])])])])]),H={},K=C({name:"InputGroup",props:H,setup(e){const{mergedClsPrefixRef:r}=y(e);return I("-input-group",F,r),{mergedClsPrefix:r}},render(){const{mergedClsPrefix:e}=this;return x("div",{class:`${e}-input-group`},this.$slots)}}),J=o("input-group-label",`
 position: relative;
 user-select: none;
 -webkit-user-select: none;
 box-sizing: border-box;
 padding: 0 12px;
 display: inline-block;
 border-radius: var(--n-border-radius);
 background-color: var(--n-group-label-color);
 color: var(--n-group-label-text-color);
 font-size: var(--n-font-size);
 line-height: var(--n-height);
 height: var(--n-height);
 flex-shrink: 0;
 white-space: nowrap;
 transition: 
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
`,[p("border",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border-radius: inherit;
 border: var(--n-group-label-border);
 transition: border-color .3s var(--n-bezier);
 `)]),M=Object.assign(Object.assign({},k.props),{size:{type:String,default:"medium"},bordered:{type:Boolean,default:void 0}}),U=C({name:"InputGroupLabel",props:M,setup(e){const{mergedBorderedRef:r,mergedClsPrefixRef:s,inlineThemeDisabled:a}=y(e),m=k("Input","-input-group-label",J,j,e,s),u=z(()=>{const{size:h}=e,{common:{cubicBezierEaseInOut:g},self:{groupLabelColor:c,borderRadius:b,groupLabelTextColor:_,lineHeight:f,groupLabelBorder:S,[w("fontSize",h)]:B,[w("height",h)]:P}}=m.value;return{"--n-bezier":g,"--n-group-label-color":c,"--n-group-label-border":S,"--n-border-radius":b,"--n-group-label-text-color":_,"--n-font-size":B,"--n-line-height":f,"--n-height":P}}),n=a?L("input-group-label",z(()=>e.size[0]),u,e):void 0;return{mergedClsPrefix:s,mergedBordered:r,cssVars:a?void 0:u,themeClass:n==null?void 0:n.themeClass,onRender:n==null?void 0:n.onRender}},render(){var e,r,s;const{mergedClsPrefix:a}=this;return(e=this.onRender)===null||e===void 0||e.call(this),x("div",{class:[`${a}-input-group-label`,this.themeClass],style:this.cssVars},(s=(r=this.$slots).default)===null||s===void 0?void 0:s.call(r),this.mergedBordered?x("div",{class:`${a}-input-group-label__border`}):null)}}),q={ref:"container",class:"container"},A={class:"topBar"},Q=t("i",{class:"iconfont icon-gerentouxiang_o user"},null,-1),W={class:"Username"},X={class:"searchContainer"},Y=t("div",{class:"titleContainer"},[t("div",{class:"flexContainer"},[t("h1",{class:"title1"},"Retrieve scholars")])],-1),Z={class:"inputContainer"},tt=t("i",{class:"iconfont icon-sousuo souSuo"},null,-1),et={id:"canvas",ref:"canvas"},ot=t("div",{class:"PageContainer"},[t("img",{src:N,width:"903",height:"801",class:"background",alt:" "})],-1),bt=C({__name:"ScholarSearch",setup(e){const r=$(),s=()=>{r.push({name:"Introduction"})},a=()=>{r.push({name:"Earth"})},m=()=>{r.push({name:"ScholarSearch"})},u=[{label:"用户资料",key:"profile"},{label:"编辑用户资料",key:"editProfile"},{label:"退出登录",key:"logout"}];return(n,h)=>{const g=O,c=U,b=D,_=E,f=K;return V(),G(T,null,[t("div",q,[t("div",A,[t("img",{src:R,onClick:s,class:"logo"}),t("h3",{class:"paperSearch word1",onClick:a},"论文检索"),t("h3",{class:"scholarSearch word1",onClick:m},"学者检索"),Q,t("div",W,[l(g,{trigger:"hover",options:u},{default:d(()=>[v(" ling ")]),_:1})])]),t("div",X,[Y,t("div",Z,[l(f,{class:""},{default:d(()=>[l(c,{size:"large"},{default:d(()=>[v("姓名")]),_:1}),l(b,{style:{width:"22%",height:"50%"},size:"large",placeholder:"请输入姓名(必填)"}),l(c,{size:"large"},{default:d(()=>[v("科研机构")]),_:1}),l(b,{style:{width:"50%",height:"60%"},size:"large",placeholder:"请尽量填写详细"}),l(_,{type:"info",class:"searchButton"},{default:d(()=>[tt]),_:1})]),_:1})])]),t("canvas",et,null,512)],512),ot],64)}}});export{bt as default};
