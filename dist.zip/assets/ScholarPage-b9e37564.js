import{c as Be,bK as Ue,b as y,a$ as s,c0 as xe,a as H,d as k,bp as we,e as ve,u as fe,g as ne,b$ as qe,r as F,b0 as Qe,h as j,i as Ie,cm as he,j as m,bn as V,c1 as Xe,N as Ye,bE as me,k as I,p as pe,b_ as P,aU as Ge,aX as Je,aV as Ze,aW as et,bm as Se,az as K,bP as oe,aC as T,aE as tt,aI as b,aF as t,aG as d,aM as p,bh as it,aP as U,aQ as q,aL as A,b2 as ae,aA as se,bN as ie,aD as O,aB as ge,aJ as te,be as Fe,aK as Pe,by as ze,b7 as J,b8 as Z,cs as nt,bx as Ce,bw as ee,ct as ot,cu as $e,cv as ke}from"./index-b27597f8.js";import{_ as at,b as st,a as lt}from"./Statistic-fa67906d.js";import{a as rt,_ as ct}from"./Popover-61edb1a7.js";import{C as dt,D as ut}from"./index-eb756369.js";import{_ as ht}from"./Scrollbar-9f2820eb.js";import{f as mt}from"./format-length-c9d165c6.js";import{u as pt}from"./use-houdini-f27d5895.js";import{N as _t}from"./Icon-98a0c14c.js";const vt={buttonHeightSmall:"14px",buttonHeightMedium:"18px",buttonHeightLarge:"22px",buttonWidthSmall:"14px",buttonWidthMedium:"18px",buttonWidthLarge:"22px",buttonWidthPressedSmall:"20px",buttonWidthPressedMedium:"24px",buttonWidthPressedLarge:"28px",railHeightSmall:"18px",railHeightMedium:"22px",railHeightLarge:"26px",railWidthSmall:"32px",railWidthMedium:"40px",railWidthLarge:"48px"},ft=e=>{const{primaryColor:r,opacityDisabled:i,borderRadius:a,textColor3:n}=e,c="rgba(0, 0, 0, .14)";return Object.assign(Object.assign({},vt),{iconColor:n,textColor:"white",loadingColor:r,opacityDisabled:i,railColor:c,railColorActive:r,buttonBoxShadow:"0 1px 4px 0 rgba(0, 0, 0, 0.3), inset 0 0 1px 0 rgba(0, 0, 0, 0.05)",buttonColor:"#FFF",railBorderRadiusSmall:a,railBorderRadiusMedium:a,railBorderRadiusLarge:a,buttonBorderRadiusSmall:a,buttonBorderRadiusMedium:a,buttonBorderRadiusLarge:a,boxShadowFocus:`0 0 0 2px ${Ue(r,{alpha:.2})}`})},gt={name:"Switch",common:Be,self:ft},bt=gt,yt={titleMarginMedium:"0 0 6px 0",titleMarginLarge:"-2px 0 6px 0",titleFontSizeMedium:"14px",titleFontSizeLarge:"16px",iconSizeMedium:"14px",iconSizeLarge:"14px"},xt=e=>{const{textColor3:r,infoColor:i,errorColor:a,successColor:n,warningColor:c,textColor1:o,textColor2:l,railColor:f,fontWeightStrong:u,fontSize:g}=e;return Object.assign(Object.assign({},yt),{contentFontSize:g,titleFontWeight:u,circleBorder:`2px solid ${r}`,circleBorderInfo:`2px solid ${i}`,circleBorderError:`2px solid ${a}`,circleBorderSuccess:`2px solid ${n}`,circleBorderWarning:`2px solid ${c}`,iconColor:r,iconColorInfo:i,iconColorError:a,iconColorSuccess:n,iconColorWarning:c,titleTextColor:o,contentTextColor:l,metaTextColor:r,lineColor:f})},wt={name:"Timeline",common:Be,self:xt},St=wt,zt=y("switch",`
 height: var(--n-height);
 min-width: var(--n-width);
 vertical-align: middle;
 user-select: none;
 -webkit-user-select: none;
 display: inline-flex;
 outline: none;
 justify-content: center;
 align-items: center;
`,[s("children-placeholder",`
 height: var(--n-rail-height);
 display: flex;
 flex-direction: column;
 overflow: hidden;
 pointer-events: none;
 visibility: hidden;
 `),s("rail-placeholder",`
 display: flex;
 flex-wrap: none;
 `),s("button-placeholder",`
 width: calc(1.75 * var(--n-rail-height));
 height: var(--n-rail-height);
 `),y("base-loading",`
 position: absolute;
 top: 50%;
 left: 50%;
 transform: translateX(-50%) translateY(-50%);
 font-size: calc(var(--n-button-width) - 4px);
 color: var(--n-loading-color);
 transition: color .3s var(--n-bezier);
 `,[xe({left:"50%",top:"50%",originalTransform:"translateX(-50%) translateY(-50%)"})]),s("checked, unchecked",`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 box-sizing: border-box;
 position: absolute;
 white-space: nowrap;
 top: 0;
 bottom: 0;
 display: flex;
 align-items: center;
 line-height: 1;
 `),s("checked",`
 right: 0;
 padding-right: calc(1.25 * var(--n-rail-height) - var(--n-offset));
 `),s("unchecked",`
 left: 0;
 justify-content: flex-end;
 padding-left: calc(1.25 * var(--n-rail-height) - var(--n-offset));
 `),H("&:focus",[s("rail",`
 box-shadow: var(--n-box-shadow-focus);
 `)]),k("round",[s("rail","border-radius: calc(var(--n-rail-height) / 2);",[s("button","border-radius: calc(var(--n-button-height) / 2);")])]),we("disabled",[we("icon",[k("rubber-band",[k("pressed",[s("rail",[s("button","max-width: var(--n-button-width-pressed);")])]),s("rail",[H("&:active",[s("button","max-width: var(--n-button-width-pressed);")])]),k("active",[k("pressed",[s("rail",[s("button","left: calc(100% - var(--n-offset) - var(--n-button-width-pressed));")])]),s("rail",[H("&:active",[s("button","left: calc(100% - var(--n-offset) - var(--n-button-width-pressed));")])])])])])]),k("active",[s("rail",[s("button","left: calc(100% - var(--n-button-width) - var(--n-offset))")])]),s("rail",`
 overflow: hidden;
 height: var(--n-rail-height);
 min-width: var(--n-rail-width);
 border-radius: var(--n-rail-border-radius);
 cursor: pointer;
 position: relative;
 transition:
 opacity .3s var(--n-bezier),
 background .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 background-color: var(--n-rail-color);
 `,[s("button-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 font-size: calc(var(--n-button-height) - 4px);
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 display: flex;
 justify-content: center;
 align-items: center;
 line-height: 1;
 `,[xe()]),s("button",`
 align-items: center; 
 top: var(--n-offset);
 left: var(--n-offset);
 height: var(--n-button-height);
 width: var(--n-button-width-pressed);
 max-width: var(--n-button-width);
 border-radius: var(--n-button-border-radius);
 background-color: var(--n-button-color);
 box-shadow: var(--n-button-box-shadow);
 box-sizing: border-box;
 cursor: inherit;
 content: "";
 position: absolute;
 transition:
 background-color .3s var(--n-bezier),
 left .3s var(--n-bezier),
 opacity .3s var(--n-bezier),
 max-width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 `)]),k("active",[s("rail","background-color: var(--n-rail-color-active);")]),k("loading",[s("rail",`
 cursor: wait;
 `)]),k("disabled",[s("rail",`
 cursor: not-allowed;
 opacity: .5;
 `)])]),Ct=Object.assign(Object.assign({},ne.props),{size:{type:String,default:"medium"},value:{type:[String,Number,Boolean],default:void 0},loading:Boolean,defaultValue:{type:[String,Number,Boolean],default:!1},disabled:{type:Boolean,default:void 0},round:{type:Boolean,default:!0},"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],checkedValue:{type:[String,Number,Boolean],default:!0},uncheckedValue:{type:[String,Number,Boolean],default:!1},railStyle:Function,rubberBand:{type:Boolean,default:!0},onChange:[Function,Array]});let E;const $t=ve({name:"Switch",props:Ct,setup(e){E===void 0&&(typeof CSS<"u"?typeof CSS.supports<"u"?E=CSS.supports("width","max(1px)"):E=!1:E=!0);const{mergedClsPrefixRef:r,inlineThemeDisabled:i}=fe(e),a=ne("Switch","-switch",zt,bt,e,r),n=qe(e),{mergedSizeRef:c,mergedDisabledRef:o}=n,l=F(e.defaultValue),f=Qe(e,"value"),u=rt(f,l),g=j(()=>u.value===e.checkedValue),z=F(!1),_=F(!1),C=j(()=>{const{railStyle:h}=e;if(h)return h({focused:_.value,checked:g.value})});function $(h){const{"onUpdate:value":X,onChange:Y,onUpdateValue:G}=e,{nTriggerFormInput:le,nTriggerFormChange:re}=n;X&&me(X,h),G&&me(G,h),Y&&me(Y,h),l.value=h,le(),re()}function W(){const{nTriggerFormFocus:h}=n;h()}function w(){const{nTriggerFormBlur:h}=n;h()}function B(){e.loading||o.value||(u.value!==e.checkedValue?$(e.checkedValue):$(e.uncheckedValue))}function S(){_.value=!0,W()}function x(){_.value=!1,w(),z.value=!1}function v(h){e.loading||o.value||h.key===" "&&(u.value!==e.checkedValue?$(e.checkedValue):$(e.uncheckedValue),z.value=!1)}function R(h){e.loading||o.value||h.key===" "&&(h.preventDefault(),z.value=!0)}const Q=j(()=>{const{value:h}=c,{self:{opacityDisabled:X,railColor:Y,railColorActive:G,buttonBoxShadow:le,buttonColor:re,boxShadowFocus:He,loadingColor:Oe,textColor:We,iconColor:Ne,[I("buttonHeight",h)]:M,[I("buttonWidth",h)]:je,[I("buttonWidthPressed",h)]:De,[I("railHeight",h)]:L,[I("railWidth",h)]:D,[I("railBorderRadius",h)]:Ee,[I("buttonBorderRadius",h)]:Ae},common:{cubicBezierEaseInOut:Ke}}=a.value;let ce,de,ue;return E?(ce=`calc((${L} - ${M}) / 2)`,de=`max(${L}, ${M})`,ue=`max(${D}, calc(${D} + ${M} - ${L}))`):(ce=pe((P(L)-P(M))/2),de=pe(Math.max(P(L),P(M))),ue=P(L)>P(M)?D:pe(P(D)+P(M)-P(L))),{"--n-bezier":Ke,"--n-button-border-radius":Ae,"--n-button-box-shadow":le,"--n-button-color":re,"--n-button-width":je,"--n-button-width-pressed":De,"--n-button-height":M,"--n-height":de,"--n-offset":ce,"--n-opacity-disabled":X,"--n-rail-border-radius":Ee,"--n-rail-color":Y,"--n-rail-color-active":G,"--n-rail-height":L,"--n-rail-width":D,"--n-width":ue,"--n-box-shadow-focus":He,"--n-loading-color":Oe,"--n-text-color":We,"--n-icon-color":Ne}}),N=i?Ie("switch",j(()=>c.value[0]),Q,e):void 0;return{handleClick:B,handleBlur:x,handleFocus:S,handleKeyup:v,handleKeydown:R,mergedRailStyle:C,pressed:z,mergedClsPrefix:r,mergedValue:u,checked:g,mergedDisabled:o,cssVars:i?void 0:Q,themeClass:N==null?void 0:N.themeClass,onRender:N==null?void 0:N.onRender}},render(){const{mergedClsPrefix:e,mergedDisabled:r,checked:i,mergedRailStyle:a,onRender:n,$slots:c}=this;n==null||n();const{checked:o,unchecked:l,icon:f,"checked-icon":u,"unchecked-icon":g}=c,z=!(he(f)&&he(u)&&he(g));return m("div",{role:"switch","aria-checked":i,class:[`${e}-switch`,this.themeClass,z&&`${e}-switch--icon`,i&&`${e}-switch--active`,r&&`${e}-switch--disabled`,this.round&&`${e}-switch--round`,this.loading&&`${e}-switch--loading`,this.pressed&&`${e}-switch--pressed`,this.rubberBand&&`${e}-switch--rubber-band`],tabindex:this.mergedDisabled?void 0:0,style:this.cssVars,onClick:this.handleClick,onFocus:this.handleFocus,onBlur:this.handleBlur,onKeyup:this.handleKeyup,onKeydown:this.handleKeydown},m("div",{class:`${e}-switch__rail`,"aria-hidden":"true",style:a},V(o,_=>V(l,C=>_||C?m("div",{"aria-hidden":!0,class:`${e}-switch__children-placeholder`},m("div",{class:`${e}-switch__rail-placeholder`},m("div",{class:`${e}-switch__button-placeholder`}),_),m("div",{class:`${e}-switch__rail-placeholder`},m("div",{class:`${e}-switch__button-placeholder`}),C)):null)),m("div",{class:`${e}-switch__button`},V(f,_=>V(u,C=>V(g,$=>m(Xe,null,{default:()=>this.loading?m(Ye,{key:"loading",clsPrefix:e,strokeWidth:20}):this.checked&&(C||_)?m("div",{class:`${e}-switch__button-icon`,key:C?"checked-icon":"icon"},C||_):!this.checked&&($||_)?m("div",{class:`${e}-switch__button-icon`,key:$?"unchecked-icon":"icon"},$||_):null})))),V(o,_=>_&&m("div",{key:"checked",class:`${e}-switch__checked`},_)),V(l,_=>_&&m("div",{key:"unchecked",class:`${e}-switch__unchecked`},_)))))}}),Re=1.25,kt=y("timeline",`
 position: relative;
 width: 100%;
 display: flex;
 flex-direction: column;
 line-height: ${Re};
`,[k("horizontal",`
 flex-direction: row;
 `,[H(">",[y("timeline-item",`
 flex-shrink: 0;
 padding-right: 40px;
 `,[k("dashed-line-type",[H(">",[y("timeline-item-timeline",[s("line",`
 background-image: linear-gradient(90deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 10px 1px;
 `)])])]),H(">",[y("timeline-item-content",`
 margin-top: calc(var(--n-icon-size) + 12px);
 `,[H(">",[s("meta",`
 margin-top: 6px;
 margin-bottom: unset;
 `)])]),y("timeline-item-timeline",`
 width: 100%;
 height: calc(var(--n-icon-size) + 12px);
 `,[s("line",`
 left: var(--n-icon-size);
 top: calc(var(--n-icon-size) / 2 - 1px);
 right: 0px;
 width: unset;
 height: 2px;
 `)])])])])]),k("right-placement",[y("timeline-item",[y("timeline-item-content",`
 text-align: right;
 margin-right: calc(var(--n-icon-size) + 12px);
 `),y("timeline-item-timeline",`
 width: var(--n-icon-size);
 right: 0;
 `)])]),k("left-placement",[y("timeline-item",[y("timeline-item-content",`
 margin-left: calc(var(--n-icon-size) + 12px);
 `),y("timeline-item-timeline",`
 left: 0;
 `)])]),y("timeline-item",`
 position: relative;
 `,[H("&:last-child",[y("timeline-item-timeline",[s("line",`
 display: none;
 `)]),y("timeline-item-content",[s("meta",`
 margin-bottom: 0;
 `)])]),y("timeline-item-content",[s("title",`
 margin: var(--n-title-margin);
 font-size: var(--n-title-font-size);
 transition: color .3s var(--n-bezier);
 font-weight: var(--n-title-font-weight);
 color: var(--n-title-text-color);
 `),s("content",`
 transition: color .3s var(--n-bezier);
 font-size: var(--n-content-font-size);
 color: var(--n-content-text-color);
 `),s("meta",`
 transition: color .3s var(--n-bezier);
 font-size: 12px;
 margin-top: 6px;
 margin-bottom: 20px;
 color: var(--n-meta-text-color);
 `)]),k("dashed-line-type",[y("timeline-item-timeline",[s("line",`
 --n-color-start: var(--n-line-color);
 transition: --n-color-start .3s var(--n-bezier);
 background-color: transparent;
 background-image: linear-gradient(180deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 1px 10px;
 `)])]),y("timeline-item-timeline",`
 width: calc(var(--n-icon-size) + 12px);
 position: absolute;
 top: calc(var(--n-title-font-size) * ${Re} / 2 - var(--n-icon-size) / 2);
 height: 100%;
 `,[s("circle",`
 border: var(--n-circle-border);
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 width: var(--n-icon-size);
 height: var(--n-icon-size);
 border-radius: var(--n-icon-size);
 box-sizing: border-box;
 `),s("icon",`
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 height: var(--n-icon-size);
 width: var(--n-icon-size);
 display: flex;
 align-items: center;
 justify-content: center;
 `),s("line",`
 transition: background-color .3s var(--n-bezier);
 position: absolute;
 top: var(--n-icon-size);
 left: calc(var(--n-icon-size) / 2 - 1px);
 bottom: 0px;
 width: 2px;
 background-color: var(--n-line-color);
 `)])])]),Rt=Object.assign(Object.assign({},ne.props),{horizontal:Boolean,itemPlacement:{type:String,default:"left"},size:{type:String,default:"medium"},iconSize:Number}),Ve=Je("n-timeline"),Bt=ve({name:"Timeline",props:Rt,setup(e,{slots:r}){const{mergedClsPrefixRef:i}=fe(e),a=ne("Timeline","-timeline",kt,St,e,i);return Ge(Ve,{props:e,mergedThemeRef:a,mergedClsPrefixRef:i}),()=>{const{value:n}=i;return m("div",{class:[`${n}-timeline`,e.horizontal&&`${n}-timeline--horizontal`,`${n}-timeline--${e.size}-size`,!e.horizontal&&`${n}-timeline--${e.itemPlacement}-placement`]},r)}}}),It={time:[String,Number],title:String,content:String,color:String,lineType:{type:String,default:"default"},type:{type:String,default:"default"}},_e=ve({name:"TimelineItem",props:It,setup(e){const r=Ze(Ve);r||et("timeline-item","`n-timeline-item` must be placed inside `n-timeline`."),pt();const{inlineThemeDisabled:i}=fe(),a=j(()=>{const{props:{size:c,iconSize:o},mergedThemeRef:l}=r,{type:f}=e,{self:{titleTextColor:u,contentTextColor:g,metaTextColor:z,lineColor:_,titleFontWeight:C,contentFontSize:$,[I("iconSize",c)]:W,[I("titleMargin",c)]:w,[I("titleFontSize",c)]:B,[I("circleBorder",f)]:S,[I("iconColor",f)]:x},common:{cubicBezierEaseInOut:v}}=l.value;return{"--n-bezier":v,"--n-circle-border":S,"--n-icon-color":x,"--n-content-font-size":$,"--n-content-text-color":g,"--n-line-color":_,"--n-meta-text-color":z,"--n-title-font-size":B,"--n-title-font-weight":C,"--n-title-margin":w,"--n-title-text-color":u,"--n-icon-size":mt(o)||W}}),n=i?Ie("timeline-item",j(()=>{const{props:{size:c,iconSize:o}}=r,{type:l}=e;return`${c[0]}${o||"a"}${l[0]}`}),a,r.props):void 0;return{mergedClsPrefix:r.mergedClsPrefixRef,cssVars:i?void 0:a,themeClass:n==null?void 0:n.themeClass,onRender:n==null?void 0:n.onRender}},render(){const{mergedClsPrefix:e,color:r,onRender:i,$slots:a}=this;return i==null||i(),m("div",{class:[`${e}-timeline-item`,this.themeClass,`${e}-timeline-item--${this.type}-type`,`${e}-timeline-item--${this.lineType}-line-type`],style:this.cssVars},m("div",{class:`${e}-timeline-item-timeline`},m("div",{class:`${e}-timeline-item-timeline__line`}),V(a.icon,n=>n?m("div",{class:`${e}-timeline-item-timeline__icon`,style:{color:r}},n):m("div",{class:`${e}-timeline-item-timeline__circle`,style:{borderColor:r}}))),m("div",{class:`${e}-timeline-item-content`},V(a.header,n=>n||this.title?m("div",{class:`${e}-timeline-item-content__title`},n||this.title):null),m("div",{class:`${e}-timeline-item-content__content`},Se(a.default,()=>[this.content])),m("div",{class:`${e}-timeline-item-content__meta`},Se(a.footer,()=>[this.time]))))}});const be=e=>(U("data-v-7c33e7e6"),e=e(),q(),e),Ft={class:"container"},Pt=be(()=>t("div",{class:"title"},[t("span",{class:"title-text"},"相关数据")],-1)),Vt={class:"content"},Tt=be(()=>t("span",null,[A('"h指数"（H-index）是一种用于评估其学术研究成就和影响力的指标,它旨在综合考量一个学者的科研产出（发表的论文数量）和论文的引用次数。'),t("br"),A(" H-index 的计算方式如下：一个学者的index是一个非负整数，表示该学者的前 H 篇论文（按引用次数降序排列）每篇被引用至少 H 次，同时，该学者的其余论文（排在 H+1 或更低的位置）每篇被引用次数不超过 H 次。")],-1)),Mt=be(()=>t("span",null,'"i10 指数"（i10-index）是一种用于衡量其学术研究活跃度的指标,它表示一个学者在其学术生涯中至少有多少篇论文被引用了至少 10 次。 这个指标主要用于评估学者的学术活跃度和影响力，以及他们在学术界的持续贡献。',-1)),Lt={__name:"ScholarIndex",props:{scholar:{default:{summary_stats:[]},type:Object}},setup(e){const r=e,{scholar:i}=oe(r);return(a,n)=>{const c=at,o=ct,l=st,f=lt,u=it;return T(),tt(u,{hoverable:"",bordered:!1},{default:b(()=>[t("div",Ft,[Pt,t("div",Vt,[d(f,null,{default:b(()=>[d(l,{span:12},{default:b(()=>[d(o,{trigger:"hover",width:"300"},{trigger:b(()=>[d(c,{label:"h指数",value:p(i).summary_stats.h_index},null,8,["value"])]),default:b(()=>[Tt]),_:1})]),_:1}),d(l,{span:12},{default:b(()=>[d(o,{trigger:"hover",width:"300"},{trigger:b(()=>[d(c,{label:"i10指数",value:p(i).summary_stats.i10_index},null,8,["value"])]),default:b(()=>[Mt]),_:1})]),_:1})]),_:1}),d(f,null,{default:b(()=>[d(l,{span:12},{default:b(()=>[d(c,{label:"成果引用量",value:p(i).summary_stats.cited_by_count},null,8,["value"])]),_:1}),d(l,{span:12},{default:b(()=>[d(c,{label:"成果总量",value:p(i).summary_stats.works_count},null,8,["value"])]),_:1})]),_:1}),d(c,{label:"对外开放文献比例",value:p(i).summary_stats.oa_percent},null,8,["value"])])])]),_:1})}}},Ht=K(Lt,[["__scopeId","data-v-7c33e7e6"]]);const Te=e=>(U("data-v-07fee358"),e=e(),q(),e),Ot=Te(()=>t("div",{style:{"font-size":"16px","font-weight":"600"}},"研究领域",-1)),Wt=Te(()=>t("div",{id:"myChart"},null,-1)),Nt={__name:"ResearchField",props:{scholar:{default:{x_concepts:[]},type:Object}},setup(e){const r=e,{scholar:i}=oe(r);ae(i,()=>{n()},{deep:!0}),se(()=>{});const a=ie({option:{tooltip:{trigger:"item"},legend:{top:"0%",left:"center"},series:[{name:"ResearchField",type:"pie",radius:["40%","70%"],avoidLabelOverlap:!1,top:"20%",itemStyle:{borderRadius:10,borderColor:"#fff",borderWidth:2},label:{show:!1,position:"center"},emphasis:{label:{show:!0,fontSize:30,fontWeight:"bold"}},labelLine:{show:!1},data:[]}]}});function n(){for(let o=0;o<8;o++)a.option.series[0].data.push({value:i.value.x_concepts[o].score,name:i.value.x_concepts[o].display_name});c()}const c=()=>{ge(document.getElementById("myChart")).setOption(a.option)};return(o,l)=>(T(),O(te,null,[Ot,Wt],64))}},jt=K(Nt,[["__scopeId","data-v-07fee358"]]);const ye=e=>(U("data-v-8bed9e1c"),e=e(),q(),e),Dt={class:"head"},Et={class:"cooperationType"},At={class:"switch"},Kt={id:"scholar_diagram"},Ut={style:{"margin-top":"10px"}},qt={class:"scholarList"},Qt=["onClick"],Xt={class:"left"},Yt={class:"name_institution"},Gt={class:"name"},Jt=ye(()=>t("span",{class:"relationship",style:{color:"green"}},"合作者",-1)),Zt={class:"right"},ei=ye(()=>t("div",null,"合作论文数",-1)),ti={style:{color:"dodgerblue"}},ii={class:"institutionList"},ni=["onClick"],oi={class:"left"},ai={class:"name_institution"},si={class:"name"},li={class:"right"},ri=ye(()=>t("div",null,"合作论文数",-1)),ci={style:{color:"dodgerblue"}},di={__name:"Cooperation",props:{scholar:{default:{id:""},type:Object}},setup(e){const r=e,{scholar:i}=oe(r);ae(i,()=>{z()},{deep:!0}),se(()=>{setTimeout(()=>{},1e3),setTimeout(()=>{},2e3)}),Fe();const a=Pe(),n=ie({option:{tooltip:{},animation:!1,series:[{type:"graph",layout:"force",force:{repulsion:80},symbolSize:15,data:[],links:[]}]}}),c=ie(({focused:w,checked:B})=>{const S={};return B?(S.background="#d03050",w&&(S.boxShadow="0 0 0 2px #d0305040")):(S.background="#2080f0",w&&(S.boxShadow="0 0 0 2px #2080f040")),S});let o=F(!1),l=F(1);const f=F([]),u=F([]),g=()=>{ge(document.getElementById("scholar_diagram")).setOption(n.option)};function z(){dt({id:parseInt(i.value.id)}).then(function(w){let B=w.data.institutions,S=w.data.researchers;for(let v in B)B.hasOwnProperty(v)&&u.value.push({id:v,data:B[v]});for(let v in S)S.hasOwnProperty(v)&&f.value.push({id:v,data:S[v]});u.value.sort(function(v,R){return R.data.times-v.data.times}),f.value.sort(function(v,R){return R.data.times-v.data.times}),n.option.series[0].data.push({name:i.value.display_name,symbolSize:30});let x=[];for(let v=0;v<f.value.length&&v<30;v++){let R=f.value[v].data.display_name,Q=f.value[v].data.times;R!==i.value.display_name&&(x.includes(R)||(x.push(R),n.option.series[0].data.push({name:R,value:Q}),n.option.series[0].links.push({source:i.value.display_name,target:R})))}g()})}function _(){l.value=1}function C(){l.value=2}function $(w){a.push({name:"ScholarPage",query:{id:parseInt(w.id)}})}function W(w){a.push({name:"Institution",query:{id:parseInt(w.id)}})}return(w,B)=>{const S=ht;return T(),O(te,null,[t("div",Dt,[t("div",Et,[t("button",{class:ze(["type",{scholar:p(l)===1}]),onClick:_},"合作学者",2),t("button",{class:ze(["type",{institution:p(l)===2}]),onClick:C},"合作机构",2)]),J(t("div",At,[d(p($t),{"rail-style":c,value:p(o),"onUpdate:value":B[0]||(B[0]=x=>nt(o)?o.value=x:o=x)},{checked:b(()=>[A(" 列表 ")]),unchecked:b(()=>[A(" 关系图 ")]),_:1},8,["rail-style","value"])],512),[[Z,p(l)===1]])]),J(t("div",Kt,null,512),[[Z,!p(o)&&p(l)===1]]),t("div",Ut,[d(S,{style:{"max-height":"800px"}},{default:b(()=>[J(t("div",qt,[(T(!0),O(te,null,Ce(f.value,(x,v)=>(T(),O("div",{class:"scholar",onClick:R=>$(x)},[t("div",Xt,[t("div",Yt,[t("div",Gt,[A(ee(x.data.display_name),1),Jt])])]),t("div",Zt,[ei,t("div",ti,ee(x.data.times),1)])],8,Qt))),256))],512),[[Z,p(o)&&p(l)===1]])]),_:1})]),J(t("div",ii,[(T(!0),O(te,null,Ce(u.value,(x,v)=>(T(),O("div",{class:"institution",onClick:R=>W(x)},[t("div",oi,[t("div",ai,[t("div",si,ee(x.data.display_name),1)])]),t("div",li,[ri,t("div",ci,ee(x.data.times),1)])],8,ni))),256))],512),[[Z,p(l)===2]])],64)}}},ui=K(di,[["__scopeId","data-v-8bed9e1c"]]);const Me=e=>(U("data-v-79d3f3c4"),e=e(),q(),e),hi=Me(()=>t("div",{class:"head"},[t("div",{style:{"font-size":"16px","font-weight":"600"}},"产出统计")],-1)),mi=Me(()=>t("div",null,[t("div",{id:"FieldStatistics1"})],-1)),pi=[hi,mi],_i={__name:"OutputQuantity",props:{scholar:{default:{counts_by_year:[]},type:Object}},setup(e){const r=e,{scholar:i}=oe(r);ae(i,()=>{c()},{deep:!0}),se(()=>{});const a=ie({option:{title:{text:""},tooltip:{trigger:"axis"},legend:{data:["works_count","oa_works_count","cited_by_count"]},grid:{left:"3%",right:"4%",bottom:"3%",containLabel:!0},toolbox:{feature:{saveAsImage:{}}},xAxis:{type:"category",boundaryGap:!1,data:[]},yAxis:{type:"value"},series:[{name:"works_count",type:"line",data:[]},{name:"oa_works_count",type:"line",data:[]},{name:"cited_by_count",type:"line",data:[]}]}}),n=()=>{ge(document.getElementById("FieldStatistics1")).setOption(a.option)};function c(){for(let o=i.value.counts_by_year.length-1;o>=0;o--)a.option.xAxis.data.push(i.value.counts_by_year[o].year),a.option.series[0].data.push(i.value.counts_by_year[o].works_count),a.option.series[1].data.push(i.value.counts_by_year[o].oa_works_count),a.option.series[2].data.push(i.value.counts_by_year[o].cited_by_count);n()}return(o,l)=>(T(),O("div",null,pi))}},vi=K(_i,[["__scopeId","data-v-79d3f3c4"]]);const Le=e=>(U("data-v-4b1ba128"),e=e(),q(),e),fi={class:"left"},gi={class:"profile"},bi=Le(()=>t("svg",{xmlns:"http://www.w3.org/2000/svg","xmlns:xlink":"http://www.w3.org/1999/xlink",viewBox:"0 0 32 32"},[t("path",{d:"M19 10h7v2h-7z",fill:"currentColor"}),t("path",{d:"M19 15h7v2h-7z",fill:"currentColor"}),t("path",{d:"M19 20h7v2h-7z",fill:"currentColor"}),t("path",{d:"M6 10h7v2H6z",fill:"currentColor"}),t("path",{d:"M6 15h7v2H6z",fill:"currentColor"}),t("path",{d:"M6 20h7v2H6z",fill:"currentColor"}),t("path",{d:"M28 5H4a2.002 2.002 0 0 0-2 2v18a2.002 2.002 0 0 0 2 2h24a2.002 2.002 0 0 0 2-2V7a2.002 2.002 0 0 0-2-2zM4 7h11v18H4zm13 18V7h11v18z",fill:"currentColor"})],-1)),yi={class:"edu_work"},xi={class:"middle"},wi={class:"right"},Si={class:"section3 right_item"},zi={class:"section4 right_item"},Ci=Le(()=>t("div",{class:"data_disclaimer"},[t("p",null,"数据免责声明"),t("p",null,"页面数据均来自互联网公开来源、合作出版商和通过AI技术自动分析结果， 我们不对页面数据的有效性、准确性、正确性、可靠性、完整性和及时性做出任何承诺和保证。 若有疑问，可以通过电子邮件方式联系我们：mewscience@163.com")],-1)),$i={__name:"ScholarPage",setup(e){const r=$e(()=>ke(()=>import("./Achievements-afdb7d97.js"),["assets/Achievements-afdb7d97.js","assets/index-b27597f8.js","assets/index-53dfe5d9.css","assets/index-eb756369.js","assets/Dropdown-488366d3.js","assets/Popover-61edb1a7.js","assets/format-length-c9d165c6.js","assets/Icon-98a0c14c.js","assets/create-657dc0dd.js","assets/Divider-f8fc66cc.js","assets/ListItem-f81f04ef.js","assets/Ellipsis-0b59b29f.js","assets/Tooltip-a25626bb.js","assets/headers-87eb3e56.js","assets/light-5e5d12e6.js","assets/DrawerContent-f16998e5.js","assets/Drawer-e775b6b5.js","assets/Achievements-682d473c.css"])),i=$e(()=>ke(()=>import("./Profile-cffe0e1c.js"),["assets/Profile-cffe0e1c.js","assets/index-b27597f8.js","assets/index-53dfe5d9.css","assets/index-eb756369.js","assets/Popover-61edb1a7.js","assets/format-length-c9d165c6.js","assets/get-slot-1efb97e5.js","assets/Image-1a0c3b52.js","assets/Tooltip-a25626bb.js","assets/use-locale-c044757c.js","assets/Add-a453005a.js","assets/Input-f8b5fbf4.js","assets/use-message-cf8630a3.js","assets/Divider-f8fc66cc.js","assets/headers-87eb3e56.js","assets/light-5e5d12e6.js","assets/DrawerContent-f16998e5.js","assets/Drawer-e775b6b5.js","assets/Profile-cc80f3b3.css"]));let a=F(!0);const n=Fe();Pe(),se(()=>{c.value=n.query.id,f()}),ae(n,(u,g)=>{console.log("watch 已触发",u,g),c.value=n.query.id,f(),o.value++});const c=F();let o=F(0);const l=F();function f(){ut({id:c.value}).then(function(u){console.log(u.data);const g=new Date(u.data.updated_date),z=g.getFullYear(),_=(g.getMonth()+1).toString().padStart(2,"0"),C=g.getDate().toString().padStart(2,"0"),$=g.getHours().toString().padStart(2,"0"),W=g.getMinutes().toString().padStart(2,"0");u.data.updated_date=z+"年"+_+"月"+C+"日"+$+":"+W,l.value=u.data})}return(u,g)=>{const z=_t;return T(),O("div",{class:"container",key:p(o)},[t("div",fi,[d(p(Bt),null,{default:b(()=>[d(p(_e),{"line-type":"dashed"},{default:b(()=>[t("div",gi,[d(p(ot),null,{default:b(()=>[d(p(i),{identity:p(a),scholar:l.value},null,8,["identity","scholar"])]),_:1})])]),_:1}),d(p(_e),{"line-type":"dashed"},{icon:b(()=>[d(z,{size:"30"},{default:b(()=>[bi]),_:1})]),default:b(()=>[t("div",yi,[d(Ht,{scholar:l.value},null,8,["scholar"])])]),_:1}),d(p(_e))]),_:1})]),t("div",xi,[d(vi,{scholar:l.value,class:"middle1 middle-item"},null,8,["scholar"]),d(p(r),{scholar:l.value,class:"middle2 middle-item"},null,8,["scholar"])]),t("div",wi,[t("div",Si,[d(jt,{scholar:l.value},null,8,["scholar"])]),t("div",zi,[d(ui,{scholar:l.value},null,8,["scholar"])]),Ci])])}}},Mi=K($i,[["__scopeId","data-v-4b1ba128"]]);export{Mi as default};
